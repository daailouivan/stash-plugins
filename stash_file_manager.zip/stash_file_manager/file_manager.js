(function () {
  "use strict";

  try {
    if (!window.PluginApi) {
      console.warn("[PathFileManager] window.PluginApi is not ready.");
      return;
    }

    const { React, ReactDOM, register } = window.PluginApi;
    if (!React || !ReactDOM) {
      console.warn("[PathFileManager] React or ReactDOM not found on PluginApi.");
      return;
    }

    const { useState, useEffect, useMemo, useCallback, useRef } = React;

    // Global In-Memory Singleton Cache (instant 0ms retrieval within session)
    window.__SFM_GLOBAL_CACHE__ = window.__SFM_GLOBAL_CACHE__ || {
      trie: null,
      scenes: null,
      timestamp: 0,
    };

    // IndexedDB Persistent Storage for Large Libraries (replaces 5MB sessionStorage limit)
    const IDB_NAME = "stash_file_manager_db";
    const IDB_VERSION = 1;
    const IDB_STORE = "library";
    const CACHE_KEY = "scenes_index_v7";
    const CACHE_TTL_MS = 24 * 60 * 60 * 1000; // 24 hours

    function openIDB() {
      return new Promise((resolve) => {
        if (!window.indexedDB) return resolve(null);
        try {
          const req = window.indexedDB.open(IDB_NAME, IDB_VERSION);
          req.onupgradeneeded = (e) => {
            const db = e.target.result;
            if (!db.objectStoreNames.contains(IDB_STORE)) {
              db.createObjectStore(IDB_STORE);
            }
          };
          req.onsuccess = () => resolve(req.result);
          req.onerror = () => resolve(null);
        } catch (e) {
          resolve(null);
        }
      });
    }

    async function idbGet(key) {
      const db = await openIDB();
      if (!db) return null;
      return new Promise((resolve) => {
        try {
          const tx = db.transaction(IDB_STORE, "readonly");
          const store = tx.objectStore(IDB_STORE);
          const req = store.get(key);
          req.onsuccess = () => resolve(req.result || null);
          req.onerror = () => resolve(null);
        } catch (e) {
          resolve(null);
        }
      });
    }

    async function idbSet(key, val) {
      const db = await openIDB();
      if (!db) return false;
      return new Promise((resolve) => {
        try {
          const tx = db.transaction(IDB_STORE, "readwrite");
          const store = tx.objectStore(IDB_STORE);
          const req = store.put(val, key);
          req.onsuccess = () => resolve(true);
          req.onerror = () => resolve(false);
        } catch (e) {
          resolve(false);
        }
      });
    }

    async function idbClear() {
      const db = await openIDB();
      if (!db) return false;
      return new Promise((resolve) => {
        try {
          const tx = db.transaction(IDB_STORE, "readwrite");
          const store = tx.objectStore(IDB_STORE);
          const req = store.clear();
          req.onsuccess = () => resolve(true);
          req.onerror = () => resolve(false);
        } catch (e) {
          resolve(false);
        }
      });
    }

    async function clearCachedScenes() {
      try {
        if (window.__SFM_GLOBAL_CACHE__) {
          window.__SFM_GLOBAL_CACHE__.trie = null;
          window.__SFM_GLOBAL_CACHE__.scenes = null;
          window.__SFM_GLOBAL_CACHE__.timestamp = 0;
        }
        await idbClear();
      } catch (e) {
        console.warn("[PathFileManager] clearCachedScenes error:", e);
      }
    }

    // GraphQL Query Helper
    async function gqlFetch(query, variables = {}) {
      const res = await window.fetch("/graphql", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "same-origin",
        body: JSON.stringify({ query, variables }),
      });
      const json = await res.json();
      if (json.errors && json.errors.length > 0) {
        throw new Error(json.errors[0].message);
      }
      return json.data;
    }

    // Stash Plugin Settings Helpers (Query & Mutation)
    async function fetchStashPluginSettings() {
      try {
        const data = await gqlFetch(`query GetSFMSettings {
          configuration {
            general {
              stashes {
                path
              }
            }
            plugins
          }
        }`);
        const sfm = data?.configuration?.plugins?.stash_file_manager || {};
        const stashes = (data?.configuration?.general?.stashes || []).map((s) => s.path).filter(Boolean);
        return { ...sfm, __stashes__: stashes };
      } catch (e) {
        try {
          const fallbackData = await gqlFetch(`query GetSFMSettingsFallback {
            configuration {
              plugins
            }
          }`);
          return fallbackData?.configuration?.plugins?.stash_file_manager || {};
        } catch (err) {
          return {};
        }
      }
    }

    async function saveStashPluginSettings(values) {
      try {
        const payload = {
          default_transcode_method: String(values.default_transcode_method || "direct"),
          fallback_transcode_method: String(values.fallback_transcode_method || "hls"),
          root_library_path: String(values.root_library_path || ""),
          folder_view_mode: String(values.folder_view_mode || "cards"),
          scene_view_mode: String(values.scene_view_mode || "cards"),
          default_sort_field: String(values.default_sort_field || "name"),
          default_sort_direction: String(values.default_sort_direction || "asc"),
          folder_card_size: Number(values.folder_card_size) || 160,
          scene_card_size: Number(values.scene_card_size) || 240,
          remember_last_path: values.remember_last_path !== false,
          auto_rebuild_tree_on_start: Boolean(values.auto_rebuild_tree_on_start),
        };
        const data = await gqlFetch(
          `mutation ConfigureSFM($plugin_id: ID!, $input: Map!) {
            configurePlugin(plugin_id: $plugin_id, input: $input)
          }`,
          { plugin_id: "stash_file_manager", input: payload }
        );
        return data?.configurePlugin;
      } catch (e) {
        console.error("[SFM] Failed to configure plugin settings:", e);
        return null;
      }
    }

    // Helper: format bytes
    function formatBytes(bytes) {
      if (!bytes || bytes <= 0) return "0 B";
      const k = 1024;
      const sizes = ["B", "KB", "MB", "GB", "TB"];
      const i = Math.floor(Math.log(bytes) / Math.log(k));
      return (bytes / Math.pow(k, i)).toFixed(1) + " " + sizes[i];
    }

    // Helper: format duration seconds
    function formatDuration(sec) {
      if (!sec || sec <= 0) return "";
      const h = Math.floor(sec / 3600);
      const m = Math.floor((sec % 3600) / 60);
      const s = Math.floor(sec % 60);
      if (h > 0) {
        return `${h}:${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
      }
      return `${m}:${s.toString().padStart(2, "0")}`;
    }
    const formatSeconds = formatDuration;

    // React Error Boundary to prevent any child modal or component error from closing the workspace
    class SafeErrorBoundary extends React.Component {
      constructor(props) {
        super(props);
        this.state = { hasError: false, error: null };
      }
      static getDerivedStateFromError(error) {
        return { hasError: true, error };
      }
      componentDidCatch(error, info) {
        console.error("[SFM SafeErrorBoundary caught]", error, info);
      }
      render() {
        if (this.state.hasError) {
          return React.createElement(
            "div",
            {
              className: "sfm-modal-backdrop",
              onClick: () => {
                this.setState({ hasError: false, error: null });
                if (this.props.onReset) this.props.onReset();
              },
            },
            React.createElement(
              "div",
              {
                className: "sfm-player-dialog p-4 bg-dark text-light border border-danger",
                onClick: (e) => e.stopPropagation(),
                style: { maxWidth: "520px", margin: "10% auto", borderRadius: "8px" },
              },
              React.createElement("h5", { className: "text-danger" }, React.createElement(IconAlert, { size: 16, className: "mr-2 text-danger" }), "Video Player Error"),
              React.createElement("p", { className: "text-muted small" }, String(this.state.error?.message || this.state.error)),
              React.createElement(
                "button",
                {
                  className: "btn btn-secondary btn-sm mt-3",
                  onClick: () => {
                    this.setState({ hasError: false, error: null });
                    if (this.props.onReset) this.props.onReset();
                  },
                },
                "Close Player"
              )
            )
          );
        }
        return this.props.children;
      }
    }

    // Modern SVG Vector Icons for UI consistency (no cartoon emojis)
    function IconHome({ size = 14, color = "currentColor", style = {} }) {
      return React.createElement(
        "svg",
        {
          width: size,
          height: size,
          viewBox: "0 0 24 24",
          fill: "none",
          stroke: color,
          strokeWidth: "2",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          style: { display: "inline-block", verticalAlign: "-2px", ...style },
        },
        React.createElement("path", { d: "M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" }),
        React.createElement("polyline", { points: "9 22 9 12 15 12 15 22" })
      );
    }

    function IconArrowLeft({ size = 13, color = "currentColor", style = {} }) {
      return React.createElement(
        "svg",
        {
          width: size,
          height: size,
          viewBox: "0 0 24 24",
          fill: "none",
          stroke: color,
          strokeWidth: "2.2",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          style: { display: "inline-block", verticalAlign: "-1px", ...style },
        },
        React.createElement("line", { x1: "19", y1: "12", x2: "5", y2: "12" }),
        React.createElement("polyline", { points: "12 19 5 12 12 5" })
      );
    }

    function IconArrowUp({ size = 13, color = "currentColor", style = {} }) {
      return React.createElement(
        "svg",
        {
          width: size,
          height: size,
          viewBox: "0 0 24 24",
          fill: "none",
          stroke: color,
          strokeWidth: "2.2",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          style: { display: "inline-block", verticalAlign: "-1px", ...style },
        },
        React.createElement("line", { x1: "12", y1: "19", x2: "12", y2: "5" }),
        React.createElement("polyline", { points: "5 12 12 5 19 12" })
      );
    }

    function IconFolder({ size = 20, color = "currentColor", className = "" }) {
      return React.createElement(
        "svg",
        {
          viewBox: "0 0 24 24",
          width: size,
          height: size,
          fill: color,
          className: `sfm-svg-icon ${className}`.trim(),
          style: { display: "inline-block", verticalAlign: "middle" },
          "aria-hidden": "true",
        },
        React.createElement("path", {
          d: "M10 4H4c-1.11 0-2 .89-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-8l-2-2z",
        })
      );
    }

    function IconFolderCard({ size = 46, color = "#81a1c1" }) {
      return React.createElement(
        "svg",
        {
          viewBox: "0 0 24 24",
          width: size,
          height: size,
          className: "sfm-folder-card-svg",
          "aria-hidden": "true",
        },
        React.createElement("path", {
          d: "M10 4H4c-1.1 0-2 .9-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-8l-2-2z",
          fill: color,
          opacity: "0.85",
        }),
        React.createElement("path", {
          d: "M20 9H4a1 1 0 0 0-1 1v8a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V10a1 1 0 0 0-1-1z",
          fill: "#88c0d0",
          opacity: "0.95",
        })
      );
    }

    function IconZoom({ size = 12, color = "#81a1c1" }) {
      return React.createElement(
        "svg",
        {
          width: size,
          height: size,
          viewBox: "0 0 24 24",
          fill: "none",
          stroke: color,
          strokeWidth: "2.2",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          style: { display: "inline-block", verticalAlign: "middle", flexShrink: 0 },
        },
        React.createElement("circle", { cx: "11", cy: "11", r: "8" }),
        React.createElement("line", { x1: "21", y1: "21", x2: "16.65", y2: "16.65" }),
        React.createElement("line", { x1: "11", y1: "8", x2: "11", y2: "14" }),
        React.createElement("line", { x1: "8", y1: "11", x2: "14", y2: "11" })
      );
    }

    function IconSmartphone({ size = 14, color = "currentColor", style = {} }) {
      return React.createElement(
        "svg",
        {
          viewBox: "0 0 24 24",
          width: size,
          height: size,
          stroke: color,
          strokeWidth: "2",
          fill: "none",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          style: { display: "inline-block", verticalAlign: "middle", ...style },
        },
        React.createElement("rect", { x: "5", y: "2", width: "14", height: "20", rx: "2", ry: "2" }),
        React.createElement("line", { x1: "12", y1: "18", x2: "12.01", y2: "18" })
      );
    }

    function IconShuffle({ size = 16, color = "currentColor", style = {} }) {
      return React.createElement(
        "svg",
        {
          viewBox: "0 0 24 24",
          width: size,
          height: size,
          stroke: color,
          strokeWidth: "2.2",
          fill: "none",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          style: { display: "inline-block", verticalAlign: "middle", ...style },
        },
        React.createElement("polyline", { points: "16 3 21 3 21 8" }),
        React.createElement("line", { x1: "4", y1: "20", x2: "21", y2: "3" }),
        React.createElement("polyline", { points: "21 16 21 21 16 21" }),
        React.createElement("line", { x1: "15", y1: "15", x2: "21", y2: "21" }),
        React.createElement("line", { x1: "4", y1: "4", x2: "9", y2: "9" })
      );
    }

        function IconCompass({ size = 14, color = "currentColor", className = "", style = {} }) {
      return React.createElement(
        "svg",
        {
          viewBox: "0 0 24 24",
          width: size,
          height: size,
          stroke: color,
          strokeWidth: "2",
          fill: "none",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          className: className,
          style: { display: "inline-block", verticalAlign: "middle", ...style },
        },
        React.createElement("circle", { cx: "12", cy: "12", r: "10" }),
        React.createElement("polygon", { points: "16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76" })
      );
    }

function IconWidth({ size = 12, color = "#81a1c1" }) {
      return React.createElement(
        "svg",
        {
          width: size,
          height: size,
          viewBox: "0 0 24 24",
          fill: "none",
          stroke: color,
          strokeWidth: "2.2",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          style: { display: "inline-block", verticalAlign: "middle", flexShrink: 0 },
        },
        React.createElement("polyline", { points: "7 8 3 12 7 16" }),
        React.createElement("polyline", { points: "17 8 21 12 17 16" }),
        React.createElement("line", { x1: "3", y1: "12", x2: "21", y2: "12" })
      );
    }

    function IconScan({ size = 13, color = "currentColor", style = {} }) {
      return React.createElement(
        "svg",
        {
          width: size,
          height: size,
          viewBox: "0 0 24 24",
          fill: "none",
          stroke: color,
          strokeWidth: "2",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          style: { display: "inline-block", verticalAlign: "-2px", ...style },
        },
        React.createElement("circle", { cx: "12", cy: "12", r: "2", fill: "currentColor" }),
        React.createElement("path", { d: "M16.24 7.76a6 6 0 0 1 0 8.49m-8.48 0a6 6 0 0 1 0-8.49m11.31-2.83a10 10 0 0 1 0 14.14m-14.14 0a10 10 0 0 1 0-14.14" })
      );
    }

    function IconGrid({ size = 13, color = "currentColor", style = {} }) {
      return React.createElement(
        "svg",
        {
          width: size,
          height: size,
          viewBox: "0 0 24 24",
          fill: "none",
          stroke: color,
          strokeWidth: "2",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          style: { display: "inline-block", verticalAlign: "-2px", ...style },
        },
        React.createElement("rect", { x: "3", y: "3", width: "7", height: "7", rx: "1.5" }),
        React.createElement("rect", { x: "14", y: "3", width: "7", height: "7", rx: "1.5" }),
        React.createElement("rect", { x: "14", y: "14", width: "7", height: "7", rx: "1.5" }),
        React.createElement("rect", { x: "3", y: "14", width: "7", height: "7", rx: "1.5" })
      );
    }

    function IconGear({ size = 14, color = "currentColor" }) {
      return React.createElement(
        "svg",
        {
          width: size,
          height: size,
          viewBox: "0 0 24 24",
          fill: "none",
          stroke: color,
          strokeWidth: "2",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          style: { display: "inline-block", verticalAlign: "-1px", marginRight: "4px" },
        },
        React.createElement("circle", { cx: "12", cy: "12", r: "3" }),
        React.createElement("path", {
          d: "M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z",
        })
      );
    }

    function IconSearch({ size = 12, color = "currentColor" }) {
      return React.createElement(
        "svg",
        {
          width: size,
          height: size,
          viewBox: "0 0 24 24",
          fill: "none",
          stroke: color,
          strokeWidth: "2",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          style: { display: "inline-block", verticalAlign: "-1px", marginRight: "4px" },
        },
        React.createElement("circle", { cx: "11", cy: "11", r: "8" }),
        React.createElement("line", { x1: "21", y1: "21", x2: "16.65", y2: "16.65" })
      );
    }

    function IconEdit({ size = 12, color = "currentColor" }) {
      return React.createElement(
        "svg",
        {
          width: size,
          height: size,
          viewBox: "0 0 24 24",
          fill: "none",
          stroke: color,
          strokeWidth: "2",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          style: { display: "inline-block", verticalAlign: "-1px", marginRight: "4px" },
        },
        React.createElement("path", { d: "M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" }),
        React.createElement("path", { d: "M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" })
      );
    }

    function IconX({ size = 12, color = "currentColor", className = "" }) {
      return React.createElement(
        "svg",
        {
          width: size,
          height: size,
          viewBox: "0 0 24 24",
          fill: "none",
          stroke: color,
          strokeWidth: "2.5",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          className: className || undefined,
          style: { display: "inline-block", verticalAlign: "-1px" },
        },
        React.createElement("line", { x1: "18", y1: "6", x2: "6", y2: "18" }),
        React.createElement("line", { x1: "6", y1: "6", x2: "18", y2: "18" })
      );
    }

    function IconPlay({ size = 12, color = "currentColor", style = {} }) {
      return React.createElement(
        "svg",
        {
          width: size,
          height: size,
          viewBox: "0 0 24 24",
          fill: color,
          stroke: "none",
          className: "sfm-icon-play",
          style: { display: "inline-block", verticalAlign: "-1px", ...style },
        },
        React.createElement("polygon", { points: "5 3 19 12 5 21 5 3" })
      );
    }


    function IconSettings({ size = 15, color = "currentColor", className = "", style = {} }) {
      return React.createElement(
        "svg",
        {
          width: size,
          height: size,
          viewBox: "0 0 24 24",
          fill: "none",
          stroke: color,
          strokeWidth: "2",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          className: className || undefined,
          style: { display: "inline-block", verticalAlign: "-2px", ...style },
        },
        React.createElement("circle", { cx: "12", cy: "12", r: "3" }),
        React.createElement("path", {
          d: "M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z",
        })
      );
    }

    function IconScissors({ size = 13, color = "currentColor", className = "", style = {} }) {
      return React.createElement(
        "svg",
        {
          width: size,
          height: size,
          viewBox: "0 0 24 24",
          fill: "none",
          stroke: color,
          strokeWidth: "2",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          className: className || undefined,
          style: { display: "inline-block", verticalAlign: "-2px", ...style },
        },
        React.createElement("circle", { cx: "6", cy: "6", r: "3" }),
        React.createElement("circle", { cx: "6", cy: "18", r: "3" }),
        React.createElement("line", { x1: "20", y1: "4", x2: "8.12", y2: "15.88" }),
        React.createElement("line", { x1: "14.47", y1: "14.48", x2: "20", y2: "20" }),
        React.createElement("line", { x1: "8.12", y1: "8.12", x2: "12", y2: "12" })
      );
    }

    function IconGlobe({ size = 14, color = "currentColor", className = "", style = {} }) {
      return React.createElement(
        "svg",
        {
          width: size,
          height: size,
          viewBox: "0 0 24 24",
          fill: "none",
          stroke: color,
          strokeWidth: "2",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          className: className || undefined,
          style: { display: "inline-block", verticalAlign: "-2px", ...style },
        },
        React.createElement("circle", { cx: "12", cy: "12", r: "10" }),
        React.createElement("line", { x1: "2", y1: "12", x2: "22", y2: "12" }),
        React.createElement("path", { d: "M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" })
      );
    }

    function IconAlert({ size = 14, color = "currentColor", className = "", style = {} }) {
      return React.createElement(
        "svg",
        {
          width: size,
          height: size,
          viewBox: "0 0 24 24",
          fill: "none",
          stroke: color,
          strokeWidth: "2",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          className: className || undefined,
          style: { display: "inline-block", verticalAlign: "-2px", ...style },
        },
        React.createElement("path", { d: "M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" }),
        React.createElement("line", { x1: "12", y1: "9", x2: "12", y2: "13" }),
        React.createElement("line", { x1: "12", y1: "17", x2: "12.01", y2: "17" })
      );
    }

    function IconCheck({ size = 14, color = "currentColor", className = "", style = {} }) {
      return React.createElement(
        "svg",
        {
          width: size,
          height: size,
          viewBox: "0 0 24 24",
          fill: "none",
          stroke: color,
          strokeWidth: "2.5",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          className: className || undefined,
          style: { display: "inline-block", verticalAlign: "-2px", ...style },
        },
        React.createElement("polyline", { points: "20 6 9 17 4 12" })
      );
    }

    function IconRefresh({ size = 14, color = "currentColor", className = "", style = {} }) {
      return React.createElement(
        "svg",
        {
          width: size,
          height: size,
          viewBox: "0 0 24 24",
          fill: "none",
          stroke: color,
          strokeWidth: "2",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          className: className || undefined,
          style: { display: "inline-block", verticalAlign: "-2px", ...style },
        },
        React.createElement("polyline", { points: "23 4 23 10 17 10" }),
        React.createElement("polyline", { points: "1 20 1 14 7 14" }),
        React.createElement("path", { d: "M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" })
      );
    }

    function IconSparkles({ size = 14, color = "currentColor", className = "", style = {} }) {
      return React.createElement(
        "svg",
        {
          width: size,
          height: size,
          viewBox: "0 0 24 24",
          fill: "none",
          stroke: color,
          strokeWidth: "2",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          className: className || undefined,
          style: { display: "inline-block", verticalAlign: "-2px", ...style },
        },
        React.createElement("path", { d: "M12 3l1.912 5.885L19.798 10.8 13.912 12.715 12 18.6l-1.912-5.885L4.202 10.8l5.886-1.915z" }),
        React.createElement("path", { d: "M5 3l.7 2.15L7.85 5.85 5.7 6.55 5 8.7 4.3 6.55 2.15 5.85 4.3 5.15z" })
      );
    }

    function IconFilm({ size = 14, color = "currentColor", style = {} }) {
      return React.createElement(
        "svg",
        {
          width: size,
          height: size,
          viewBox: "0 0 24 24",
          fill: "none",
          stroke: color,
          strokeWidth: "2",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          className: "sfm-icon-film",
          style: { display: "inline-block", verticalAlign: "-2px", ...style },
        },
        React.createElement("rect", { x: "2", y: "2", width: "20", height: "20", rx: "2.18", ry: "2.18" }),
        React.createElement("line", { x1: "7", y1: "2", x2: "7", y2: "22" }),
        React.createElement("line", { x1: "17", y1: "2", x2: "17", y2: "22" }),
        React.createElement("line", { x1: "2", y1: "12", x2: "22", y2: "12" }),
        React.createElement("line", { x1: "2", y1: "7", x2: "7", y2: "7" }),
        React.createElement("line", { x1: "2", y1: "17", x2: "7", y2: "17" }),
        React.createElement("line", { x1: "17", y1: "17", x2: "22", y2: "17" }),
        React.createElement("line", { x1: "17", y1: "7", x2: "22", y2: "7" })
      );
    }



    // Helper: Resolve common base library prefix across scenes and settings (Smart Common Root)
    function resolveLibraryRoot(scenes, configuredRoot = "", stashPaths = []) {
      // 1. Manual root override from plugin settings
      if (configuredRoot && typeof configuredRoot === "string" && configuredRoot.trim()) {
        const clean = configuredRoot.trim().replace(/\\/g, "/").replace(/\/+$/, "");
        const parts = clean.split("/").filter(Boolean);
        const prefix = clean.startsWith("/") ? `/${parts.join("/")}` : parts.join("/");
        return {
          basePrefix: parts,
          diskRoot: prefix || clean,
        };
      }

      // 2. Single Stash library path from Stash configuration
      if (stashPaths && Array.isArray(stashPaths) && stashPaths.length === 1 && stashPaths[0]) {
        const clean = stashPaths[0].trim().replace(/\\/g, "/").replace(/\/+$/, "");
        const parts = clean.split("/").filter(Boolean);
        const prefix = clean.startsWith("/") ? `/${parts.join("/")}` : parts.join("/");
        return {
          basePrefix: parts,
          diskRoot: prefix || clean,
        };
      }

      // 3. Auto-detect common directory prefix from indexed scene file paths
      if (!scenes || scenes.length === 0) {
        return { basePrefix: [], diskRoot: "" };
      }

      let commonParts = null;
      const sampleLimit = Math.min(scenes.length, 500);

      for (let i = 0; i < sampleLimit; i++) {
        const filePath = scenes[i]?.files?.[0]?.path;
        if (!filePath) continue;

        const clean = filePath.replace(/\\/g, "/");
        const parts = clean.split("/").filter(Boolean);
        if (parts.length <= 1) continue;
        parts.pop(); // Remove filename

        if (commonParts === null) {
          commonParts = [...parts];
        } else {
          let j = 0;
          while (j < commonParts.length && j < parts.length && commonParts[j] === parts[j]) {
            j++;
          }
          commonParts = commonParts.slice(0, j);
          if (commonParts.length === 0) break;
        }
      }

      if (commonParts && commonParts.length > 0) {
        const samplePath = scenes[0]?.files?.[0]?.path || "";
        const diskRoot = (samplePath.startsWith("/") ? "/" : "") + commonParts.join("/");
        return {
          basePrefix: commonParts,
          diskRoot: diskRoot,
        };
      }

      return { basePrefix: [], diskRoot: "" };
    }

    // In-memory Path Trie Data Structure with Root Rebase & Single-Child Auto-Collapsing (Feature 5)
    class PathTrie {
      constructor(basePrefix = [], diskRoot = "") {
        this.basePrefix = basePrefix || [];
        this.diskRoot = diskRoot || "";
        this.sceneIdToFolder = new Map();
        this.root = {
          name: "Stash",
          fullPath: "",
          diskPath: this.diskRoot,
          folders: {},
          directScenes: [],
          allSceneIds: new Set(),
          totalSize: 0,
        };
      }

      getSceneFolder(sceneOrId) {
        if (!sceneOrId) return "";
        const id = typeof sceneOrId === "object" ? sceneOrId.id : sceneOrId;
        if (id && this.sceneIdToFolder && this.sceneIdToFolder.has(String(id))) {
          return this.sceneIdToFolder.get(String(id));
        }
        if (typeof sceneOrId === "object" && typeof sceneOrId._folderPath === "string" && sceneOrId._folderPath) {
          return sceneOrId._folderPath;
        }
        const filePath = typeof sceneOrId === "object" ? sceneOrId.files?.[0]?.path : null;
        if (filePath && this.basePrefix) {
          const cleanPath = filePath.replace(/\\/g, "/");
          const parts = cleanPath.split("/").filter(Boolean);
          parts.pop();
          if (parts.length >= this.basePrefix.length) {
            let match = true;
            for (let i = 0; i < this.basePrefix.length; i++) {
              if (parts[i] !== this.basePrefix[i]) { match = false; break; }
            }
            if (match) {
              return parts.slice(this.basePrefix.length).join("/");
            }
          }
        }
        return "";
      }

      insert(scene) {
        const filePath = scene.files?.[0]?.path;
        if (!filePath) return;

        const cleanPath = filePath.replace(/\\/g, "/");
        const parts = cleanPath.split("/").filter(Boolean);
        parts.pop(); // drop filename

        const size = scene.files?.[0]?.size || 0;

        let curr = this.root;
        curr.allSceneIds.add(scene.id);
        curr.totalSize += size;

        // Check if path matches basePrefix
        let relativeParts = parts;
        let prefixMatches = false;
        if (this.basePrefix && this.basePrefix.length > 0) {
          if (parts.length >= this.basePrefix.length) {
            prefixMatches = true;
            for (let i = 0; i < this.basePrefix.length; i++) {
              if (parts[i] !== this.basePrefix[i]) {
                prefixMatches = false;
                break;
              }
            }
            if (prefixMatches) {
              relativeParts = parts.slice(this.basePrefix.length);
            }
          }
        }

        let accumulated = "";
        for (let i = 0; i < relativeParts.length; i++) {
          const segment = relativeParts[i];
          accumulated = accumulated ? `${accumulated}/${segment}` : segment;
          if (!curr.folders[segment]) {
            const diskSegment = prefixMatches
              ? (this.diskRoot.replace(/\/+$/, "") + "/" + accumulated)
              : ("/" + parts.slice(0, (parts.length - relativeParts.length) + i + 1).join("/"));

            curr.folders[segment] = {
              name: segment,
              fullPath: accumulated,
              diskPath: diskSegment,
              folders: {},
              directScenes: [],
              allSceneIds: new Set(),
              totalSize: 0,
            };
          }
          curr = curr.folders[segment];
          curr.allSceneIds.add(scene.id);
          curr.totalSize += size;
        }
        curr.directScenes.push(scene);
        scene._folderPath = curr.fullPath;
        if (scene.id) {
          this.sceneIdToFolder.set(String(scene.id), curr.fullPath);
        }
      }

      rebaseSingleChildRoot() {
        const self = this;
        while (
          this.root.directScenes.length === 0 &&
          Object.keys(this.root.folders).length === 1
        ) {
          const childKey = Object.keys(this.root.folders)[0];
          const childNode = this.root.folders[childKey];
          const childPrefix = childNode.fullPath;

          function stripPrefix(node) {
            if (!node) return;
            if (node.fullPath === childPrefix) {
              node.fullPath = "";
            } else if (node.fullPath.startsWith(childPrefix + "/")) {
              node.fullPath = node.fullPath.slice(childPrefix.length + 1);
            }
            if (node.directScenes) {
              for (const s of node.directScenes) {
                if (s._folderPath === childPrefix) {
                  s._folderPath = "";
                } else if (s._folderPath && s._folderPath.startsWith(childPrefix + "/")) {
                  s._folderPath = s._folderPath.slice(childPrefix.length + 1);
                }
                if (s.id && self && self.sceneIdToFolder) {
                  self.sceneIdToFolder.set(String(s.id), s._folderPath);
                }
              }
            }
            if (node.folders) {
              for (const k of Object.keys(node.folders)) {
                stripPrefix(node.folders[k]);
              }
            }
          }

          stripPrefix(childNode);

          this.root = {
            name: "Stash",
            fullPath: "",
            diskPath: childNode.diskPath || this.root.diskPath,
            folders: childNode.folders,
            directScenes: childNode.directScenes,
            allSceneIds: childNode.allSceneIds,
            totalSize: childNode.totalSize,
          };
        }
      }

      getNode(pathString) {
        if (!pathString) return this.root;
        const parts = pathString.split("/").filter(Boolean);
        let curr = this.root;
        for (const segment of parts) {
          if (!curr.folders[segment]) return null;
          curr = curr.folders[segment];
        }
        return curr;
      }
    }

    // ==========================================
    // High-Performance Progressive Indexing & Multi-Tier Caching Singleton
    // ==========================================
    let catalogLoadingPromise = null;
    async function ensureCatalog(forceBypassCache = false, onProgress = null) {
      if (!forceBypassCache && window.__SFM_GLOBAL_CACHE__.trie) {
        return window.__SFM_GLOBAL_CACHE__.trie;
      }
      if (catalogLoadingPromise && !forceBypassCache) {
        return catalogLoadingPromise;
      }

      catalogLoadingPromise = (async () => {
        try {
          // Tier 2: Persistent IndexedDB Cache (~50ms across tab visits / reloads)
          const cached = await idbGet(CACHE_KEY);
          if (!forceBypassCache && cached && Array.isArray(cached.scenes) && cached.scenes.length > 0) {
            if (Date.now() - cached.timestamp < CACHE_TTL_MS) {
              const total = cached.scenes.length;
              if (typeof onProgress === "function") {
                onProgress(`Restoring ${total.toLocaleString()} scenes from local index...`);
              }
              const pluginCfg = await fetchStashPluginSettings();
              const { basePrefix, diskRoot } = resolveLibraryRoot(
                cached.scenes,
                pluginCfg.root_library_path,
                pluginCfg.__stashes__
              );
              const newTrie = new PathTrie(basePrefix, diskRoot);
              for (let i = 0; i < total; i++) {
                newTrie.insert(cached.scenes[i]);
              }
              newTrie.rebaseSingleChildRoot();

              window.__SFM_GLOBAL_CACHE__.trie = newTrie;
              window.__SFM_GLOBAL_CACHE__.scenes = cached.scenes;
              window.__SFM_GLOBAL_CACHE__.timestamp = cached.timestamp;
              return newTrie;
            }
          }

          if (typeof window === "undefined" || typeof window.fetch !== "function") {
            return null;
          }

          // Tier 3: Fresh GraphQL Library Ingestion
          if (typeof onProgress === "function") {
            onProgress("Querying library scenes via GraphQL...");
          }

          const query = `
            query GetScenePaths {
              findScenes(filter: { per_page: -1 }) {
                count
                scenes {
                  id
                  title
                  date
                  rating100
                  studio { id name }
                  performers { id name }
                  tags { id name }
                  paths { screenshot preview stream }
                  files { id path basename size duration video_codec format }
                }
              }
            }
          `;
          const data = await gqlFetch(query);
          const scenes = data?.findScenes?.scenes || [];
          const total = scenes.length;

          const pluginCfg = await fetchStashPluginSettings();
          const { basePrefix, diskRoot } = resolveLibraryRoot(
            scenes,
            pluginCfg.root_library_path,
            pluginCfg.__stashes__
          );
          const newTrie = new PathTrie(basePrefix, diskRoot);
          const chunkSize = 1000;

          for (let i = 0; i < total; i += chunkSize) {
            const chunk = scenes.slice(i, i + chunkSize);
            chunk.forEach((s) => newTrie.insert(s));
            const processed = Math.min(i + chunkSize, total);
            if (typeof onProgress === "function") {
              onProgress(`Indexing file hierarchy: ${processed.toLocaleString()} / ${total.toLocaleString()} scenes...`);
            }
            await new Promise((r) => setTimeout(r, 0));
          }
          newTrie.rebaseSingleChildRoot();

          const compact = scenes.map((s) => ({
            id: s.id,
            title: s.title,
            date: s.date,
            rating100: s.rating100,
            _folderPath: s._folderPath || "",
            studio: s.studio ? { id: s.studio.id, name: s.studio.name } : null,
            performers: s.performers ? s.performers.map((p) => ({ id: p.id, name: p.name })) : [],
            tags: s.tags ? s.tags.map((t) => ({ id: t.id, name: t.name })) : [],
            paths: {
              screenshot: s.paths?.screenshot,
              preview: s.paths?.preview,
            },
            files: Array.isArray(s.files)
              ? s.files.map((f) => ({
                  id: f.id,
                  path: f.path,
                  basename: f.basename,
                  size: f.size,
                  duration: f.duration,
                }))
              : [],
          }));

          window.__SFM_GLOBAL_CACHE__.trie = newTrie;
          window.__SFM_GLOBAL_CACHE__.scenes = compact;
          window.__SFM_GLOBAL_CACHE__.timestamp = Date.now();

          await idbSet(CACHE_KEY, {
            timestamp: Date.now(),
            scenes: compact,
          });

          return newTrie;
        } catch (err) {
          console.warn("[PathFileManager] ensureCatalog error:", err);
          return null;
        } finally {
          catalogLoadingPromise = null;
        }
      })();

      return catalogLoadingPromise;
    }



    // Helper: Collect all descendant scenes across all subfolder levels (all levels down)
    function getAllDescendantScenes(node) {
      if (!node) return [];
      const sceneMap = new Map();
      function traverse(n) {
        if (!n) return;
        if (n.directScenes && Array.isArray(n.directScenes)) {
          for (const s of n.directScenes) {
            if (s && s.id && !sceneMap.has(s.id)) {
              sceneMap.set(s.id, s);
            }
          }
        }
        if (n.folders) {
          for (const key of Object.keys(n.folders)) {
            traverse(n.folders[key]);
          }
        }
      }
      traverse(node);
      return Array.from(sceneMap.values());
    }

    // ==========================================
    // Modal & Floating PIP: Binge Reel Video Player
    // (Features: Binge Fast-Forward/Rewind Controls, 1-Click PiP, Smooth Direct/Transcode Streaming, VLC Integration)
    // ==========================================
    // ==========================================
    // Modal & Floating PIP: Binge Reel Video Player (Clean Redesigned Interface)
    // Features:
    // - WebM & HLS Transcode Priority (fixes lost duration & timeline seeking)
    // - Clean unified header with single PiP, VLC, and Link actions (no redundancy)
    // - Double-click left/right seek ±10s with native fullscreen prevention
    // - Binge discovery reel scrolling with pull-distance threshold & spring-back animation
    // - 1-Click Native PiP + Draggable In-App Floating Mini Player
    // ==========================================
// ==========================================
    // Modal: Full-Bleed Binge Reel Player (Seamless Video Reel, Circular Buttons & Auto-Hide Overlay)
    // Features:
    // - Full-bleed immersive canvas (top and bottom bars removed)
    // - TikTok / Instagram-style bottom-left metadata overlay (auto-hides with controls)
    // - Unified custom dark scrubber & player controls (no browser UI shifts across Direct/HLS/WebM)
    // - Right-side circular action column: Stash > VLC > Copy Link > Transcode > [space] > Prev/Counter/Next > [space] > PiP > Fullscreen
    // - Persistent, non-breaking Picture-in-Picture (video element remains mounted)
    // - Dynamic transcode fallback: default 'direct', fallback 'hls' for non-native files, resets on scroll
    // - Seamless vertical reel track with connected adjacent top/bottom video slides
    // ==========================================
// ==========================================
    // Modal: Full-Bleed Binge Reel Player (v2.5.0)
    // Features:
    // - Persistent non-breaking PiP with zero lingering player dialog (seamlessly restores on PiP enlarge)
    // - Automatic MPEG-4 vs H.264 detection: MPEG-4 .mp4 automatically defaults to HLS transcode
    // - Compact 36px circular button stack aligned starting with the close button at top right
    // - Increased divider spacer gaps around previous/next buttons
    // - TikTok-style scroll threshold: requires > 50% pull to advance, snaps back to center otherwise
    // - Elevated metadata description overlay (sits comfortably above the scrubbing bar)
    // - Synchronized in-app settings with native Stash config.yml plugin settings
    // ==========================================
// ==========================================
    // Modal: Full-Bleed Binge Reel Player (v2.5.3)
    // Features:
    // - Binge Discover-grade ultra-smooth scrolling (instant momentum, poster fallback, zero black frames)
    // - Proactive MPEG-4 Part 2 / ASP detection (.mp4 extension with mpeg4/divx/xvid automatically uses HLS)
    // - Video track decode watchdog (auto-promotes to HLS if video frames fail to render)
    // - Modern monochrome vector SVG icons (clean theme consistency, no colorful emojis)
    // - Elevated metadata overlay: Title on top, File Type / Codec / Duration / Size / Date on Line 2
    // - Refined right button stack: No divider under Close, PiP and Fullscreen spaced down
    // - Consolidated native Stash plugin configuration
    // ==========================================
    // Helper: Fisher-Yates non-repeating shuffle queue for video player
    function createShuffledQueue(allScenes, currentScene) {
      if (!allScenes || allScenes.length <= 1) return allScenes ? [...allScenes] : [];
      const currentId = currentScene?.id;
      const others = allScenes.filter((s) => s.id !== currentId);
      for (let i = others.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        const temp = others[i];
        others[i] = others[j];
        others[j] = temp;
      }
      return currentScene ? [currentScene, ...others] : others;
    }

    // ==========================================
    // Folder Profile & Video Wall Component (Social Media Profile Simulation)
    // ==========================================
    // Helper: derive clean directory path from file path
    function deriveFolderFromPath(filePath) {
      if (!filePath) return "";
      const clean = filePath.replace(/\\/g, "/");
      const parts = clean.split("/").filter(Boolean);
      parts.pop(); // remove file basename
      
      const trie = window.__SFM_GLOBAL_CACHE__?.trie;
      if (trie?.basePrefix && trie.basePrefix.length > 0) {
        if (parts.length >= trie.basePrefix.length) {
          let match = true;
          for (let i = 0; i < trie.basePrefix.length; i++) {
            if (parts[i] !== trie.basePrefix[i]) {
              match = false;
              break;
            }
          }
          if (match) {
            return parts.slice(trie.basePrefix.length).join("/");
          }
        }
      }
      return parts.join("/");
    }

    function resolveSceneFolder(sceneOrId, trieInstance = null) {
      if (!sceneOrId) return "";
      const trie = trieInstance || window.__SFM_GLOBAL_CACHE__?.trie;
      if (trie && typeof trie.getSceneFolder === "function") {
        const found = trie.getSceneFolder(sceneOrId);
        if (found !== undefined && found !== null && found !== "") {
          return found;
        }
      }
      if (typeof sceneOrId === "object") {
        if (typeof sceneOrId._folderPath === "string" && sceneOrId._folderPath !== "") {
          return sceneOrId._folderPath;
        }
        const filePath = sceneOrId.files?.[0]?.path;
        if (filePath) {
          const derived = deriveFolderFromPath(filePath);
          if (derived) {
            sceneOrId._folderPath = derived;
            return derived;
          }
        }
      } else if (typeof sceneOrId === "string" || typeof sceneOrId === "number") {
        const cached = window.__SFM_GLOBAL_CACHE__?.scenes?.find((s) => String(s.id) === String(sceneOrId));
        if (cached) return resolveSceneFolder(cached, trieInstance);
      }
      return "";
    }

    // ==========================================
    // History, URL Hash & Navigation Depth Helpers
    // ==========================================
    function normalizePath(p) {
      if (!p) return "";
      try {
        return decodeURIComponent(p).replace(/\\/g, "/").replace(/^\/+|\/+$/g, "");
      } catch (e) {
        return p.replace(/\\/g, "/").replace(/^\/+|\/+$/g, "");
      }
    }

    function buildHashForPath(path, view = null, sceneId = null) {
      const params = new URLSearchParams();
      if (path) params.set("path", path);
      if (view) params.set("view", view);
      if (sceneId) params.set("scene", String(sceneId));
      const qs = params.toString();
      return qs ? `#file-manager?${qs}` : "#file-manager";
    }

    function parseHashState() {
      const hash = window.location.hash || "";
      if (!hash.startsWith("#file-manager")) return null;
      const qIdx = hash.indexOf("?");
      if (qIdx !== -1) {
        const params = new URLSearchParams(hash.slice(qIdx + 1));
        return {
          path: normalizePath(params.get("path") || ""),
          view: params.get("view") || null, // "profile" | "discover" | null
          sceneId: params.get("scene") || null,
        };
      }
      if (hash.startsWith("#file-manager/")) {
        return {
          path: normalizePath(decodeURIComponent(hash.slice("#file-manager/".length)) || ""),
          view: null,
          sceneId: null,
        };
      }
      return { path: "", view: null, sceneId: null };
    }

    function getPathFromHash() {
      const state = parseHashState();
      return state ? state.path : null;
    }

    function getNextSfmDepth() {
      const cur = (window.history.state && typeof window.history.state.sfmDepth === "number")
        ? window.history.state.sfmDepth
        : 1;
      return cur + 1;
    }

    function FolderProfileView({
      folderName,
      targetFolderPath,
      displayFolderPath,
      scenes = [],
      currentScene,
      posterUrl,
      isForceMobile,
      isInsidePlayer = false,
      onToggleForceMobile,
      onSelectScene,
      onCloseProfile,
      onNavigateToDirectory,
      onPlayAll,
      onShuffleAll,
      onNavigateToFolder,
      onFolderChange,
      initialPage = 0,
      onPageChange,
    }) {
      const [forceMobileInternal, setForceMobileInternal] = useState(() => {
        if (typeof isForceMobile === "boolean") return isForceMobile;
        try {
          return window.localStorage.getItem("sfm_force_mobile_view") === "true";
        } catch (e) {
          return false;
        }
      });

      const effectiveForceMobile = typeof isForceMobile === "boolean" && onToggleForceMobile ? isForceMobile : forceMobileInternal;

      const handleToggleMobile = useCallback(() => {
        if (onToggleForceMobile) {
          onToggleForceMobile();
        } else {
          setForceMobileInternal((prev) => {
            const next = !prev;
            try {
              window.localStorage.setItem("sfm_force_mobile_view", String(next));
            } catch (e) {}
            return next;
          });
        }
      }, [onToggleForceMobile]);

      const [activeTab, setActiveTab] = useState(() => (initialPage === 1 ? "explore" : "reels"));

      useEffect(() => {
        const target = initialPage === 1 ? "explore" : "reels";
        if (activeTab !== target) {
          setActiveTab(target);
        }
      }, [initialPage]);

      // Internal navigable path state: defaults to targetFolderPath, updates when breadcrumbs clicked
      const [currentFolderPath, setCurrentFolderPath] = useState(targetFolderPath || "");
      const [isSubfoldersExpanded, setIsSubfoldersExpanded] = useState(false);
      const [subfolderFilter, setSubfolderFilter] = useState("");

      useEffect(() => {
        setCurrentFolderPath(targetFolderPath || "");
        setIsSubfoldersExpanded(false);
        setSubfolderFilter("");
      }, [targetFolderPath]);

      // Resolve current folder node and list of child subfolders from PathTrie
      const trie = window.__SFM_GLOBAL_CACHE__?.trie;
      const currentNode = useMemo(() => {
        if (!trie) return null;
        return trie.getNode(currentFolderPath);
      }, [trie, currentFolderPath]);

      const childFolders = useMemo(() => {
        if (!currentNode || !currentNode.folders) return [];
        return Object.keys(currentNode.folders).sort().map((subName) => {
          const subNode = currentNode.folders[subName];
          const subPath = currentFolderPath ? `${currentFolderPath}/${subName}` : subName;
          const directCount = (subNode && Array.isArray(subNode.directScenes)) ? subNode.directScenes.length : 0;
          const totalCount = subNode && subNode.allSceneIds ? subNode.allSceneIds.size : directCount;
          return {
            name: subName,
            path: subPath,
            count: totalCount || directCount,
          };
        });
      }, [currentNode, currentFolderPath]);

      const displayedSubfolders = useMemo(() => {
        if (!subfolderFilter.trim()) return childFolders;
        const q = subfolderFilter.toLowerCase().trim();
        return childFolders.filter((cf) => cf.name.toLowerCase().includes(q));
      }, [childFolders, subfolderFilter]);

      const handleTabChange = useCallback((tab) => {
        setActiveTab(tab);
        const viewName = tab === "explore" ? "discover" : "profile";
        // Profile view hash must NOT contain sceneId so that hitting back never replays the video
        const targetHash = buildHashForPath(currentFolderPath, viewName, null);
        if (window.location.hash !== targetHash) {
          if (isInsidePlayer) {
            const curDepth = (window.history.state && typeof window.history.state.sfmDepth === "number") ? window.history.state.sfmDepth : 1;
            window.history.replaceState({ sfmPath: currentFolderPath, sfmView: viewName, inPlayerProfile: true, sfmDepth: curDepth }, "", targetHash);
          } else {
            const nextDepth = getNextSfmDepth();
            window.history.pushState({ sfmPath: currentFolderPath, sfmView: viewName, inPlayerProfile: false, sfmDepth: nextDepth }, "", targetHash);
          }
        }
        if (onPageChange) {
          onPageChange(tab === "explore" ? 1 : 0);
        }
      }, [currentFolderPath, isInsidePlayer, onPageChange]);

      // Jump profile folder and remain in the video profile card
      const handleNavigateFolder = useCallback((nextPath) => {
        const norm = normalizePath(nextPath);
        setCurrentFolderPath(norm);
        if (onFolderChange) {
          onFolderChange(norm);
        }
        const viewName = activeTab === "explore" ? "discover" : "profile";
        // Profile view hash must NOT contain sceneId so that hitting back never replays the video
        const targetHash = buildHashForPath(norm, viewName, null);
        if (window.location.hash !== targetHash) {
          if (isInsidePlayer) {
            const curDepth = (window.history.state && typeof window.history.state.sfmDepth === "number") ? window.history.state.sfmDepth : 1;
            window.history.replaceState({ sfmPath: norm, sfmView: viewName, inPlayerProfile: true, sfmDepth: curDepth }, "", targetHash);
          } else {
            const nextDepth = getNextSfmDepth();
            window.history.pushState({ sfmPath: norm, sfmView: viewName, inPlayerProfile: false, sfmDepth: nextDepth }, "", targetHash);
          }
        }
      }, [activeTab, isInsidePlayer, onFolderChange]);

      // Sync internal profile folder & tab with browser back/forward (pageback)
      useEffect(() => {
        const handleProfilePopstate = () => {
          const state = parseHashState();
          if (state) {
            if (state.path !== undefined) {
              setCurrentFolderPath(state.path);
            }
            if (state.view === "discover") {
              setActiveTab("explore");
            } else if (state.view === "profile") {
              setActiveTab("reels");
            }
          }
        };
        window.addEventListener("popstate", handleProfilePopstate);
        return () => window.removeEventListener("popstate", handleProfilePopstate);
      }, []);

      // Include Sub-Folders toggle state for Folder Profile & Discover pages
      const [includeSubfolders, setIncludeSubfolders] = useState(() => {
        try {
          return window.localStorage.getItem("sfm_profile_include_subfolders") === "true";
        } catch (e) {
          return false;
        }
      });

      const handleToggleSubfolders = useCallback(() => {
        setIncludeSubfolders((prev) => {
          const next = !prev;
          try {
            window.localStorage.setItem("sfm_profile_include_subfolders", String(next));
          } catch (e) {}
          return next;
        });
      }, []);

      // Profile-isolated sorting (restored mobile sort option)
      const [profileSort, setProfileSort] = useState(() => {
        try {
          return window.localStorage.getItem("sfm_profile_scene_sort") || "date_desc";
        } catch (e) {
          return "date_desc";
        }
      });

      const handleProfileSortChange = useCallback((newSort) => {
        setProfileSort(newSort);
        try {
          window.localStorage.setItem("sfm_profile_scene_sort", newSort);
        } catch (e) {}
      }, []);

      // Resolve effective scenes for this folder profile (direct vs recursive subfolders)
      // When direct scenes are empty (e.g. parent directories or root), auto-fallback to descendant scenes so the wall never turns black!
      const effectiveScenes = useMemo(() => {
        const trie = window.__SFM_GLOBAL_CACHE__?.trie;
        if (trie) {
          const node = trie.getNode(currentFolderPath);
          if (node) {
            if (includeSubfolders) {
              return getAllDescendantScenes(node);
            }
            if (Array.isArray(node.directScenes) && node.directScenes.length > 0) {
              return node.directScenes;
            }
            // Auto-fallback: if direct scenes are empty in this folder, include subfolder scenes so video wall never stays black
            const descendants = getAllDescendantScenes(node);
            if (descendants.length > 0) {
              return descendants;
            }
            return [];
          }
        }
        return scenes;
      }, [currentFolderPath, includeSubfolders, scenes]);

      // Sorted profile scenes for Reels & Videos view
      const sortedProfileScenes = useMemo(() => {
        if (!Array.isArray(effectiveScenes)) return [];
        const list = [...effectiveScenes];
        list.sort((a, b) => {
          if (profileSort === "title_asc") {
            return (a.title || a.files?.[0]?.basename || "").localeCompare(b.title || b.files?.[0]?.basename || "");
          }
          if (profileSort === "title_desc") {
            return (b.title || b.files?.[0]?.basename || "").localeCompare(a.title || a.files?.[0]?.basename || "");
          }
          if (profileSort === "date_asc") {
            return (a.date || "").localeCompare(b.date || "");
          }
          if (profileSort === "date_desc") {
            return (b.date || "").localeCompare(a.date || "");
          }
          if (profileSort === "rating_desc") {
            return (b.rating100 || 0) - (a.rating100 || 0);
          }
          if (profileSort === "duration_desc") {
            return (b.files?.[0]?.duration || 0) - (a.files?.[0]?.duration || 0);
          }
          if (profileSort === "size_desc") {
            return (b.files?.[0]?.size || 0) - (a.files?.[0]?.size || 0);
          }
          return 0;
        });
        return list;
      }, [effectiveScenes, profileSort]);

      // Retrieve ALL scenes under root across the entire library for Explore
      const allRootScenes = useMemo(() => {
        if (Array.isArray(window.__SFM_GLOBAL_CACHE__?.scenes) && window.__SFM_GLOBAL_CACHE__.scenes.length > 0) {
          return window.__SFM_GLOBAL_CACHE__.scenes;
        }
        const trie = window.__SFM_GLOBAL_CACHE__?.trie;
        if (trie?.root) {
          const descendants = getAllDescendantScenes(trie.root);
          if (descendants.length > 0) return descendants;
        }
        return scenes || [];
      }, [scenes]);

      const [exploreScenes, setExploreScenes] = useState([]);
      const [visibleWallCount, setVisibleWallCount] = useState(36);
      const [visibleExploreCount, setVisibleExploreCount] = useState(36);
      const [isExploreLoading, setIsExploreLoading] = useState(false);

      const wallSentinelRef = useRef(null);
      const exploreSentinelRef = useRef(null);
      const profileContainerRef = useRef(null);

      // Reset visible counts when current folder, subfolders, or sort changes
      useEffect(() => {
        setVisibleWallCount(36);
      }, [currentFolderPath, includeSubfolders, effectiveScenes, profileSort]);

      useEffect(() => {
        setVisibleExploreCount(36);
      }, [exploreScenes]);

      // Discover Scene loader: displays ALL scenes under root in a randomized mosaic
      const loadExploreScenes = useCallback(() => {
        setIsExploreLoading(true);
        const pool = allRootScenes;
        if (!Array.isArray(pool) || pool.length === 0) {
          setExploreScenes([]);
          setVisibleExploreCount(36);
          setIsExploreLoading(false);
          return;
        }
        const shuffled = [...pool];
        for (let i = shuffled.length - 1; i > 0; i--) {
          const j = Math.floor(Math.random() * (i + 1));
          [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
        }
        setExploreScenes(shuffled);
        setVisibleExploreCount(36);
        setIsExploreLoading(false);
      }, [allRootScenes]);

      useEffect(() => {
        if (allRootScenes.length > 0 && exploreScenes.length === 0) {
          loadExploreScenes();
        }
      }, [allRootScenes, loadExploreScenes, exploreScenes.length]);

      // Batch loaders for infinite scrolling
      const handleLoadMoreWall = useCallback(() => {
        setVisibleWallCount((prev) => Math.min(prev + 36, sortedProfileScenes.length));
      }, [sortedProfileScenes.length]);

      const handleLoadMoreExplore = useCallback(() => {
        setVisibleExploreCount((prev) => Math.min(prev + 36, exploreScenes.length));
      }, [exploreScenes.length]);

      // IntersectionObserver for Reels tab bottom sentinel button
      useEffect(() => {
        if (activeTab !== "reels" || typeof IntersectionObserver === "undefined") return;
        const sentinel = wallSentinelRef.current;
        if (!sentinel) return;

        const observer = new IntersectionObserver(
          (entries) => {
            const first = entries[0];
            if (first && first.isIntersecting && visibleWallCount < sortedProfileScenes.length) {
              handleLoadMoreWall();
            }
          },
          { root: null, rootMargin: "400px 0px", threshold: 0.01 }
        );

        observer.observe(sentinel);
        return () => observer.disconnect();
      }, [activeTab, visibleWallCount, sortedProfileScenes.length, handleLoadMoreWall]);

      // IntersectionObserver for Explore tab bottom sentinel button
      useEffect(() => {
        if (activeTab !== "explore" || typeof IntersectionObserver === "undefined") return;
        const sentinel = exploreSentinelRef.current;
        if (!sentinel) return;

        const observer = new IntersectionObserver(
          (entries) => {
            const first = entries[0];
            if (first && first.isIntersecting && visibleExploreCount < exploreScenes.length) {
              handleLoadMoreExplore();
            }
          },
          { root: null, rootMargin: "400px 0px", threshold: 0.01 }
        );

        observer.observe(sentinel);
        return () => observer.disconnect();
      }, [activeTab, visibleExploreCount, exploreScenes.length, handleLoadMoreExplore]);

      // Scroll listener fallback on profileContainerRef
      useEffect(() => {
        const el = profileContainerRef.current;
        if (!el) return;

        const handleScroll = () => {
          const scrollBottom = el.scrollHeight - el.scrollTop - el.clientHeight;
          if (scrollBottom < 400) {
            if (activeTab === "reels" && visibleWallCount < sortedProfileScenes.length) {
              handleLoadMoreWall();
            } else if (activeTab === "explore" && visibleExploreCount < exploreScenes.length) {
              handleLoadMoreExplore();
            }
          }
        };

        el.addEventListener("scroll", handleScroll, { passive: true });
        return () => el.removeEventListener("scroll", handleScroll);
      }, [activeTab, visibleWallCount, sortedProfileScenes.length, visibleExploreCount, exploreScenes.length, handleLoadMoreWall, handleLoadMoreExplore]);

      // Touch gesture coordinates for horizontal swipe left/right
      const touchStartXRef = useRef(0);
      const touchStartYRef = useRef(0);
      const touchStartTimeRef = useRef(0);

      const handleTouchStart = (e) => {
        e.stopPropagation();
        if (!e.touches || e.touches.length === 0) return;
        touchStartXRef.current = e.touches[0].clientX;
        touchStartYRef.current = e.touches[0].clientY;
        touchStartTimeRef.current = Date.now();
      };

      const handleTouchMove = (e) => {
        e.stopPropagation();
      };

      const handleTouchEnd = (e) => {
        e.stopPropagation();
        if (!e.changedTouches || e.changedTouches.length === 0) return;
        const touch = e.changedTouches[0];
        const deltaX = touch.clientX - touchStartXRef.current;
        const deltaY = touch.clientY - touchStartYRef.current;
        const deltaTime = Date.now() - touchStartTimeRef.current;

        if (Math.abs(deltaX) > 40 && Math.abs(deltaX) > Math.abs(deltaY) * 1.25 && deltaTime < 600) {
          if (deltaX < 0 && activeTab === "reels") {
            handleTabChange("explore");
          } else if (deltaX > 0 && activeTab === "explore") {
            handleTabChange("reels");
          }
        }
      };

      // Desktop & Controller navigation: Esc to close profile, Left/Right arrows to switch tabs
      useEffect(() => {
        const handleKeyDown = (e) => {
          if (["input", "textarea", "select"].includes(e.target.tagName?.toLowerCase())) return;
          if (e.key === "Escape") {
            if (onCloseProfile) {
              e.preventDefault();
              onCloseProfile();
            }
          } else if (
            e.key === "ArrowLeft" || e.key === "Left" ||
            e.code === "ArrowLeft" || e.keyCode === 37 ||
            e.key === "PageLeft" || e.key === "MediaTrackPrevious"
          ) {
            e.preventDefault();
            handleTabChange("reels");
          } else if (
            e.key === "ArrowRight" || e.key === "Right" ||
            e.code === "ArrowRight" || e.keyCode === 39 ||
            e.key === "PageRight" || e.key === "MediaTrackNext"
          ) {
            e.preventDefault();
            handleTabChange("explore");
          }
        };
        window.addEventListener("keydown", handleKeyDown);
        return () => window.removeEventListener("keydown", handleKeyDown);
      }, [onCloseProfile, handleTabChange]);

      // Selection handler for explore scene: plays scene in player
      const handleSelectExploreScene = (s) => {
        if (!s) return;
        onSelectScene(s, exploreScenes);
      };

      const stats = useMemo(() => {
        let totalSize = 0;
        let totalDuration = 0;
        const resCounts = {};

        for (const s of effectiveScenes) {
          const f = s.files?.[0];
          if (f) {
            if (f.size) totalSize += f.size;
            if (f.duration) totalDuration += f.duration;
            const h = f.height;
            if (h >= 2160) resCounts["4K"] = (resCounts["4K"] || 0) + 1;
            else if (h >= 1440) resCounts["1440p"] = (resCounts["1440p"] || 0) + 1;
            else if (h >= 1080) resCounts["1080p"] = (resCounts["1080p"] || 0) + 1;
            else if (h >= 720) resCounts["720p"] = (resCounts["720p"] || 0) + 1;
            else if (h) resCounts["SD"] = (resCounts["SD"] || 0) + 1;
          }
        }

        const totalHours = Math.floor(totalDuration / 3600);
        const remainingMins = Math.floor((totalDuration % 3600) / 60);
        const durationStr = totalHours > 0 ? `${totalHours}h ${remainingMins}m` : `${remainingMins}m`;

        return {
          count: effectiveScenes.length,
          formattedSize: formatBytes(totalSize),
          formattedDuration: durationStr,
          resCounts,
        };
      }, [effectiveScenes]);

      const displayName = useMemo(() => {
        if (!currentFolderPath) return "Root";
        const segs = currentFolderPath.split("/").filter(Boolean);
        return segs.length > 0 ? segs[segs.length - 1] : "Root";
      }, [currentFolderPath]);

      // Navigable Breadcrumbs renderer with inline subfolders indicator
      const renderBreadcrumbs = (path, onNav, isNavTitle = false) => {
        const segs = path ? path.split("/").filter(Boolean) : [];
        return React.createElement(
          "nav",
          {
            className: `sfm-profile-breadcrumbs ${isNavTitle ? "sfm-profile-nav-breadcrumbs" : "sfm-profile-bio-breadcrumbs"} d-inline-flex align-items-center flex-wrap`,
            "aria-label": "Folder path",
          },
          React.createElement(
            "button",
            {
              type: "button",
              className: `btn btn-link sfm-profile-crumb-btn ${segs.length === 0 ? "active" : ""}`,
              onClick: (e) => {
                e.stopPropagation();
                onNav("");
              },
              title: "Root directory (/)",
            },
            React.createElement(IconFolder, { size: 12, className: "mr-1 text-info flex-shrink-0" }),
            React.createElement("span", null, "/")
          ),
          segs.map((seg, i) => {
            const segPath = segs.slice(0, i + 1).join("/");
            const isLast = i === segs.length - 1;
            return React.createElement(
              React.Fragment,
              { key: segPath },
              React.createElement("span", { className: "sfm-profile-crumb-sep" }, "/"),
              React.createElement(
                "button",
                {
                  type: "button",
                  className: `btn btn-link sfm-profile-crumb-btn ${isLast ? "active" : ""}`,
                  onClick: (e) => {
                    e.stopPropagation();
                    onNav(segPath);
                  },
                  title: `Navigate to /${segPath}`,
                },
                seg
              )
            );
          })
        );
      };

      return React.createElement(
        "div",
        {
          ref: profileContainerRef,
          className: `sfm-folder-profile-page ${isInsidePlayer ? "sfm-folder-profile-in-player" : ""} ${effectiveForceMobile ? "sfm-profile-force-mobile" : ""}`,
          onClick: (e) => e.stopPropagation(),
          onTouchStart: handleTouchStart,
          onTouchEnd: handleTouchEnd,
        },
        // 1. Sticky Navigation Top Bar (Un-crowded layout with spacious actions)
        React.createElement(
          "div",
          { className: "sfm-profile-nav-bar d-flex align-items-center justify-content-between" },
          React.createElement(
            "button",
            {
              type: "button",
              className: "btn btn-sm btn-outline-info py-1 px-3 d-inline-flex align-items-center sfm-profile-back-btn mr-3",
              onClick: onCloseProfile,
              title: isInsidePlayer ? "Back to Video Player (Esc)" : "Back to File Manager (Esc)",
            },
            React.createElement(IconArrowLeft, { size: 14, className: "mr-1" }),
            React.createElement("span", { className: "font-weight-bold sfm-btn-label-desktop" }, isInsidePlayer ? "Back to Video" : "Back to Files"),
            React.createElement("span", { className: "font-weight-bold sfm-btn-label-mobile" }, "Back")
          ),
          React.createElement(
            "div",
            { className: "sfm-profile-nav-title d-flex align-items-center text-truncate mx-2 flex-grow-1" },
            renderBreadcrumbs(currentFolderPath, handleNavigateFolder, true)
          ),
          React.createElement(
            "div",
            { className: "d-flex align-items-center sfm-profile-nav-actions flex-shrink-0" },
            // Include Sub-Folders Toggle Button
            React.createElement(
              "button",
              {
                type: "button",
                className: `btn btn-sm ${includeSubfolders ? "btn-info font-weight-bold" : "btn-outline-secondary"} py-1 px-3 d-inline-flex align-items-center sfm-profile-subfolders-btn`,
                onClick: handleToggleSubfolders,
                title: includeSubfolders
                  ? "Include Sub-Folders: ON — Showing all scenes in folder hierarchy"
                  : "Include Sub-Folders: OFF — Showing direct scenes in folder only",
              },
              React.createElement("span", { className: "mr-1 font-weight-bold" }, includeSubfolders ? "✓" : "○"),
              React.createElement("span", { className: "sfm-btn-label-desktop" }, "Sub-Folders"),
              React.createElement("span", { className: "sfm-btn-label-mobile" }, "Subs")
            ),
            // Force Mobile View Toggle Button
            React.createElement(
              "button",
              {
                type: "button",
                className: `btn btn-sm ${effectiveForceMobile ? "btn-info font-weight-bold" : "btn-outline-secondary"} py-1 px-3 d-inline-flex align-items-center sfm-profile-mode-btn`,
                onClick: handleToggleMobile,
                title: effectiveForceMobile ? "Switch to Fullscreen Desktop View" : "Switch to Mobile Phone View (Instagram/TikTok 3-Column Wall)",
              },
              React.createElement(IconSmartphone, { size: 14, className: "mr-1" }),
              React.createElement("span", { className: "sfm-btn-label-desktop" }, effectiveForceMobile ? "Desktop Mode" : "Mobile View"),
              React.createElement("span", { className: "sfm-btn-label-mobile" }, effectiveForceMobile ? "Desktop" : "Mobile")
            ),
            // File Manager button (explicitly navigates File Manager to currentFolderPath)
            React.createElement(
              "button",
              {
                type: "button",
                className: "btn btn-sm btn-outline-secondary py-1 px-3 d-inline-flex align-items-center sfm-profile-fm-btn",
                onClick: () => {
                  if (onNavigateToDirectory) {
                    onNavigateToDirectory(currentFolderPath);
                  } else if (onNavigateToFolder) {
                    onNavigateToFolder(currentFolderPath);
                  }
                },
                title: `Open "${currentFolderPath || "Root"}" in File Manager`,
              },
              React.createElement(IconFolder, { size: 13, className: "mr-1" }),
              React.createElement("span", { className: "sfm-btn-label-desktop" }, "File Manager"),
              React.createElement("span", { className: "sfm-btn-label-mobile" }, "Files")
            ),
            React.createElement(
              "button",
              {
                type: "button",
                className: "btn btn-sm btn-outline-secondary py-1 px-2 d-inline-flex align-items-center justify-content-center sfm-profile-close-btn",
                onClick: onCloseProfile,
                title: "Close Profile",
              },
              React.createElement(IconX, { size: 14 })
            )
          )
        ),

        // Main Profile Content Container (Mobile-framed when force mobile, web-centered on desktop)
        React.createElement(
          "div",
          { className: `sfm-profile-main-container ${effectiveForceMobile ? "sfm-profile-mobile-container" : ""}` },
          // 2. Profile Header Section (Social Media Creator Profile Simulation)
          React.createElement(
            "div",
            { className: "sfm-profile-header-container" },
            // Mobile Header Layout: Top row [Avatar] + [3 Stats Columns]
            React.createElement(
              "div",
              { className: "sfm-profile-header-top d-flex align-items-center mb-3" },
              // Large Avatar with IG-style gradient ring
              React.createElement(
                "div",
                { className: "sfm-profile-avatar-wrap position-relative flex-shrink-0" },
                React.createElement("img", {
                  src: posterUrl,
                  className: "sfm-profile-avatar-large-img",
                  alt: displayName,
                }),
                React.createElement(
                  "div",
                  { className: "sfm-profile-avatar-large-badge" },
                  React.createElement(IconFolder, { size: 12, color: "#ffffff" })
                )
              ),
              // Stats Row (IG Profile format: 3 vertical stacks)
              React.createElement(
                "div",
                { className: "sfm-profile-stats-grid d-flex justify-content-around flex-grow-1 ml-3" },
                React.createElement(
                  "div",
                  { className: "sfm-profile-stat-col text-center" },
                  React.createElement("div", { className: "sfm-profile-stat-num" }, stats.count),
                  React.createElement("div", { className: "sfm-profile-stat-lbl" }, "Videos")
                ),
                React.createElement(
                  "div",
                  { className: "sfm-profile-stat-col text-center" },
                  React.createElement("div", { className: "sfm-profile-stat-num" }, stats.formattedSize),
                  React.createElement("div", { className: "sfm-profile-stat-lbl" }, "Size")
                ),
                React.createElement(
                  "div",
                  { className: "sfm-profile-stat-col text-center" },
                  React.createElement("div", { className: "sfm-profile-stat-num" }, stats.formattedDuration),
                  React.createElement("div", { className: "sfm-profile-stat-lbl" }, "Duration")
                )
              )
            ),
            // Folder Bio: Dedicated clean lines for Title, Breadcrumb Path, and Badges (Un-crowded)
            React.createElement(
              "div",
              { className: "sfm-profile-bio-box mb-3" },
              React.createElement("h2", { className: "sfm-profile-title mb-2 font-weight-bold text-light" }, displayName),
              // Dedicated Breadcrumbs Path Line
              React.createElement(
                "div",
                { className: "sfm-profile-bio-path-wrap mb-2" },
                renderBreadcrumbs(currentFolderPath, handleNavigateFolder, false)
              ),
              // Collapsible Subfolders Section (Collapsed by default, eliminates clutter and redundancy)
              childFolders.length > 0 &&
                React.createElement(
                  "div",
                  { className: "sfm-profile-subfolders-section mb-3" },
                  React.createElement(
                    "div",
                    {
                      className: "sfm-profile-subfolders-toggle d-flex align-items-center justify-content-between p-2",
                      role: "button",
                      tabIndex: 0,
                      onClick: (e) => {
                        e.stopPropagation();
                        setIsSubfoldersExpanded((prev) => !prev);
                      },
                      title: isSubfoldersExpanded ? "Click to collapse subfolders" : "Click to expand subfolders",
                    },
                    React.createElement(
                      "div",
                      { className: "d-flex align-items-center" },
                      React.createElement("span", { className: "sfm-collapse-icon mr-2 text-info font-weight-bold" }, isSubfoldersExpanded ? "▼" : "▶"),
                      React.createElement(IconFolder, { size: 14, className: "mr-2 text-info flex-shrink-0" }),
                      React.createElement("span", { className: "font-weight-bold text-light small mr-2" }, `Subfolders in ${displayName}`),
                      React.createElement("span", { className: "badge badge-dark text-muted font-weight-normal py-0 px-2" }, `${childFolders.length}`)
                    ),
                    React.createElement(
                      "span",
                      { className: "small text-muted" },
                      isSubfoldersExpanded ? "Hide ▲" : "Show ▼"
                    )
                  ),
                  isSubfoldersExpanded &&
                    React.createElement(
                      "div",
                      { className: "sfm-profile-subfolders-body p-2" },
                      childFolders.length > 8 &&
                        React.createElement(
                          "div",
                          { className: "sfm-subfolder-filter-wrap mb-2" },
                          React.createElement("input", {
                            type: "text",
                            className: "form-control form-control-sm sfm-subfolder-filter-input",
                            placeholder: `Filter ${childFolders.length} subfolders...`,
                            value: subfolderFilter,
                            onChange: (e) => setSubfolderFilter(e.target.value),
                            onClick: (e) => e.stopPropagation(),
                          })
                        ),
                      React.createElement(
                        "div",
                        { className: "sfm-profile-subfolders-pills d-flex align-items-center flex-wrap gap-2" },
                        displayedSubfolders.map((cf) =>
                          React.createElement(
                            "button",
                            {
                              key: cf.path,
                              type: "button",
                              className: "btn btn-sm sfm-subfolder-pill-btn d-inline-flex align-items-center",
                              onClick: (e) => {
                                e.stopPropagation();
                                handleNavigateFolder(cf.path);
                              },
                              title: `Open "${cf.name}" (${cf.count} scenes)`,
                            },
                            React.createElement(IconFolder, { size: 12, className: "mr-1 text-info" }),
                            React.createElement("span", { className: "font-weight-bold mr-1" }, cf.name),
                            React.createElement("span", { className: "badge badge-dark text-muted font-weight-normal py-0 px-1 ml-1" }, `${cf.count}`)
                          )
                        ),
                        displayedSubfolders.length === 0 &&
                          React.createElement("span", { className: "small text-muted py-1" }, `No subfolders match "${subfolderFilter}"`)
                      )
                    )
                ),
              // Dedicated Chips & Subfolders Line
              React.createElement(
                "div",
                { className: "sfm-profile-bio-chips-wrap d-flex align-items-center flex-wrap gap-2 mb-3" },
                React.createElement(
                  "button",
                  {
                    type: "button",
                    className: `badge sfm-badge-btn ${includeSubfolders ? "sfm-state-active" : "sfm-state-inactive"} cursor-pointer`,
                    onClick: handleToggleSubfolders,
                    title: includeSubfolders
                      ? "Include Sub-Folders: ON — Click to show direct scenes only"
                      : "Include Sub-Folders: OFF — Click to include all sub-folders",
                  },
                  React.createElement("span", { className: "mr-1 font-weight-bold" }, includeSubfolders ? "✓" : "○"),
                  "Sub-Folders"
                ),
                Object.entries(stats.resCounts).map(([res, count]) =>
                  React.createElement(
                    "span",
                    { key: res, className: "badge badge-info font-weight-normal py-1 px-2 sfm-res-chip" },
                    `${res}: ${count}`
                  )
                )
              )
            ),
            // Action Buttons Row (IG/TikTok Style Full-Width)
            React.createElement(
              "div",
              { className: "sfm-profile-action-row d-flex align-items-center gap-2" },
              React.createElement(
                "button",
                {
                  type: "button",
                  className: "btn btn-sm btn-primary flex-grow-1 py-1 font-weight-bold d-inline-flex align-items-center justify-content-center",
                  onClick: () => onPlayAll && onPlayAll(sortedProfileScenes),
                  title: "Play all videos sequentially",
                },
                React.createElement("span", { className: "mr-1" }, "▶"),
                "Play All"
              ),
              React.createElement(
                "button",
                {
                  type: "button",
                  className: "btn btn-sm btn-outline-info flex-grow-1 py-1 d-inline-flex align-items-center justify-content-center",
                  onClick: onShuffleAll,
                  title: "Shuffle play all videos",
                },
                React.createElement(IconShuffle, { size: 14, className: "mr-1" }),
                "Shuffle"
              ),
              React.createElement(
                "button",
                {
                  type: "button",
                  className: "btn btn-sm btn-outline-secondary py-1 px-3 d-inline-flex align-items-center justify-content-center",
                  onClick: () => {
                    const filter = { type: "path", value: currentFolderPath, modifier: "MATCHES_REGEX" };
                    window.open(`/scenes?c=${encodeURIComponent(JSON.stringify(filter))}`, "_blank");
                  },
                  title: "Open in Stash scene grid (new tab)",
                },
                React.createElement(IconGrid, { size: 13, className: "mr-1" }),
                "Stash"
              )
            )
          ),

          // 3. Tab Bar Header: Dual-Tab (Reels & Videos vs Explore)
          React.createElement(
            "div",
            { className: "sfm-profile-wall-tab-bar" },
            // Tab 1: Reels & Videos
            React.createElement(
              "button",
              {
                type: "button",
                className: `sfm-profile-tab-btn ${activeTab === "reels" ? "sfm-profile-tab-active" : "sfm-profile-tab-inactive"} d-flex align-items-center justify-content-center`,
                onClick: () => handleTabChange("reels"),
                title: "Directory Video Wall (Swipe right)",
              },
              React.createElement("span", { className: "mr-1 mr-sm-2 font-weight-bold" }, "▦"),
              React.createElement("span", { className: "font-weight-bold text-uppercase letter-spacing-1 small sfm-tab-text" }, "REELS & VIDEOS"),
              React.createElement("span", { className: "badge badge-dark ml-2 sfm-tab-count-badge" }, sortedProfileScenes.length)
            ),
            // Divider
            React.createElement("div", { className: "sfm-profile-tab-divider" }),
            // Tab 2: Explore
            React.createElement(
              "button",
              {
                type: "button",
                className: `sfm-profile-tab-btn ${activeTab === "explore" ? "sfm-profile-tab-active" : "sfm-profile-tab-inactive"} d-flex align-items-center justify-content-center`,
                onClick: () => handleTabChange("explore"),
                title: "Explore Library Mosaic (All scenes under root randomly)",
              },
              React.createElement(IconCompass, { size: 14, className: "mr-1 mr-sm-2" }),
              React.createElement("span", { className: "font-weight-bold text-uppercase letter-spacing-1 small sfm-tab-text" }, "EXPLORE"),
              React.createElement("span", { className: "badge badge-info ml-2 sfm-tab-explore-badge" }, allRootScenes.length)
            )
          ),

          // 4. Content Area: Either Reels Video Wall (with Mobile/Desktop Sort Toolbar) OR Explore Mosaic Grid
          activeTab === "reels" ? (
            React.createElement(
              React.Fragment,
              null,
              // Reels Toolbar: Folder Name & Scene Count on Left, Sort Selector on Right (Restored Mobile Sort Option)
              React.createElement(
                "div",
                { className: "sfm-reels-toolbar d-flex align-items-center justify-content-between px-3 py-2" },
                React.createElement(
                  "div",
                  { className: "d-flex align-items-center text-truncate mr-2" },
                  React.createElement(IconFolder, { size: 14, color: "#88c0d0", className: "mr-2 flex-shrink-0" }),
                  React.createElement("span", { className: "small font-weight-bold text-light text-truncate" }, displayName),
                  React.createElement("span", { className: "badge badge-dark ml-2 text-muted flex-shrink-0" }, `${sortedProfileScenes.length} videos`)
                ),
                React.createElement(
                  "div",
                  { className: "d-flex align-items-center sfm-profile-sort-wrap flex-shrink-0" },
                  React.createElement("span", { className: "sfm-sort-label mr-2 text-muted small" }, "Sort:"),
                  React.createElement(
                    "select",
                    {
                      className: "sfm-sort-select sfm-profile-sort-select",
                      value: profileSort,
                      onChange: (e) => handleProfileSortChange(e.target.value),
                      title: "Sort Profile Videos",
                    },
                    React.createElement("option", { value: "date_desc" }, "Date (Newest)"),
                    React.createElement("option", { value: "date_asc" }, "Date (Oldest)"),
                    React.createElement("option", { value: "title_asc" }, "Title (A-Z)"),
                    React.createElement("option", { value: "title_desc" }, "Title (Z-A)"),
                    React.createElement("option", { value: "rating_desc" }, "Rating (Highest)"),
                    React.createElement("option", { value: "duration_desc" }, "Duration (Longest)"),
                    React.createElement("option", { value: "size_desc" }, "Size (Largest)")
                  )
                )
              ),
              React.createElement(
                "div",
                { className: "sfm-profile-wall-grid sfm-tab-content-reels" },
                sortedProfileScenes.slice(0, visibleWallCount).map((s) => {
                  const isCurrent = s.id === currentScene?.id;
                  const sPoster = s.paths?.screenshot || `/scene/${s.id}/screenshot`;
                  const sTitle = s.title || s.files?.[0]?.basename || `Scene #${s.id}`;
                  const sDuration = formatDuration(s.files?.[0]?.duration);
                  const sHeight = s.files?.[0]?.height;
                  const sRes = sHeight >= 2160 ? "4K" : sHeight >= 1080 ? "1080p" : sHeight >= 720 ? "720p" : "";

                  return React.createElement(
                    "div",
                    {
                      key: s.id,
                      className: `sfm-wall-tile ${isCurrent ? "sfm-wall-tile-active" : ""}`,
                      onClick: () => {
                        onSelectScene(s, sortedProfileScenes);
                      },
                      title: `Play: ${sTitle}`,
                    },
                    React.createElement("img", {
                      src: sPoster,
                      className: "sfm-wall-tile-img",
                      alt: sTitle,
                      loading: "lazy",
                    }),
                    isCurrent &&
                      React.createElement(
                        "div",
                        { className: "sfm-wall-tile-playing" },
                        "▶ PLAYING"
                      ),
                    sRes &&
                      React.createElement(
                        "div",
                        { className: "sfm-wall-tile-res" },
                        sRes
                      ),
                    React.createElement(
                      "div",
                      { className: "sfm-wall-tile-views" },
                      React.createElement("span", { className: "mr-1", style: { fontSize: "0.65rem" } }, "▶"),
                      React.createElement("span", null, sDuration)
                    ),
                    React.createElement(
                      "div",
                      { className: "sfm-wall-tile-hover-overlay" },
                      React.createElement(
                        "div",
                        { className: "sfm-wall-tile-hover-center" },
                        "▶"
                      ),
                      React.createElement(
                        "div",
                        { className: "sfm-wall-tile-hover-title" },
                        sTitle
                      )
                    )
                  );
                })
              ),
              React.createElement(
                "div",
                {
                  ref: wallSentinelRef,
                  className: "sfm-infinite-scroll-bottom text-center my-4 py-3",
                },
                visibleWallCount < sortedProfileScenes.length
                  ? React.createElement(
                      "button",
                      {
                        type: "button",
                        className: "btn btn-sm btn-outline-info px-4 py-2 font-weight-bold sfm-infinite-load-btn",
                        onClick: handleLoadMoreWall,
                        title: "Load more scenes (or scroll down)",
                      },
                      React.createElement("span", { className: "mr-2" }, "↓"),
                      `Load More Scenes (Showing ${Math.min(visibleWallCount, sortedProfileScenes.length)} of ${sortedProfileScenes.length})`
                    )
                  : sortedProfileScenes.length > 0 &&
                    React.createElement(
                      "div",
                      { className: "text-muted small font-weight-bold" },
                      `✓ All ${sortedProfileScenes.length} scenes loaded`
                    )
              )
            )
          ) : (
            React.createElement(
              React.Fragment,
              null,
              React.createElement(
                "div",
                { className: "sfm-explore-container sfm-tab-content-explore d-flex flex-column flex-grow-1" },
                React.createElement(
                  "div",
                  { className: "sfm-explore-toolbar d-flex align-items-center justify-content-between px-3 py-2" },
                  React.createElement(
                    "div",
                    { className: "d-flex align-items-center text-truncate mr-2" },
                    React.createElement(IconCompass, { size: 14, color: "#88c0d0", className: "mr-2 flex-shrink-0" }),
                    React.createElement("span", { className: "small font-weight-bold text-light text-truncate" }, "Explore Library Mosaic (Random)"),
                    React.createElement(
                      "span",
                      { className: "badge badge-dark ml-2 text-muted flex-shrink-0" },
                      `${exploreScenes.length} scenes`
                    )
                  ),
                  React.createElement(
                    "button",
                    {
                      type: "button",
                      className: "btn btn-sm btn-outline-info py-0 px-2 d-inline-flex align-items-center sfm-explore-refresh-btn font-weight-bold flex-shrink-0",
                      onClick: loadExploreScenes,
                      disabled: isExploreLoading,
                      title: "Shuffle and re-arrange all library scenes randomly",
                    },
                    React.createElement(IconShuffle, { size: 12, className: "mr-1" }),
                    isExploreLoading ? "Shuffling..." : "Shuffle Feed"
                  )
                ),
                isExploreLoading && exploreScenes.length === 0 ? (
                  React.createElement(
                    "div",
                    { className: "text-center py-5 text-muted" },
                    React.createElement("div", { className: "spinner-border spinner-border-sm text-info mr-2" }),
                    "Loading Explore Feed..."
                  )
                ) : (
                  React.createElement(
                    "div",
                    { className: "sfm-explore-grid" },
                    exploreScenes.slice(0, visibleExploreCount).map((s, idx) => {
                      const isFeatured = idx % 12 === 0 || idx % 12 === 7;
                      const isCurrent = s.id === currentScene?.id;
                      const sPoster = s.paths?.screenshot || `/scene/${s.id}/screenshot`;
                      const sTitle = s.title || s.files?.[0]?.basename || `Scene #${s.id}`;
                      const sDuration = formatDuration(s.files?.[0]?.duration);
                      const sHeight = s.files?.[0]?.height;
                      const sRes = sHeight >= 2160 ? "4K" : sHeight >= 1080 ? "1080p" : sHeight >= 720 ? "720p" : "";
                      const studioName = s.studio?.name;

                      return React.createElement(
                        "div",
                        {
                          key: `explore-${s.id}-${idx}`,
                          className: `sfm-explore-tile ${isFeatured ? "sfm-explore-tile-featured" : ""} ${isCurrent ? "sfm-explore-tile-active" : ""}`,
                          onClick: () => handleSelectExploreScene(s),
                          title: `Play: ${sTitle}`,
                        },
                        React.createElement("img", {
                          src: sPoster,
                          className: "sfm-explore-tile-img",
                          alt: sTitle,
                          loading: "lazy",
                        }),
                        isFeatured &&
                          React.createElement(
                            "div",
                            { className: "sfm-explore-tile-featured-badge" },
                            "★ FEATURED"
                          ),
                        isCurrent &&
                          React.createElement(
                            "div",
                            { className: "sfm-wall-tile-playing" },
                            "▶ PLAYING"
                          ),
                        sRes &&
                          React.createElement(
                            "div",
                            { className: "sfm-explore-tile-res" },
                            sRes
                          ),
                        React.createElement(
                          "div",
                          { className: "sfm-explore-tile-views" },
                          React.createElement("span", { className: "mr-1", style: { fontSize: "0.65rem" } }, "▶"),
                          React.createElement("span", null, sDuration)
                        ),
                        React.createElement(
                          "div",
                          { className: "sfm-explore-tile-hover-overlay" },
                          React.createElement(
                            "div",
                            { className: "sfm-explore-tile-hover-center" },
                            "▶"
                          ),
                          React.createElement(
                            "div",
                            { className: "sfm-explore-tile-hover-bottom" },
                            studioName &&
                              React.createElement(
                                "div",
                                { className: "sfm-explore-tile-hover-studio" },
                                studioName
                              ),
                            React.createElement(
                              "div",
                              { className: "sfm-explore-tile-hover-title" },
                              sTitle
                            )
                          )
                        )
                      );
                    })
                  )
                )
              ),
              React.createElement(
                "div",
                {
                  ref: exploreSentinelRef,
                  className: "sfm-infinite-scroll-bottom text-center my-4 py-3",
                },
                visibleExploreCount < exploreScenes.length
                  ? React.createElement(
                      "button",
                      {
                        type: "button",
                        className: "btn btn-sm btn-outline-info px-4 py-2 font-weight-bold sfm-infinite-load-btn",
                        onClick: handleLoadMoreExplore,
                        title: "Load more scenes (or scroll down)",
                      },
                      React.createElement("span", { className: "mr-2" }, "↓"),
                      `Load More Scenes (Showing ${Math.min(visibleExploreCount, exploreScenes.length)} of ${exploreScenes.length})`
                    )
                  : exploreScenes.length > 0 &&
                    React.createElement(
                      "div",
                      { className: "text-muted small font-weight-bold" },
                      `✓ All ${exploreScenes.length} scenes loaded`
                    )
              )
            )
          )
        )
      );
    }
    function BingeReelPlayerModal({ scene, scenes = [], onSelectScene, onClose, onOpenProfile, folderName, currentPath, onNavigateToFolder }) {
      const videoRef = useRef(null);

      // Ensure browser fullscreen is cleanly exited when player modal unmounts
      useEffect(() => {
        return () => {
          if (typeof document !== "undefined" && document.fullscreenElement) {
            document.exitFullscreen().catch(() => {});
          }
        };
      }, []);
      const videoContainerRef = useRef(null);
      const hlsInstanceRef = useRef(null);
      const hideTimeoutRef = useRef(null);
      const [isVideoReady, setIsVideoReady] = useState(false);
      const [showFolderProfile, setShowFolderProfile] = useState(false);

      // Force Mobile View State (IG/TikTok Phone Frame simulation)
      const [isForceMobile, setIsForceMobile] = useState(() => {
        try {
          return window.localStorage.getItem("sfm_force_mobile_view") === "true";
        } catch (e) {
          return false;
        }
      });

      const handleToggleForceMobile = useCallback(() => {
        setIsForceMobile((prev) => {
          const next = !prev;
          try {
            window.localStorage.setItem("sfm_force_mobile_view", String(next));
          } catch (e) {}
          return next;
        });
      }, []);

      // Resolve the actual parent folder where this playing scene is located
      const activeSceneFolder = useMemo(() => {
        const resolved = resolveSceneFolder(scene);
        if (resolved !== undefined && resolved !== null && resolved !== "") return resolved;
        if (scene?._folderPath !== undefined && scene._folderPath !== null && scene._folderPath !== "") return scene._folderPath;
        return currentPath || "";
      }, [scene, currentPath]);

      const targetFolderPath = activeSceneFolder;
      const subfolderName = targetFolderPath ? targetFolderPath.split("/").filter(Boolean).pop() : (folderName || "Root");
      const displayFolderPath = targetFolderPath ? `/${targetFolderPath}` : "/";

      // Dynamically resolve all companion scenes belonging to this playing scene and its directory
      const activeFolderScenes = useMemo(() => {
        const trie = window.__SFM_GLOBAL_CACHE__?.trie;
        if (trie && targetFolderPath) {
          const node = trie.getNode(targetFolderPath);
          if (node && Array.isArray(node.directScenes) && node.directScenes.length > 0) {
            return node.directScenes;
          }
        }
        if (Array.isArray(scenes) && scenes.length > 0 && scenes.some((s) => String(s.id) === String(scene?.id))) {
          return scenes;
        }
        return Array.isArray(scenes) && scenes.length > 0 ? scenes : (scene ? [scene] : []);
      }, [targetFolderPath, scenes, scene]);

      // 1. Shuffle Queue State & Non-Repeating Active Queue
      const [isShuffle, setIsShuffle] = useState(() => {
        try {
          return window.localStorage.getItem("sfm_player_shuffle") === "true";
        } catch (e) {
          return false;
        }
      });

      const [shuffledQueue, setShuffledQueue] = useState(() => {
        try {
          const pref = window.localStorage.getItem("sfm_player_shuffle") === "true";
          if (pref && activeFolderScenes && activeFolderScenes.length > 0) {
            return createShuffledQueue(activeFolderScenes, scene);
          }
        } catch (e) {}
        return [];
      });

      useEffect(() => {
        if (isShuffle && activeFolderScenes && activeFolderScenes.length > 0) {
          setShuffledQueue((prev) => {
            const sceneIds = new Set(activeFolderScenes.map((s) => s.id));
            const prevIds = new Set(prev.map((s) => s.id));
            if (sceneIds.size !== prevIds.size || [...sceneIds].some((id) => !prevIds.has(id))) {
              return createShuffledQueue(activeFolderScenes, scene);
            }
            return prev;
          });
        }
      }, [activeFolderScenes, isShuffle, scene?.id]);

      const activeScenes = useMemo(() => {
        if (isShuffle && shuffledQueue.length === activeFolderScenes.length && shuffledQueue.length > 0) {
          return shuffledQueue;
        }
        return activeFolderScenes;
      }, [isShuffle, shuffledQueue, activeFolderScenes]);

      // 2. Scene Navigation & Previews (Sliding Window ±2 for Multi-Video Swiping across Active Queue)
      const currentIndex = useMemo(() => {
        return activeScenes.findIndex((s) => s.id === scene?.id);
      }, [activeScenes, scene?.id]);

      const totalScenes = activeScenes.length;
      const hasPrev = currentIndex > 0;
      const hasPrev2 = currentIndex > 1;
      const hasNext = currentIndex !== -1 && currentIndex < totalScenes - 1;
      const hasNext2 = currentIndex !== -1 && currentIndex < totalScenes - 2;

      const prev2Scene = hasPrev2 ? activeScenes[currentIndex - 2] : null;
      const prevScene = hasPrev ? activeScenes[currentIndex - 1] : null;
      const nextScene = hasNext ? activeScenes[currentIndex + 1] : null;
      const next2Scene = hasNext2 ? activeScenes[currentIndex + 2] : null;

      // 2. Format & Codec Resolution (Proactive MPEG-4 vs H.264 Detection)
      const filePath = scene?.files?.[0]?.path || scene?.files?.[0]?.basename || "";
      const fileExt = (filePath.split(".").pop() || "").toLowerCase();
      const rawCodec = (scene?.files?.[0]?.video_codec || "").toLowerCase();
      const rawFormat = (scene?.files?.[0]?.format || "").toLowerCase();
      const lowerPath = filePath.toLowerCase();
      const lowerTitle = (scene?.title || "").toLowerCase();

      // Robust check for MPEG-4 Part 2 / ASP codecs in .mp4 (which browsers cannot decode natively)
      const isMpeg4 =
        rawCodec.includes("mpeg4") ||
        rawCodec.includes("mp4v") ||
        rawCodec.includes("divx") ||
        rawCodec.includes("xvid") ||
        rawCodec.includes("dx50") ||
        rawCodec.includes("fmp4") ||
        rawFormat.includes("mpeg-4") ||
        rawFormat.includes("mpeg4") ||
        lowerPath.includes("mpeg4") ||
        lowerPath.includes("mpeg-4") ||
        lowerPath.includes("xvid") ||
        lowerPath.includes("divx") ||
        lowerTitle.includes("mpeg4") ||
        lowerTitle.includes("mpeg-4");

      const isUnsupportedCodec =
        isMpeg4 ||
        rawCodec.includes("mpeg2") ||
        rawCodec.includes("wmv") ||
        rawCodec.includes("flv") ||
        rawCodec.includes("vc1") ||
        rawCodec.includes("msmpeg");

      // Only native H.264, AV1, VP9 or WebM are direct-streamable in browsers
      const isNativeDirect = ["mp4", "m4v", "webm"].includes(fileExt) && !isUnsupportedCodec;

      const folderProfileScenes = activeFolderScenes;

      const extLabel = fileExt ? `.${fileExt.toUpperCase()}` : "VIDEO";
      const codecBadge = rawCodec ? rawCodec.toUpperCase() : isMpeg4 ? "MPEG-4" : "";
      const title = scene?.title || scene?.files?.[0]?.basename || `Scene #${scene?.id}`;
      const fileSize = formatBytes(scene?.files?.[0]?.size);
      const durationFormatted = formatDuration(scene?.files?.[0]?.duration);
      const dateStr = scene?.date || "";
      const studioName = scene?.studio?.name || "";
      const posterUrl = scene?.paths?.screenshot || `/scene/${scene?.id}/screenshot`;

      // 3. Transcode Mode & Fallback Strategy
      const defaultMethod = window.__SFM_DEFAULT_TRANSCODE_METHOD__ || "direct";
      const fallbackMethod = window.__SFM_FALLBACK_TRANSCODE_METHOD__ || "hls";

      const targetMode = isNativeDirect ? defaultMethod : fallbackMethod;
      const [streamMode, setStreamMode] = useState(() => targetMode);
      const [customStreamUrl, setCustomStreamUrl] = useState("");
      const [availableStreams, setAvailableStreams] = useState([]);
      const [playerNotice, setPlayerNotice] = useState("");
      const [playerError, setPlayerError] = useState("");
      const [copiedNotice, setCopiedNotice] = useState("");
      const [showTranscodeMenu, setShowTranscodeMenu] = useState(false);

      const [directUrl, setDirectUrl] = useState(() => scene?.paths?.stream || `/scene/${scene?.id}/stream`);
      const [transcodeWebmUrl, setTranscodeWebmUrl] = useState(() => `/scene/${scene?.id}/stream.webm`);
      const [transcodeHlsUrl, setTranscodeHlsUrl] = useState(() => `/scene/${scene?.id}/stream.m3u8`);
      const [transcodeMp4Url, setTranscodeMp4Url] = useState(() => `/scene/${scene?.id}/stream.mp4`);

      const [showSlowLoadPoster, setShowSlowLoadPoster] = useState(false);

      // Dynamically reset stream mode per-scene during scrolling
      useEffect(() => {
        setIsVideoReady(false);
        setShowSlowLoadPoster(false);
        setCustomStreamUrl("");
        setPlayerError("");
        setPlayerNotice("");
        setShowTranscodeMenu(false);
        setStreamMode(targetMode);

        // Prevent thumbnail flash on fast-loading/prebuffered scenes.
        // Only display poster if media decode takes longer than 350ms (e.g. transcode startup).
        const slowTimer = setTimeout(() => {
          setShowSlowLoadPoster(true);
        }, 350);

        return () => clearTimeout(slowTimer);
      }, [scene?.id, targetMode]);

      // Query available streams & fresh file codec via GraphQL
      useEffect(() => {
        if (!scene?.id) return;
        let active = true;

        const initialDirect = scene?.paths?.stream || `/scene/${scene.id}/stream`;
        setDirectUrl(initialDirect);
        setTranscodeWebmUrl(`/scene/${scene.id}/stream.webm`);
        setTranscodeHlsUrl(`/scene/${scene.id}/stream.m3u8`);
        setTranscodeMp4Url(`/scene/${scene.id}/stream.mp4`);

        gqlFetch(
          `query ScenePlaybackDetails($id: ID!) {
            findScene(id: $id) {
              id
              title
              files {
                id
                path
                basename
                size
                duration
                video_codec
                format
              }
              paths {
                stream
                screenshot
                preview
              }
              sceneStreams {
                url
                mime_type
                label
              }
            }
          }`,
          { id: scene.id }
        )
          .then((res) => {
            if (!active) return;
            const data = res?.findScene;
            if (!data) return;

            const officialDirect = data.paths?.stream || initialDirect;
            const streams = data.sceneStreams || [];

            setDirectUrl(officialDirect);
            setAvailableStreams(streams);

            const webm = streams.find((s) => s.url !== officialDirect && (s.mime_type?.includes("webm") || s.url?.includes(".webm") || s.label?.toLowerCase().includes("webm")));
            const hls = streams.find((s) => s.url !== officialDirect && (s.mime_type?.includes("mpegurl") || s.url?.includes(".m3u8") || s.label?.toLowerCase().includes("hls")));
            const mp4 = streams.find((s) => s.url !== officialDirect && (s.mime_type?.includes("mp4") || s.url?.includes("stream.mp4") || s.label?.toLowerCase().includes("mp4")));

            if (webm) setTranscodeWebmUrl(webm.url);
            if (hls) setTranscodeHlsUrl(hls.url);
            if (mp4) setTranscodeMp4Url(mp4.url);

            // Fresh Codec Validation: If probe confirms MPEG-4, enforce HLS immediately
            const freshFile = data.files?.[0];
            if (freshFile) {
              const freshCodec = (freshFile.video_codec || "").toLowerCase();
              const freshFormat = (freshFile.format || "").toLowerCase();
              const freshPath = (freshFile.path || freshFile.basename || "").toLowerCase();
              if (
                freshCodec.includes("mpeg4") ||
                freshCodec.includes("mp4v") ||
                freshCodec.includes("divx") ||
                freshCodec.includes("xvid") ||
                freshFormat.includes("mpeg-4") ||
                freshFormat.includes("mpeg4") ||
                freshPath.includes("mpeg4") ||
                freshPath.includes("mpeg-4")
              ) {
                console.log("[SFM Player] Detected MPEG-4 file from GraphQL details. Switched to HLS transcode.");
                setStreamMode(fallbackMethod);
              }
            }
          })
          .catch((err) => {
            console.warn("[SFM Player] GraphQL stream query error:", err);
          });

        return () => {
          active = false;
        };
      }, [scene?.id, fallbackMethod]);

      // Effective stream URL
      const streamUrl = useMemo(() => {
        if (!scene?.id) return "";
        if (customStreamUrl) return customStreamUrl;
        if (streamMode === "direct") return directUrl;
        if (streamMode === "hls") return transcodeHlsUrl;
        if (streamMode === "webm") return transcodeWebmUrl;
        if (streamMode === "mp4") return transcodeMp4Url;
        return directUrl;
      }, [scene?.id, customStreamUrl, streamMode, directUrl, transcodeHlsUrl, transcodeWebmUrl, transcodeMp4Url]);

      // Helper to pre-resolve stream URLs for adjacent and upcoming scenes
      const resolveSceneStreamUrl = useCallback((sc, mode) => {
        if (!sc?.id) return "";
        const fPath = sc.files?.[0]?.path || sc.files?.[0]?.basename || "";
        const fCodec = (sc.files?.[0]?.video_codec || "").toLowerCase();
        const fFormat = (sc.files?.[0]?.format || "").toLowerCase();
        const fLower = (fPath + " " + (sc.title || "")).toLowerCase();
        const scMpeg4 =
          fCodec.includes("mpeg4") ||
          fCodec.includes("mp4v") ||
          fCodec.includes("divx") ||
          fCodec.includes("xvid") ||
          fFormat.includes("mpeg-4") ||
          fLower.includes("mpeg4") ||
          fLower.includes("xvid") ||
          fLower.includes("divx");

        if (mode === "hls" || scMpeg4) return `/scene/${sc.id}/stream.m3u8`;
        if (mode === "webm") return `/scene/${sc.id}/stream.webm`;
        if (mode === "mp4") return `/scene/${sc.id}/stream.mp4`;
        return sc.paths?.stream || `/scene/${sc.id}/stream`;
      }, []);

      const prev2StreamUrl = useMemo(() => resolveSceneStreamUrl(prev2Scene, streamMode), [prev2Scene, streamMode, resolveSceneStreamUrl]);
      const prevStreamUrl = useMemo(() => resolveSceneStreamUrl(prevScene, streamMode), [prevScene, streamMode, resolveSceneStreamUrl]);
      const nextStreamUrl = useMemo(() => resolveSceneStreamUrl(nextScene, streamMode), [nextScene, streamMode, resolveSceneStreamUrl]);
      const next2StreamUrl = useMemo(() => resolveSceneStreamUrl(next2Scene, streamMode), [next2Scene, streamMode, resolveSceneStreamUrl]);

      // 4. Playback State & Custom Scrubber Control
      const [isPlaying, setIsPlaying] = useState(false);
      const [currentTime, setCurrentTime] = useState(0);
      const [duration, setDuration] = useState(() => scene?.files?.[0]?.duration || 0);
      const [bufferedProgress, setBufferedProgress] = useState(0);
      const [volume, setVolume] = useState(1);
      const [isMuted, setIsMuted] = useState(false);
      const [hudNotice, setHudNotice] = useState("");
      const hudTimerRef = useRef(null);
      const showHud = useCallback((text) => {
        if (hudTimerRef.current) clearTimeout(hudTimerRef.current);
        setHudNotice(text);
        hudTimerRef.current = setTimeout(() => setHudNotice(""), 800);
      }, []);

      const handleSeekBy = useCallback((seconds) => {
        const v = videoRef.current;
        if (!v) return;
        const currentT = v.currentTime || 0;
        const totalDur = (v.duration && !isNaN(v.duration) && v.duration > 0) ? v.duration : (duration || 999999);
        const nextT = Math.max(0, Math.min(totalDur, currentT + seconds));
        v.currentTime = nextT;
        setCurrentTime(nextT);
        showHud(seconds < 0 ? `${seconds}s` : `+${seconds}s`);
      }, [duration, showHud]);

      // Synchronize in-player profile overlay with browser pageback (popstate)
      useEffect(() => {
        const handlePlayerPopstate = () => {
          const state = parseHashState();
          if (!state || state.view !== "profile") {
            setShowFolderProfile(false);
          } else if (state.view === "profile") {
            setShowFolderProfile(true);
          }
        };
        window.addEventListener("popstate", handlePlayerPopstate);
        return () => window.removeEventListener("popstate", handlePlayerPopstate);
      }, []);

      // Auto-Hide Controls & Overlay Timer
      const [isControlsVisible, setIsControlsVisible] = useState(true);

      const resetControlsTimer = useCallback(() => {
        setIsControlsVisible(true);
        if (hideTimeoutRef.current) clearTimeout(hideTimeoutRef.current);
        hideTimeoutRef.current = setTimeout(() => {
          if (isPlaying && !showTranscodeMenu) {
            setIsControlsVisible(false);
          }
        }, 2500);
      }, [isPlaying, showTranscodeMenu]);

      useEffect(() => {
        resetControlsTimer();
        return () => {
          if (hideTimeoutRef.current) clearTimeout(hideTimeoutRef.current);
        };
      }, [resetControlsTimer]);

      // Setup Video Stream Player
      useEffect(() => {
        const v = videoRef.current;
        if (!v || !streamUrl) return;

        if (hlsInstanceRef.current) {
          hlsInstanceRef.current.destroy();
          hlsInstanceRef.current = null;
        }

        const isHlsUrl = streamUrl.includes(".m3u8") || streamMode === "hls";

        if (isHlsUrl) {
          if (v.canPlayType("application/vnd.apple.mpegurl")) {
            v.src = streamUrl;
            v.load();
            v.play().then(() => setIsPlaying(true)).catch(() => {});
          } else if (window.Hls && window.Hls.isSupported()) {
            const hls = new window.Hls({ enableWorker: true, lowLatencyMode: false });
            hlsInstanceRef.current = hls;
            hls.loadSource(streamUrl);
            hls.attachMedia(v);
            hls.on(window.Hls.Events.MANIFEST_PARSED, () => {
              v.play().then(() => setIsPlaying(true)).catch(() => {});
            });
            hls.on(window.Hls.Events.ERROR, (event, data) => {
              if (data.fatal) {
                console.warn("[SFM Player] HLS fatal error, falling back to WebM:", data);
                setStreamMode("webm");
                setPlayerNotice("HLS stream failed in this browser. Switched to WebM Progressive Container.");
              }
            });
          } else {
            setStreamMode("webm");
            setPlayerNotice("HLS requires MSE in this browser. Switched to WebM Progressive Container.");
          }
        } else {
          v.src = streamUrl;
          v.load();
          v.play().then(() => setIsPlaying(true)).catch((err) => {
            if (err.name === "NotAllowedError") {
              v.muted = true;
              setIsMuted(true);
              v.play().then(() => setIsPlaying(true)).catch(() => {});
            }
          });
        }

        return () => {
          if (hlsInstanceRef.current) {
            hlsInstanceRef.current.destroy();
            hlsInstanceRef.current = null;
          }
        };
      }, [streamUrl, streamMode]);

      // Proactive Video Track Watchdog:
      // If direct stream starts playing but has 0 decoded video dimensions (audio only decode of MPEG-4), auto-switch to HLS!
      useEffect(() => {
        const v = videoRef.current;
        if (!v || streamMode !== "direct") return;

        const watchdog = setTimeout(() => {
          if (v && !v.paused && v.currentTime > 0.4 && (v.videoWidth === 0 || v.videoHeight === 0)) {
            console.warn("[SFM Player] Video stream playing without visual track (MPEG-4 decode unsupported). Switching to HLS.");
            setStreamMode(fallbackMethod);
            setPlayerNotice("MPEG-4 video track not supported natively by browser. Switched to HLS transcode.");
          }
        }, 1100);

        return () => clearTimeout(watchdog);
      }, [streamMode, streamUrl, fallbackMethod]);

      // Playback error handler
      const handleVideoError = (e) => {
        console.warn("[SFM Player] Playback error on stream:", streamUrl, e);
        if (streamMode === "direct" && !customStreamUrl) {
          const next = fallbackMethod === "direct" ? "hls" : fallbackMethod;
          setStreamMode(next);
          setPlayerNotice(`Direct stream unsupported for this file. Switched to ${next.toUpperCase()} Transcode.`);
        } else if (streamMode === "hls" && !customStreamUrl) {
          setStreamMode("webm");
          setPlayerNotice("HLS stream failed. Switched to WebM Progressive Container.");
        } else if (streamMode === "webm" && !customStreamUrl) {
          setStreamMode("mp4");
          setPlayerNotice("Switched to MP4 Transcode.");
        } else {
          setPlayerError("Video playback failed on all streams. Click 'VLC' on the right to open externally.");
        }
      };

      // Video event handlers
      const handleTimeUpdate = () => {
        const v = videoRef.current;
        if (!v) return;
        setCurrentTime(v.currentTime);
        if (v.duration && !isNaN(v.duration) && v.duration > 0) {
          setDuration(v.duration);
        }
        if (v.buffered.length > 0 && v.duration) {
          setBufferedProgress((v.buffered.end(v.buffered.length - 1) / v.duration) * 100);
        }
      };

      const handleLoadedMetadata = () => {
        const v = videoRef.current;
        if (!v) return;
        if (v.duration && !isNaN(v.duration) && v.duration > 0) {
          setDuration(v.duration);
        }
      };

      const handleTogglePlay = useCallback(() => {
        const v = videoRef.current;
        if (!v) return;
        if (v.paused) {
          v.play().then(() => setIsPlaying(true)).catch(() => {});
        } else {
          v.pause();
          setIsPlaying(false);
        }
      }, []);

      const handleScrubberClick = (e) => {
        const v = videoRef.current;
        if (!v || !duration) return;
        const rect = e.currentTarget.getBoundingClientRect();
        const pos = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
        v.currentTime = pos * duration;
        setCurrentTime(v.currentTime);
      };

      const handleVolumeChange = (e) => {
        const val = Number(e.target.value);
        setVolume(val);
        const v = videoRef.current;
        if (v) {
          v.volume = val;
          v.muted = val === 0;
          setIsMuted(val === 0);
        }
      };

      const handleToggleMute = () => {
        const v = videoRef.current;
        if (!v) return;
        v.muted = !v.muted;
        setIsMuted(v.muted);
      };

      // Gestures: Double-click left/right side seek ±10s, single click toggle play
      const clickTimer = useRef(null);
      const handleGestureClick = (e) => {
        if (isSwipingGesture.current) {
          isSwipingGesture.current = false;
          return;
        }
        if (clickTimer.current) {
          clearTimeout(clickTimer.current);
          clickTimer.current = null;
          return;
        }
        clickTimer.current = setTimeout(() => {
          handleTogglePlay();
          clickTimer.current = null;
        }, 220);
      };

      const handleDoubleTapSeek = (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (clickTimer.current) {
          clearTimeout(clickTimer.current);
          clickTimer.current = null;
        }
        const v = videoRef.current;
        if (!v) return;
        const rect = e.currentTarget.getBoundingClientRect();
        const clickX = e.clientX - rect.left;
        const width = rect.width;
        if (clickX < width * 0.45) {
          v.currentTime = Math.max(0, v.currentTime - 10);
          setHudNotice("-10s");
        } else if (clickX > width * 0.55) {
          v.currentTime = Math.min(duration || 999999, v.currentTime + 10);
          setHudNotice("+10s");
        } else {
          handleTogglePlay();
          return;
        }
        setTimeout(() => setHudNotice(""), 800);
      };

      // 5. Persistent PiP with Zero Lingering Player (Restores smoothly on Enlarge)
      const [isPipMode, setIsPipMode] = useState(false);

      useEffect(() => {
        const v = videoRef.current;
        if (!v) return;
        const handleEnterPip = () => {
          setIsPipMode(true);
        };
        const handleLeavePip = () => {
          setIsPipMode(false);
        };
        v.addEventListener("enterpictureinpicture", handleEnterPip);
        v.addEventListener("leavepictureinpicture", handleLeavePip);
        return () => {
          v.removeEventListener("enterpictureinpicture", handleEnterPip);
          v.removeEventListener("leavepictureinpicture", handleLeavePip);
        };
      }, []);

      const handleTogglePip = async () => {
        const v = videoRef.current;
        if (!v) return;
        if (document.pictureInPictureElement) {
          try {
            await document.exitPictureInPicture();
          } catch (e) {}
          setIsPipMode(false);
          return;
        }
        if (document.pictureInPictureEnabled && typeof v.requestPictureInPicture === "function") {
          try {
            await v.requestPictureInPicture();
            setIsPipMode(true);
          } catch (err) {
            console.warn("[SFM Player] Native PiP request error:", err);
          }
        }
      };

      // Toggle Shuffle Queue (Randomize without repeats)
      const handleToggleShuffle = useCallback(() => {
        setIsShuffle((prev) => {
          const next = !prev;
          try {
            window.localStorage.setItem("sfm_player_shuffle", next ? "true" : "false");
          } catch (e) {}
          if (next) {
            const q = createShuffledQueue(scenes, scene);
            setShuffledQueue(q);
            setHudNotice("Shuffle: ON");
          } else {
            setShuffledQueue([]);
            setHudNotice("Sequential");
          }
          setTimeout(() => setHudNotice(""), 1000);
          return next;
        });
      }, [scenes, scene]);

      // Fullscreen Toggle (targets workspace root / documentElement so controls, modals, and profile views remain interactive)
      const handleToggleFullscreen = () => {
        if (!document.fullscreenElement) {
          const el = document.getElementById("sfm-workspace-root") || document.documentElement;
          if (el && el.requestFullscreen) {
            el.requestFullscreen().catch(() => {});
          }
        } else {
          document.exitFullscreen().catch(() => {});
        }
      };

      // Copy Stream Link
      const handleCopyStreamLink = () => {
        const fullUrl = streamUrl.startsWith("http") ? streamUrl : `${window.location.origin}${streamUrl}`;
        navigator.clipboard.writeText(fullUrl).then(() => {
          setCopiedNotice("Stream URL copied to clipboard!");
          setTimeout(() => setCopiedNotice(""), 2500);
        });
      };

      const vlcUrl = `vlc://${window.location.origin}${directUrl}`;

      // 6. Binge-Style Vertical Reel Scrolling & Physics
      const [pullOffset, setPullOffset] = useState(0);
      const [isTransitioning, setIsTransitioning] = useState(false);
      const isTransitioningRef = useRef(false);
      const lastWheelTime = useRef(0);
      const touchStartRef = useRef(null);
      const touchSamplesRef = useRef([]);
      const isSwipingGesture = useRef(false);

      // Smooth programmatic / physics transition to relative offset step (-2, -1, 0, 1, 2)
      const executeTransition = useCallback((steps, targetScene) => {
        const containerHeight = videoContainerRef.current?.clientHeight || window.innerHeight || 800;
        isTransitioningRef.current = true;
        setIsTransitioning(true);
        setPullOffset(-steps * containerHeight);

        const duration = steps === 0 ? 180 : 260;
        setTimeout(() => {
          if (steps !== 0 && targetScene) {
            onSelectScene(targetScene);
          }
          setPullOffset(0);
          isTransitioningRef.current = false;
          setIsTransitioning(false);
        }, duration);
      }, [onSelectScene]);

      const goToPrev = useCallback(() => {
        if (hasPrev && !isTransitioningRef.current) executeTransition(-1, prevScene);
      }, [hasPrev, prevScene, executeTransition]);

      const goToNext = useCallback(() => {
        if (hasNext && !isTransitioningRef.current) executeTransition(1, nextScene);
      }, [hasNext, nextScene, executeTransition]);

      const goToPrev2 = useCallback(() => {
        if (hasPrev2 && !isTransitioningRef.current) executeTransition(-2, prev2Scene);
      }, [hasPrev2, prev2Scene, executeTransition]);

      const goToNext2 = useCallback(() => {
        if (hasNext2 && !isTransitioningRef.current) executeTransition(2, next2Scene);
      }, [hasNext2, next2Scene, executeTransition]);

      // Wheel / Trackpad Gesture Handler matching Binge logic and parameters
      const handleWheel = (e) => {
        e.preventDefault();
        const delta = e.deltaY;
        if (Math.abs(delta) < 28) return; // filter micro jitter

        const now = Date.now();
        if (now - lastWheelTime.current < 320) return; // cooldown during slide transition

        // Instant Binge response: fast/strong wipe jumps 2 scenes, standard advances 1
        if (delta > 0) {
          if ((delta > 200 || e.deltaMode === 1) && hasNext2) {
            lastWheelTime.current = now;
            goToNext2();
          } else if (hasNext) {
            lastWheelTime.current = now;
            goToNext();
          }
        } else if (delta < 0) {
          if ((delta < -200 || e.deltaMode === 1) && hasPrev2) {
            lastWheelTime.current = now;
            goToPrev2();
          } else if (hasPrev) {
            lastWheelTime.current = now;
            goToPrev();
          }
        }
      };

      // Touch Swipe Gesture Handlers (supporting multi-video flick momentum)
      const handleTouchStart = (e) => {
        resetControlsTimer();
        if (isTransitioningRef.current || !e.touches || e.touches.length === 0) return;
        const touch = e.touches[0];
        isSwipingGesture.current = false;
        touchStartRef.current = {
          y: touch.clientY,
          time: Date.now(),
          initialOffset: pullOffset,
        };
        touchSamplesRef.current = [{ y: touch.clientY, t: Date.now() }];
      };

      const handleTouchMove = (e) => {
        if (!touchStartRef.current || isTransitioningRef.current || !e.touches || e.touches.length === 0) return;
        const touch = e.touches[0];
        const deltaY = touch.clientY - touchStartRef.current.y;
        if (Math.abs(deltaY) > 8) isSwipingGesture.current = true;

        const containerHeight = videoContainerRef.current?.clientHeight || window.innerHeight || 800;
        const maxForward = (hasNext2 ? 2 : hasNext ? 1 : 0) * containerHeight;
        const maxBackward = (hasPrev2 ? 2 : hasPrev ? 1 : 0) * containerHeight;

        let newOffset = touchStartRef.current.initialOffset + deltaY;
        if (newOffset < -maxForward) {
          newOffset = -maxForward - (Math.abs(newOffset) - maxForward) * 0.15;
        } else if (newOffset > maxBackward) {
          newOffset = maxBackward + (newOffset - maxBackward) * 0.15;
        }
        setPullOffset(newOffset);

        const now = Date.now();
        touchSamplesRef.current.push({ y: touch.clientY, t: now });
        if (touchSamplesRef.current.length > 6) touchSamplesRef.current.shift();
      };

      const handleTouchEnd = () => {
        if (!touchStartRef.current || isTransitioningRef.current) {
          touchStartRef.current = null;
          return;
        }

        const containerHeight = videoContainerRef.current?.clientHeight || window.innerHeight || 800;
        const samples = touchSamplesRef.current;
        let vy = 0;
        if (samples.length >= 2) {
          const first = samples[0];
          const last = samples[samples.length - 1];
          const dt = Math.max(1, last.t - first.t);
          vy = (last.y - first.y) / dt; // px/ms
        }

        const deltaY = pullOffset;
        if (deltaY < -containerHeight * 1.05 || (deltaY < -containerHeight * 0.35 && vy < -0.65)) {
          if (hasNext2) {
            executeTransition(2, next2Scene);
          } else if (hasNext) {
            executeTransition(1, nextScene);
          } else {
            executeTransition(0, null);
          }
        } else if (deltaY < -containerHeight * 0.2 || vy < -0.25) {
          if (hasNext) {
            executeTransition(1, nextScene);
          } else {
            executeTransition(0, null);
          }
        } else if (deltaY > containerHeight * 1.05 || (deltaY > containerHeight * 0.35 && vy > 0.65)) {
          if (hasPrev2) {
            executeTransition(-2, prev2Scene);
          } else if (hasPrev) {
            executeTransition(-1, prevScene);
          } else {
            executeTransition(0, null);
          }
        } else if (deltaY > containerHeight * 0.2 || vy > 0.25) {
          if (hasPrev) {
            executeTransition(-1, prevScene);
          } else {
            executeTransition(0, null);
          }
        } else {
          executeTransition(0, null);
        }

        touchStartRef.current = null;
        touchSamplesRef.current = [];
      };

      // Keyboard Controls (Left/Right Arrow key Rewind & Fast Forward, Instant Escape Exit)
      useEffect(() => {
        const handleKeyDown = (e) => {
          if (["input", "textarea", "select"].includes(e.target.tagName?.toLowerCase())) return;

          // Rewind 10s: Left Arrow, J, or external mobile controller / HID media keys
          if (
            e.key === "ArrowLeft" || e.key === "Left" ||
            e.key === "j" || e.key === "J" ||
            e.code === "ArrowLeft" || e.keyCode === 37 || e.which === 37 ||
            e.key === "MediaTrackPrevious" || e.key === "MediaRewind" || e.key === "PageLeft"
          ) {
            e.preventDefault();
            e.stopPropagation();
            handleSeekBy(-10);
            return;
          }
          // Fast Forward 10s: Right Arrow, L, or external mobile controller / HID media keys
          if (
            e.key === "ArrowRight" || e.key === "Right" ||
            e.key === "l" || e.key === "L" ||
            e.code === "ArrowRight" || e.keyCode === 39 || e.which === 39 ||
            e.key === "MediaTrackNext" || e.key === "MediaFastForward" || e.key === "PageRight"
          ) {
            e.preventDefault();
            e.stopPropagation();
            handleSeekBy(10);
            return;
          }

          if (showFolderProfile) {
            if (e.key === "Escape") {
              e.preventDefault();
              setShowFolderProfile(false);
              const curDepth = (window.history.state && typeof window.history.state.sfmDepth === "number") ? window.history.state.sfmDepth : 0;
              if (curDepth > 1 && window.location.hash.includes("view=")) {
                window.history.back();
              } else {
                const targetHash = buildHashForPath(targetFolderPath, null, scene?.id);
                if (window.location.hash !== targetHash) {
                  window.history.replaceState({ sfmPath: targetFolderPath, sfmScene: scene?.id, sfmDepth: Math.max(1, curDepth) }, "", targetHash);
                }
              }
            }
            return; // In profile/discover overlay, yield remaining keys to profile view
          }

          if (e.key === "Escape") {
            if (isPipMode && document.pictureInPictureElement) {
              document.exitPictureInPicture().catch(() => {});
            }
            onClose();
            return;
          } else if (
            e.key === "ArrowDown" || e.key === "Down" ||
            e.key === "PageDown" || e.code === "ArrowDown" ||
            e.keyCode === 40 || e.which === 40
          ) {
            e.preventDefault();
            goToNext();
          } else if (
            e.key === "ArrowUp" || e.key === "Up" ||
            e.key === "PageUp" || e.code === "ArrowUp" ||
            e.keyCode === 38 || e.which === 38
          ) {
            e.preventDefault();
            goToPrev();
          } else if (
            e.key === " " || e.key === "k" || e.key === "K" ||
            e.key === "MediaPlayPause" || e.keyCode === 32 || e.keyCode === 179
          ) {
            e.preventDefault();
            handleTogglePlay();
          } else if (e.key === "f" || e.key === "F") {
            e.preventDefault();
            handleToggleFullscreen();
          } else if (e.key === "p" || e.key === "P") {
            e.preventDefault();
            handleTogglePip();
          } else if (e.key === "s" || e.key === "S") {
            e.preventDefault();
            handleToggleShuffle();
          }
        };

        window.addEventListener("keydown", handleKeyDown, { capture: true });
        return () => window.removeEventListener("keydown", handleKeyDown, { capture: true });
      }, [onClose, goToNext, goToPrev, handleTogglePlay, handleToggleShuffle, handleSeekBy, isPipMode, showFolderProfile]);

            // External Controller / Bluetooth Gamepad API polling loop
      useEffect(() => {
        let animId = null;
        let lastActionTime = 0;
        const DEADZONE = 0.45;
        const COOLDOWN_MS = 250;

        const pollGamepad = () => {
          if (typeof navigator !== "undefined" && typeof navigator.getGamepads === "function") {
            const gamepads = navigator.getGamepads();
            for (let i = 0; i < gamepads.length; i++) {
              const gp = gamepads[i];
              if (!gp || !gp.connected) continue;

              const now = Date.now();
              if (now - lastActionTime < COOLDOWN_MS) continue;

              const b = gp.buttons;
              const a = gp.axes;

              // D-Pad Up (12) or Left Stick Up (axes[1] < -0.45)
              if ((b[12] && b[12].pressed) || (a[1] !== undefined && a[1] < -DEADZONE)) {
                lastActionTime = now;
                goToPrev();
                break;
              }
              // D-Pad Down (13) or Left Stick Down (axes[1] > 0.45)
              if ((b[13] && b[13].pressed) || (a[1] !== undefined && a[1] > DEADZONE)) {
                lastActionTime = now;
                goToNext();
                break;
              }
              // D-Pad Left (14) or Left Stick Left (axes[0] < -0.45) or LB / L1 (4)
              if ((b[14] && b[14].pressed) || (a[0] !== undefined && a[0] < -DEADZONE) || (b[4] && b[4].pressed)) {
                lastActionTime = now;
                handleSeekBy(-10);
                break;
              }
              // D-Pad Right (15) or Left Stick Right (axes[0] > 0.45) or RB / R1 (5)
              if ((b[15] && b[15].pressed) || (a[0] !== undefined && a[0] > DEADZONE) || (b[5] && b[5].pressed)) {
                lastActionTime = now;
                handleSeekBy(10);
                break;
              }
              // Button 0 (A / Cross) -> Play/Pause
              if (b[0] && b[0].pressed) {
                lastActionTime = now;
                handleTogglePlay();
                break;
              }
              // Button 1 (B / Circle) -> Close
              if (b[1] && b[1].pressed) {
                lastActionTime = now;
                onClose();
                break;
              }
            }
          }
          if (typeof window !== "undefined" && typeof window.requestAnimationFrame === "function") animId = window.requestAnimationFrame(pollGamepad);
        };

        if (typeof window !== "undefined" && typeof window.requestAnimationFrame === "function") animId = window.requestAnimationFrame(pollGamepad);
        return () => {
          if (animId && typeof window !== "undefined" && typeof window.cancelAnimationFrame === "function") window.cancelAnimationFrame(animId);
        };
      }, [goToNext, goToPrev, handleSeekBy, handleTogglePlay, onClose]);

      // Formatted duration helper
      const formatTime = (secs) => {
        if (!secs || isNaN(secs) || secs < 0) return "0:00";
        const m = Math.floor(secs / 60);
        const s = Math.floor(secs % 60);
        return `${m}:${s < 10 ? "0" : ""}${s}`;
      };

      // Render Active Player Modal or PiP Background Mode
      return React.createElement(
        React.Fragment,
        null,
        // Folder Profile Video Wall Overlay
        showFolderProfile &&
          React.createElement(FolderProfileView, {
            folderName: subfolderName,
            targetFolderPath: targetFolderPath,
            displayFolderPath: displayFolderPath,
            scenes: folderProfileScenes,
            currentScene: scene,
            posterUrl: posterUrl,
            isForceMobile: isForceMobile,
            isInsidePlayer: true,
            onToggleForceMobile: handleToggleForceMobile,
            onSelectScene: (s, q) => {
              if (onSelectScene) {
                onSelectScene(s, q);
              }
              setShowFolderProfile(false);
            },
            onCloseProfile: () => {
              setShowFolderProfile(false);
              const curDepth = (window.history.state && typeof window.history.state.sfmDepth === "number") ? window.history.state.sfmDepth : 0;
              if (curDepth > 1 && window.location.hash.includes("view=")) {
                window.history.back();
              } else {
                const targetHash = buildHashForPath(targetFolderPath, null, scene?.id);
                if (window.location.hash !== targetHash) {
                  window.history.replaceState({ sfmPath: targetFolderPath, sfmScene: scene?.id, sfmDepth: Math.max(1, curDepth) }, "", targetHash);
                }
              }
            },
            onNavigateToDirectory: (fPath) => {
              const dest = fPath !== undefined ? fPath : targetFolderPath;
              if (onNavigateToFolder) {
                onNavigateToFolder(dest);
              }
              onClose();
            },
            onPlayAll: (q) => {
              const list = Array.isArray(q) && q.length > 0 ? q : folderProfileScenes;
              if (list.length > 0) {
                onSelectScene(list[0]);
                setShowFolderProfile(false);
              }
            },
            onShuffleAll: (q) => {
              const list = Array.isArray(q) && q.length > 0 ? q : folderProfileScenes;
              if (list.length > 0) {
                const shuffled = createShuffledQueue(list, list[0]);
                setShuffledQueue(shuffled);
                setIsShuffle(true);
                onSelectScene(shuffled[0]);
                setShowFolderProfile(false);
              }
            },
          }),

        // When in PiP mode, show small non-intrusive floating dock pill
        isPipMode &&
          React.createElement(
            "div",
            {
              className: "sfm-pip-return-pill shadow-lg",
              onClick: async (e) => {
                e.stopPropagation();
                if (document.pictureInPictureElement) {
                  try {
                    await document.exitPictureInPicture();
                  } catch (err) {}
                }
                setIsPipMode(false);
              },
              title: "Click to return video to player",
            },
            React.createElement(
              "svg",
              { viewBox: "0 0 24 24", width: 14, height: 14, stroke: "currentColor", strokeWidth: "2", fill: "none", className: "mr-2" },
              React.createElement("rect", { x: "2", y: "4", width: "20", height: "16", rx: "2" }),
              React.createElement("rect", { x: "13", y: "11", width: "7", height: "6", rx: "1", fill: "currentColor" })
            ),
            React.createElement("span", { className: "sfm-pip-pill-title" }, `Playing: ${title}`),
            React.createElement("span", { className: "sfm-pip-pill-action ml-2" }, "(Click to Enlarge)"),
            React.createElement(
              "button",
              {
                className: "sfm-pip-pill-close ml-2",
                onClick: (e) => {
                  e.stopPropagation();
                  if (document.pictureInPictureElement) {
                    document.exitPictureInPicture().catch(() => {});
                  }
                  onClose();
                },
                title: "Stop playback and close",
              },
              "✕"
            )
          ),

        // Main Player Modal Backdrop (Hidden when showFolderProfile is true so profile overlay is completely visible and interactable!)
        React.createElement(
          "div",
          {
            className: `sfm-reel-modal-backdrop ${isPipMode ? "sfm-pip-detached" : ""}`,
            style: showFolderProfile ? { display: "none" } : undefined,
            onClick: onClose,
            onMouseMove: resetControlsTimer,
            onTouchStart: resetControlsTimer,
          },
          React.createElement(
            "div",
            {
              className: `sfm-reel-modal-dialog ${isPipMode ? "sfm-pip-dialog-detached" : ""} ${isForceMobile ? "sfm-reel-mobile-frame" : ""}`,
              onClick: (e) => e.stopPropagation(),
              onWheel: handleWheel,
              onTouchStart: handleTouchStart,
              onTouchMove: handleTouchMove,
              onTouchEnd: handleTouchEnd,
            },
            // Main Video Container with Seamless Reel Track
            React.createElement(
              "div",
              {
                ref: videoContainerRef,
                className: "sfm-reel-video-container",
                onMouseMove: resetControlsTimer,
              },
              // Seamless Vertical Track holding Adjacent Slides (Sliding Window ±2)
              React.createElement(
                "div",
                {
                  className: "sfm-reel-track",
                  style: {
                    transform: `translateY(${pullOffset}px)`,
                    transition: isTransitioning
                      ? "transform 0.3s cubic-bezier(0.16, 1, 0.3, 1)"
                      : "none",
                  },
                },
                // Slide -2: Scene currentIndex - 2 (Above -200%)
                hasPrev2 &&
                  React.createElement(
                    "div",
                    { className: "sfm-reel-slide sfm-reel-slide-prev2" },
                    React.createElement("img", {
                      src: prev2Scene?.paths?.screenshot || `/scene/${prev2Scene?.id}/screenshot`,
                      className: "sfm-reel-slide-poster",
                      alt: "",
                      loading: "eager",
                    }),
                    prev2StreamUrl &&
                      React.createElement("video", {
                        key: `prev2-vid-${prev2Scene.id}`,
                        src: prev2StreamUrl,
                        className: "sfm-reel-adjacent-video",
                        preload: "auto",
                        muted: true,
                        playsInline: true,
                        controls: false,
                      })
                  ),

                // Slide -1: Scene currentIndex - 1 (Above -100%)
                hasPrev &&
                  React.createElement(
                    "div",
                    { className: "sfm-reel-slide sfm-reel-slide-prev" },
                    React.createElement("img", {
                      src: prevScene?.paths?.screenshot || `/scene/${prevScene?.id}/screenshot`,
                      className: "sfm-reel-slide-poster",
                      alt: "",
                      loading: "eager",
                    }),
                    prevStreamUrl &&
                      React.createElement("video", {
                        key: `prev-vid-${prevScene.id}`,
                        src: prevStreamUrl,
                        className: "sfm-reel-adjacent-video",
                        preload: "auto",
                        muted: true,
                        playsInline: true,
                        controls: false,
                      })
                  ),

                // Slide 0: Current Active Video (playing)
                React.createElement(
                  "div",
                  { className: "sfm-reel-slide sfm-reel-slide-active" },
                  showSlowLoadPoster &&
                    React.createElement("img", {
                      src: posterUrl,
                      className: `sfm-reel-live-poster ${isVideoReady ? "sfm-poster-faded" : ""}`,
                      alt: "",
                    }),
                  React.createElement("div", {
                    className: "sfm-video-gesture-overlay",
                    onClick: handleGestureClick,
                    onDoubleClick: handleDoubleTapSeek,
                    title: "Double-click sides to seek ±10s · Single click to toggle Play/Pause",
                  }),
                  React.createElement("video", {
                    ref: videoRef,
                    controls: false,
                    playsInline: true,
                    preload: "auto",
                    className: "sfm-reel-video-element",
                    onError: handleVideoError,
                    onTimeUpdate: handleTimeUpdate,
                    onLoadedMetadata: handleLoadedMetadata,
                    onLoadedData: () => setIsVideoReady(true),
                    onPlaying: () => {
                      setIsPlaying(true);
                      setIsVideoReady(true);
                    },
                    onPause: () => setIsPlaying(false),
                    onEnded: () => {
                      if (hasNext && !isTransitioningRef.current) {
                        goToNext();
                      }
                    },
                  })
                ),

                // Slide +1: Scene currentIndex + 1 (Below +100%)
                hasNext &&
                  React.createElement(
                    "div",
                    { className: "sfm-reel-slide sfm-reel-slide-next" },
                    React.createElement("img", {
                      src: nextScene?.paths?.screenshot || `/scene/${nextScene?.id}/screenshot`,
                      className: "sfm-reel-slide-poster",
                      alt: "",
                      loading: "eager",
                    }),
                    nextStreamUrl &&
                      React.createElement("video", {
                        key: `next-vid-${nextScene.id}`,
                        src: nextStreamUrl,
                        className: "sfm-reel-adjacent-video",
                        preload: "auto",
                        muted: true,
                        playsInline: true,
                        controls: false,
                      })
                  ),

                // Slide +2: Scene currentIndex + 2 (Below +200%)
                hasNext2 &&
                  React.createElement(
                    "div",
                    { className: "sfm-reel-slide sfm-reel-slide-next2" },
                    React.createElement("img", {
                      src: next2Scene?.paths?.screenshot || `/scene/${next2Scene?.id}/screenshot`,
                      className: "sfm-reel-slide-poster",
                      alt: "",
                      loading: "eager",
                    }),
                    next2StreamUrl &&
                      React.createElement("video", {
                        key: `next2-vid-${next2Scene.id}`,
                        src: next2StreamUrl,
                        className: "sfm-reel-adjacent-video",
                        preload: "auto",
                        muted: true,
                        playsInline: true,
                        controls: false,
                      })
                  )
              ),

              // On-screen animated HUD feedback badge (e.g. ±10s seek) with sleek vector chevrons
              hudNotice &&
                React.createElement(
                  "div",
                  { className: "sfm-player-hud" },
                  React.createElement(
                    "div",
                    { className: "sfm-hud-pill d-flex align-items-center gap-1" },
                    hudNotice.startsWith("-")
                      ? React.createElement(
                          "svg",
                          { viewBox: "0 0 24 24", width: 14, height: 14, stroke: "currentColor", strokeWidth: "2.5", fill: "none" },
                          React.createElement("polyline", { points: "11 19 2 12 11 5" }),
                          React.createElement("polyline", { points: "22 19 13 12 22 5" })
                        )
                      : React.createElement(
                          "svg",
                          { viewBox: "0 0 24 24", width: 14, height: 14, stroke: "currentColor", strokeWidth: "2.5", fill: "none" },
                          React.createElement("polyline", { points: "13 19 22 12 13 5" }),
                          React.createElement("polyline", { points: "2 19 11 12 2 5" })
                        ),
                    React.createElement("span", null, hudNotice)
                  )
                ),

              // Status Notices with Clean Inline Vector SVGs
              (copiedNotice || playerNotice || playerError) &&
                React.createElement(
                  "div",
                  { className: "sfm-reel-top-notices" },
                  copiedNotice &&
                    React.createElement(
                      "div",
                      { className: "alert alert-success py-1 px-3 mb-1 small d-flex align-items-center gap-2" },
                      React.createElement(
                        "svg",
                        { viewBox: "0 0 24 24", width: 14, height: 14, stroke: "currentColor", strokeWidth: "2.5", fill: "none" },
                        React.createElement("polyline", { points: "20 6 9 17 4 12" })
                      ),
                      copiedNotice
                    ),
                  playerNotice &&
                    React.createElement(
                      "div",
                      { className: "alert alert-warning py-1 px-3 mb-1 small d-flex align-items-center gap-2" },
                      React.createElement(
                        "svg",
                        { viewBox: "0 0 24 24", width: 14, height: 14, stroke: "currentColor", strokeWidth: "2", fill: "none" },
                        React.createElement("circle", { cx: "12", cy: "12", r: "10" }),
                        React.createElement("line", { x1: "12", y1: "16", x2: "12", y2: "12" }),
                        React.createElement("line", { x1: "12", y1: "8", x2: "12.01", y2: "8" })
                      ),
                      playerNotice
                    ),
                  playerError &&
                    React.createElement(
                      "div",
                      { className: "alert alert-danger py-1 px-3 mb-1 small d-flex align-items-center gap-2" },
                      React.createElement(
                        "svg",
                        { viewBox: "0 0 24 24", width: 14, height: 14, stroke: "currentColor", strokeWidth: "2", fill: "none" },
                        React.createElement("path", { d: "M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" }),
                        React.createElement("line", { x1: "12", y1: "9", x2: "12", y2: "13" }),
                        React.createElement("line", { x1: "12", y1: "17", x2: "12.01", y2: "17" })
                      ),
                      playerError
                    )
                ),

              // ==========================================
              // Right-Side Clean Vector Action Bar
              // Monochrome sleek SVG vector icons (Theme consistent, no colorful emojis)
              // No divider under Close button; Fullscreen & PiP moved down
              // ==========================================
              React.createElement(
                "div",
                {
                  className: `sfm-reel-actions-column ${isControlsVisible ? "sfm-visible" : "sfm-hidden"}`,
                  onClick: (e) => e.stopPropagation(),
                },
                // 1. Close Player Button (Aligned at top of circular column)
                React.createElement(
                  "button",
                  {
                    className: "sfm-reel-circle-btn sfm-reel-close-circle-btn",
                    onClick: onClose,
                    title: "Close Player (Esc)",
                  },
                  React.createElement(
                    "svg",
                    { viewBox: "0 0 24 24", width: 16, height: 16, stroke: "currentColor", strokeWidth: "2.5", fill: "none" },
                    React.createElement("line", { x1: "18", y1: "6", x2: "6", y2: "18" }),
                    React.createElement("line", { x1: "6", y1: "6", x2: "18", y2: "18" })
                  )
                ),

                // 2. Stash Scene Details (Directly under close button without divider)
                React.createElement(
                  "a",
                  {
                    href: `/scenes/${scene.id}`,
                    target: "_blank",
                    rel: "noreferrer",
                    className: "sfm-reel-circle-btn",
                    title: "Open Scene Details in Stash",
                  },
                  React.createElement(
                    "svg",
                    { viewBox: "0 0 24 24", width: 16, height: 16, stroke: "currentColor", strokeWidth: "2.2", fill: "none" },
                    React.createElement("path", { d: "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" }),
                    React.createElement("polyline", { points: "15 3 21 3 21 9" }),
                    React.createElement("line", { x1: "10", y1: "14", x2: "21", y2: "3" })
                  )
                ),
                // 3. Open Stream in VLC
                React.createElement(
                  "a",
                  {
                    href: vlcUrl,
                    className: "sfm-reel-circle-btn sfm-btn-vlc",
                    title: "Open Stream in VLC Media Player",
                  },
                  React.createElement(
                    "svg",
                    { viewBox: "0 0 24 24", width: 16, height: 16, fill: "currentColor" },
                    React.createElement("path", { d: "M11 2.5a1.2 1.2 0 0 1 2 0l1.5 4.5h-5zM8.8 8.5h6.4l1.1 3.5H7.7zM6.8 13.5h10.4l1.3 4H5.5zM3.5 19.5a1 1 0 0 1 1-1h15a1 1 0 0 1 1 1v1a1 1 0 0 1-1 1h-15a1 1 0 0 1-1-1z" })
                  )
                ),
                // 4. Copy Link
                React.createElement(
                  "button",
                  {
                    className: "sfm-reel-circle-btn",
                    onClick: handleCopyStreamLink,
                    title: "Copy Stream URL to Clipboard",
                  },
                  React.createElement(
                    "svg",
                    { viewBox: "0 0 24 24", width: 16, height: 16, stroke: "currentColor", strokeWidth: "2", fill: "none" },
                    React.createElement("path", { d: "M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" }),
                    React.createElement("path", { d: "M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" })
                  )
                ),
                // 5. Transcode Dropdown Selector (Codec Processor Chip Vector Icon)
                React.createElement(
                  "div",
                  { className: "sfm-reel-transcode-wrap" },
                  React.createElement(
                    "button",
                    {
                      className: `sfm-reel-circle-btn ${streamMode !== "direct" ? "sfm-transcode-active" : ""}`,
                      onClick: () => setShowTranscodeMenu((prev) => !prev),
                      title: `Stream Codec Engine (${streamMode.toUpperCase()}) — Click to change profile`,
                    },
                    React.createElement(
                      "svg",
                      { viewBox: "0 0 24 24", width: 16, height: 16, stroke: "currentColor", strokeWidth: "2", fill: "none" },
                      React.createElement("rect", { x: "4", y: "4", width: "16", height: "16", rx: "2" }),
                      React.createElement("polygon", { points: "10 8 16 12 10 16 10 8", fill: "currentColor", stroke: "none" }),
                      React.createElement("line", { x1: "8", y1: "1", x2: "8", y2: "4" }),
                      React.createElement("line", { x1: "12", y1: "1", x2: "12", y2: "4" }),
                      React.createElement("line", { x1: "16", y1: "1", x2: "16", y2: "4" }),
                      React.createElement("line", { x1: "8", y1: "20", x2: "8", y2: "23" }),
                      React.createElement("line", { x1: "12", y1: "20", x2: "12", y2: "23" }),
                      React.createElement("line", { x1: "16", y1: "20", x2: "16", y2: "23" }),
                      React.createElement("line", { x1: "1", y1: "8", x2: "4", y2: "8" }),
                      React.createElement("line", { x1: "1", y1: "12", x2: "4", y2: "12" }),
                      React.createElement("line", { x1: "1", y1: "16", x2: "4", y2: "16" }),
                      React.createElement("line", { x1: "20", y1: "8", x2: "23", y2: "8" }),
                      React.createElement("line", { x1: "20", y1: "12", x2: "23", y2: "12" }),
                      React.createElement("line", { x1: "20", y1: "16", x2: "23", y2: "16" })
                    )
                  ),
                  showTranscodeMenu &&
                    React.createElement(
                      "div",
                      { className: "sfm-reel-transcode-menu" },
                      React.createElement(
                        "button",
                        {
                          className: `sfm-menu-item ${streamMode === "direct" && !customStreamUrl ? "active" : ""}`,
                          onClick: () => {
                            setCustomStreamUrl("");
                            setStreamMode("direct");
                            setShowTranscodeMenu(false);
                          },
                        },
                        "Direct Stream (Raw File)"
                      ),
                      React.createElement(
                        "button",
                        {
                          className: `sfm-menu-item ${streamMode === "hls" && !customStreamUrl ? "active" : ""}`,
                          onClick: () => {
                            setCustomStreamUrl("");
                            setStreamMode("hls");
                            setShowTranscodeMenu(false);
                          },
                        },
                        "HLS Stream (Adaptive)"
                      ),
                      React.createElement(
                        "button",
                        {
                          className: `sfm-menu-item ${streamMode === "webm" && !customStreamUrl ? "active" : ""}`,
                          onClick: () => {
                            setCustomStreamUrl("");
                            setStreamMode("webm");
                            setShowTranscodeMenu(false);
                          },
                        },
                        "WebM Transcode"
                      ),
                      React.createElement(
                        "button",
                        {
                          className: `sfm-menu-item ${streamMode === "mp4" && !customStreamUrl ? "active" : ""}`,
                          onClick: () => {
                            setCustomStreamUrl("");
                            setStreamMode("mp4");
                            setShowTranscodeMenu(false);
                          },
                        },
                        "MP4 Transcode"
                      ),
                      availableStreams.filter((s) => !s.url.includes("stream.webm") && !s.url.includes("stream.m3u8") && !s.url.includes("stream.mp4")).map((s, idx) =>
                        React.createElement(
                          "button",
                          {
                            key: `custom-${idx}`,
                            className: `sfm-menu-item ${customStreamUrl === s.url ? "active" : ""}`,
                            onClick: () => {
                              setCustomStreamUrl(s.url);
                              setShowTranscodeMenu(false);
                            },
                          },
                          s.label || (s.mime_type ? s.mime_type.split("/")[1].toUpperCase() : `Custom #${idx + 1}`)
                        )
                      )
                    )
                ),

                // Divider 1: Above Prev/Next Video Button (Doubled Spacing)
                React.createElement("div", { className: "sfm-reel-action-divider" }),

                // 6. Previous Video Button
                React.createElement(
                  "button",
                  {
                    className: "sfm-reel-circle-btn",
                    onClick: goToPrev,
                    disabled: !hasPrev,
                    title: hasPrev ? `Previous: ${prevScene?.title || `Scene #${prevScene?.id}`}` : "First scene in folder",
                  },
                  React.createElement(
                    "svg",
                    { viewBox: "0 0 24 24", width: 16, height: 16, stroke: "currentColor", strokeWidth: "2.5", fill: "none" },
                    React.createElement("polyline", { points: "18 15 12 9 6 15" })
                  )
                ),
                // 7. Reel Counter Pill
                React.createElement(
                  "div",
                  {
                    className: `sfm-reel-counter-badge ${isShuffle ? "sfm-counter-shuffled" : ""}`,
                    title: isShuffle
                      ? `Shuffled Queue (${currentIndex + 1}/${totalScenes}) — Folder: ${folderName || "Current"}`
                      : `Folder: ${folderName || "Current"}`,
                  },
                  isShuffle ? `[Shuffle] ${currentIndex + 1}/${totalScenes}` : `${currentIndex + 1}/${totalScenes}`
                ),
                // 8. Next Video Button
                React.createElement(
                  "button",
                  {
                    className: "sfm-reel-circle-btn",
                    onClick: goToNext,
                    disabled: !hasNext,
                    title: hasNext
                      ? `Next: ${nextScene?.title || `Scene #${nextScene?.id}`}`
                      : (isShuffle ? "End of shuffled queue" : "Last scene in folder"),
                  },
                  React.createElement(
                    "svg",
                    { viewBox: "0 0 24 24", width: 16, height: 16, stroke: "currentColor", strokeWidth: "2.5", fill: "none" },
                    React.createElement("polyline", { points: "6 9 12 15 18 9" })
                  )
                ),
                // 9. Shuffle Queue Toggle Button (Randomize without repeats)
                React.createElement(
                  "button",
                  {
                    type: "button",
                    className: `sfm-reel-circle-btn sfm-btn-shuffle ${isShuffle ? "sfm-shuffle-active" : ""}`,
                    onClick: handleToggleShuffle,
                    disabled: totalScenes <= 1,
                    title: isShuffle
                      ? `Shuffle: ON (randomized without repeats) — Click to disable (S)`
                      : `Shuffle: OFF (sequential folder order) — Click to randomize without repeats (S)`,
                  },
                  React.createElement(IconShuffle, { size: 16 })
                ),
                // Toggle Mobile Phone / Desktop View
                React.createElement(
                  "button",
                  {
                    type: "button",
                    className: `sfm-reel-circle-btn ${isForceMobile ? "sfm-btn-mobile-active" : ""}`,
                    onClick: handleToggleForceMobile,
                    title: isForceMobile ? "Switch to Fullscreen Desktop Player" : "Switch to Mobile Phone Reel View (TikTok/IG)",
                  },
                  React.createElement(IconSmartphone, { size: 15 })
                ),

                // Bottom actions group: Pushed down so Fullscreen is directly above the scrubbing line
                React.createElement(
                  "div",
                  { className: "sfm-reel-bottom-actions" },
                  // Divider 2: Restored Above PiP Button (Doubled Spacing)
                  React.createElement("div", { className: "sfm-reel-action-divider" }),
                  // 9. Picture-in-Picture Button
                  React.createElement(
                    "button",
                    {
                      className: `sfm-reel-circle-btn ${isPipMode ? "sfm-btn-pip-active" : ""}`,
                      onClick: handleTogglePip,
                      title: "Switch to Picture-in-Picture (P)",
                    },
                    React.createElement(
                      "svg",
                      { viewBox: "0 0 24 24", width: 16, height: 16, stroke: "currentColor", strokeWidth: "2", fill: "none" },
                      React.createElement("rect", { x: "2", y: "4", width: "20", height: "16", rx: "2" }),
                      React.createElement("rect", { x: "13", y: "11", width: "7", height: "6", rx: "1", fill: "currentColor" })
                    )
                  ),
                  // 10. Fullscreen Button
                  React.createElement(
                    "button",
                    {
                      className: "sfm-reel-circle-btn",
                      onClick: handleToggleFullscreen,
                      title: "Toggle Fullscreen (F)",
                    },
                    React.createElement(
                      "svg",
                      { viewBox: "0 0 24 24", width: 16, height: 16, stroke: "currentColor", strokeWidth: "2.2", fill: "none" },
                      React.createElement("path", { d: "M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3" })
                    )
                  )
                )
              ),

              // ==========================================
              // Elevated Metadata Overlay:
              // Line 1: Scene Title + Studio Name (with Video Play Vector Icon)
              // Line 2: File Type Badge + Codec + Duration + File Size + Date (Clean Vector SVGs)
              // ==========================================
              React.createElement(
                "div",
                { className: `sfm-reel-description-overlay ${isControlsVisible ? "sfm-visible" : "sfm-hidden"}` },
                // Social Media Avatar & Folder Path (Opens Folder Profile Video Wall)
                React.createElement(
                  "div",
                  {
                    className: "sfm-reel-avatar-bar d-inline-flex align-items-center mb-2",
                    role: "button",
                    tabIndex: 0,
                    onClick: (e) => {
                      e.stopPropagation();
                      e.preventDefault();
                      if (videoRef.current && !videoRef.current.paused) {
                        videoRef.current.pause();
                      }
                      if (onOpenProfile) {
                        onOpenProfile(targetFolderPath, scene);
                        return;
                      }
                      setShowFolderProfile(true);
                      const targetHash = buildHashForPath(targetFolderPath, "profile", null);
                      if (window.location.hash !== targetHash) {
                        const curDepth = (window.history.state && typeof window.history.state.sfmDepth === "number") ? window.history.state.sfmDepth : 1;
                        window.history.replaceState({ sfmPath: targetFolderPath, sfmView: "profile", inPlayerProfile: true, sfmDepth: curDepth }, "", targetHash);
                      }
                    },
                    onKeyDown: (e) => {
                      if (e.key === "Enter" || e.key === " ") {
                        e.stopPropagation();
                        e.preventDefault();
                        if (videoRef.current && !videoRef.current.paused) {
                          videoRef.current.pause();
                        }
                        if (onOpenProfile) {
                          onOpenProfile(targetFolderPath, scene);
                          return;
                        }
                        setShowFolderProfile(true);
                        const targetHash = buildHashForPath(targetFolderPath, "profile", null);
                        if (window.location.hash !== targetHash) {
                          const curDepth = (window.history.state && typeof window.history.state.sfmDepth === "number") ? window.history.state.sfmDepth : 1;
                          window.history.replaceState({ sfmPath: targetFolderPath, sfmView: "profile", inPlayerProfile: true, sfmDepth: curDepth }, "", targetHash);
                        }
                      }
                    },
                    title: `View Directory Profile & Video Wall for "${targetFolderPath || "Root"}"`,
                  },
                  React.createElement(
                    "div",
                    { className: "sfm-reel-avatar-box mr-2" },
                    React.createElement("img", {
                      src: posterUrl,
                      className: "sfm-reel-avatar-img",
                      alt: targetFolderPath || "Folder",
                    }),
                    React.createElement(
                      "span",
                      { className: "sfm-reel-avatar-badge" },
                      React.createElement(IconFolder, { size: 9, color: "#141822" })
                    )
                  ),
                  React.createElement(
                    "div",
                    { className: "sfm-reel-path-details" },
                    React.createElement(
                      "span",
                      { className: "sfm-reel-path-label" },
                      displayFolderPath
                    )
                  )
                ),
                // Line 1: Pure Title & Studio
                React.createElement(
                  "div",
                  { className: "d-flex align-items-center flex-wrap gap-2 mb-1" },
                  React.createElement(
                    "span",
                    { className: "sfm-reel-title-text d-inline-flex align-items-center" },
                    React.createElement(
                      "svg",
                      { viewBox: "0 0 24 24", width: 14, height: 14, fill: "currentColor", style: { verticalAlign: "-2px", marginRight: "6px" } },
                      React.createElement("polygon", { points: "6 4 19 12 6 20 6 4" })
                    ),
                    title
                  ),
                  studioName && React.createElement("span", { className: "sfm-badge sfm-badge-studio" }, studioName)
                ),
                // Line 2: Format Badge, Codec, Duration, File Size, Date
                React.createElement(
                  "div",
                  { className: "sfm-reel-meta-line d-flex align-items-center flex-wrap" },
                  React.createElement("span", { className: "sfm-badge sfm-badge-primary mr-1" }, extLabel),
                  codecBadge && React.createElement("span", { className: "sfm-badge sfm-badge-codec mr-1" }, codecBadge),
                  durationFormatted &&
                    React.createElement(
                      "span",
                      { className: "mr-2 d-inline-flex align-items-center" },
                      React.createElement(
                        "svg",
                        { viewBox: "0 0 24 24", width: 13, height: 13, stroke: "currentColor", strokeWidth: "2", fill: "none", style: { verticalAlign: "-2px", marginRight: "4px" } },
                        React.createElement("circle", { cx: "12", cy: "12", r: "10" }),
                        React.createElement("polyline", { points: "12 6 12 12 16 14" })
                      ),
                      durationFormatted
                    ),
                  fileSize && fileSize !== "0 B" &&
                    React.createElement(
                      "span",
                      { className: "mr-2 d-inline-flex align-items-center" },
                      React.createElement(
                        "svg",
                        { viewBox: "0 0 24 24", width: 13, height: 13, stroke: "currentColor", strokeWidth: "2", fill: "none", style: { verticalAlign: "-2px", marginRight: "4px" } },
                        React.createElement("line", { x1: "22", y1: "12", x2: "2", y2: "12" }),
                        React.createElement("path", { d: "M5.45 5.11L2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z" }),
                        React.createElement("line", { x1: "6", y1: "16", x2: "6.01", y2: "16" }),
                        React.createElement("line", { x1: "10", y1: "16", x2: "10.01", y2: "16" })
                      ),
                      fileSize
                    ),
                  dateStr &&
                    React.createElement(
                      "span",
                      { className: "mr-2 d-inline-flex align-items-center" },
                      React.createElement(
                        "svg",
                        { viewBox: "0 0 24 24", width: 13, height: 13, stroke: "currentColor", strokeWidth: "2", fill: "none", style: { verticalAlign: "-2px", marginRight: "4px" } },
                        React.createElement("rect", { x: "3", y: "4", width: "18", height: "18", rx: "2", ry: "2" }),
                        React.createElement("line", { x1: "16", y1: "2", x2: "16", y2: "6" }),
                        React.createElement("line", { x1: "8", y1: "2", x2: "8", y2: "6" }),
                        React.createElement("line", { x1: "3", y1: "10", x2: "21", y2: "10" })
                      ),
                      dateStr
                    )
                )
              ),

              // ==========================================
              // Bottom Scrubber Timeline Bar & Controls
              // ==========================================
              React.createElement(
                "div",
                {
                  className: `sfm-reel-bottom-controls ${isControlsVisible ? "sfm-visible" : "sfm-hidden"}`,
                  onClick: (e) => e.stopPropagation(),
                },
                // Scrubber Timeline Bar
                React.createElement(
                  "div",
                  {
                    className: "sfm-reel-scrubber-track",
                    onClick: handleScrubberClick,
                    title: "Seek timeline",
                  },
                  React.createElement("div", {
                    className: "sfm-reel-scrubber-buffered",
                    style: { width: `${bufferedProgress}%` },
                  }),
                  React.createElement("div", {
                    className: "sfm-reel-scrubber-played",
                    style: { width: `${duration ? (currentTime / duration) * 100 : 0}%` },
                  }),
                  React.createElement("div", {
                    className: "sfm-reel-scrubber-thumb",
                    style: { left: `${duration ? (currentTime / duration) * 100 : 0}%` },
                  })
                ),
                // Controls Row
                React.createElement(
                  "div",
                  { className: "d-flex justify-content-between align-items-center mt-2" },
                  React.createElement(
                    "div",
                    { className: "d-flex align-items-center gap-3" },
                    React.createElement(
                      "button",
                      {
                        className: "sfm-reel-play-btn",
                        onClick: handleTogglePlay,
                        title: isPlaying ? "Pause (Space)" : "Play (Space)",
                      },
                      isPlaying
                        ? React.createElement(
                            "svg",
                            { viewBox: "0 0 24 24", width: 14, height: 14, fill: "currentColor" },
                            React.createElement("rect", { x: "5", y: "4", width: "4", height: "16", rx: "1" }),
                            React.createElement("rect", { x: "15", y: "4", width: "4", height: "16", rx: "1" })
                          )
                        : React.createElement(
                            "svg",
                            { viewBox: "0 0 24 24", width: 14, height: 14, fill: "currentColor" },
                            React.createElement("polygon", { points: "6 4 19 12 6 20 6 4" })
                          )
                    ),
                    React.createElement(
                      "span",
                      { className: "sfm-reel-time-text" },
                      `${formatTime(currentTime)} / ${formatTime(duration)}`
                    )
                  ),
                  React.createElement(
                    "div",
                    { className: "d-flex align-items-center gap-2" },
                    React.createElement(
                      "button",
                      {
                        className: "sfm-reel-vol-btn d-flex align-items-center",
                        onClick: handleToggleMute,
                        title: isMuted ? "Unmute" : "Mute",
                      },
                      isMuted || volume === 0
                        ? React.createElement(
                            "svg",
                            { viewBox: "0 0 24 24", width: 16, height: 16, fill: "none", stroke: "currentColor", strokeWidth: "2" },
                            React.createElement("polygon", { points: "11 5 6 9 2 9 2 15 6 15 11 19 11 5", fill: "currentColor" }),
                            React.createElement("line", { x1: "23", y1: "9", x2: "17", y2: "15" }),
                            React.createElement("line", { x1: "17", y1: "9", x2: "23", y2: "15" })
                          )
                        : React.createElement(
                            "svg",
                            { viewBox: "0 0 24 24", width: 16, height: 16, fill: "none", stroke: "currentColor", strokeWidth: "2" },
                            React.createElement("polygon", { points: "11 5 6 9 2 9 2 15 6 15 11 19 11 5", fill: "currentColor" }),
                            React.createElement("path", { d: "M15.54 8.46a5 5 0 0 1 0 7.07" }),
                            React.createElement("path", { d: "M19.07 4.93a10 10 0 0 1 0 14.14" })
                          )
                    ),
                    React.createElement("input", {
                      type: "range",
                      className: "sfm-reel-vol-slider",
                      min: 0,
                      max: 1,
                      step: 0.05,
                      value: isMuted ? 0 : volume,
                      onChange: handleVolumeChange,
                      title: `Volume: ${Math.round((isMuted ? 0 : volume) * 100)}%`,
                    })
                  )
                )
              )
            )
          )
        )
      );
    }

    // ==========================================
    // Modal: Folder-Scoped Filename Regex Parser (Feature 1)
    // ==========================================
    // ==========================================
    // Modal: Folder-Scoped Filename Regex Parser with Guided Builder
    // ==========================================
    // ==========================================
    // Modal: Upgraded Folder-Scoped Filename Regex Parser (Interactive Blocks + Auto-Detect)
    // ==========================================
    // ==========================================
    // Modal: Upgraded Folder-Scoped Filename Regex Parser (Interactive Blocks + Auto-Detect)
    // ==========================================
    // ==========================================
    // Modal: Path-Clues & Stash-box Grounded Smart Metadata Resolver
    // ==========================================
    // ==========================================
    // Modal: Fully Customizable Smart Filename & Path Resolver
    // ==========================================
    function FilenameParserModal({ currentFolder, currentPath = "", directScenes, onClose, onApplied }) {
      const PRESETS = [
        { label: "Auto-Detected / Interactive Pattern", pattern: "", caseInsensitive: true },
        { label: "Code__PERFORMER_Title__hash (e.g. MM2821__BIANNA_ARSON_Shoot...)", pattern: "^(?<code>[A-Za-z0-9]+)__(?<performers>[A-Z]+(?:_[A-Z]+)*)_+(?<title>.+?)__(?:[a-zA-Z0-9]+)(?:\\.[^.]+)?$", caseInsensitive: false },
        { label: "StudioCode__PERFORMER_Title (e.g. MM1566__KENDRA_COLE_Shoot...)", pattern: "^(?<code>[A-Za-z0-9]+)__(?<performers>[A-Z]+(?:_[A-Z]+)*)_+(?<title>.+?)(?:__[a-zA-Z0-9]{4,10})?(?:\\.[^.]+)?$", caseInsensitive: false },
        { label: "Studio - Date - Title: ^(?<studio>[^-_]+)[-_\\s]+(?<date>\\d{4}[-._]\\d{2}[-._]\\d{2})[-_\\s]+(?<title>.+)$", pattern: "^(?<studio>[^-_]+)[-_\\s]+(?<date>\\d{4}[-._]\\d{2}[-._]\\d{2})[-_\\s]+(?<title>.+)$", caseInsensitive: true },
        { label: "Studio - Code - Title: ^(?<studio>[^-_]+)[-_\\s]+(?<code>[A-Za-z0-9_.-]+)[-_\\s]+(?<title>.+)$", pattern: "^(?<studio>[^-_]+)[-_\\s]+(?<code>[A-Za-z0-9_.-]+)[-_\\s]+(?<title>.+)$", caseInsensitive: true },
        { label: "Studio - Code - Performer - Title: ^(?<studio>[^-_]+)[-_\\s]+(?<code>[A-Za-z0-9_.-]+)[-_\\s]+(?<performers>[^-_]+)[-_\\s]+(?<title>.+)$", pattern: "^(?<studio>[^-_]+)[-_\\s]+(?<code>[A-Za-z0-9_.-]+)[-_\\s]+(?<performers>[^-_]+)[-_\\s]+(?<title>.+)$", caseInsensitive: true },
        { label: "Date.Studio.Performer.Title: ^(?<date>\\d{4}[-._]\\d{2}[-._]\\d{2})[-_\\s.]+(?<studio>[^-_.]+)[-_\\s.]+(?<performers>[^-_.]+)[-_\\s.]+(?<title>.+)$", pattern: "^(?<date>\\d{4}[-._]\\d{2}[-._]\\d{2})[-_\\s.]+(?<studio>[^-_.]+)[-_\\s.]+(?<performers>[^-_.]+)[-_\\s.]+(?<title>.+)$", caseInsensitive: true },
        { label: "Performer - Title (Date): ^(?<performers>[^-_]+)[-_\\s]+(?<title>[^()]+?)(?:\\s*\\((?<date>\\d{4}[-._]?\\d{2}[-._]?\\d{2}|\\d{4})\\))?$", pattern: "^(?<performers>[^-_]+)[-_\\s]+(?<title>[^()]+?)(?:\\s*\\((?<date>\\d{4}[-._]?\\d{2}[-._]?\\d{2}|\\d{4})\\))?$", caseInsensitive: true },
        { label: "Code - Title: ^(?<code>[A-Za-z0-9_.-]+)[-_\\s]+(?<title>.+)$", pattern: "^(?<code>[A-Za-z0-9_.-]+)[-_\\s]+(?<title>.+)$", caseInsensitive: true },
      ];

      const FIELDS = [
        { id: "title", label: "Title", color: "#88c0d0" },
        { id: "date", label: "Date", color: "#a3be8c" },
        { id: "code", label: "StudioCode", color: "#ebcb8b" },
        { id: "duration", label: "Duration", color: "#b48ead" },
        { id: "studio", label: "Studio", color: "#81a1c1" },
        { id: "performers", label: "Performers", color: "#d08770" },
        { id: "ignore", label: "Ignore", color: "#4c566a" },
      ];

      // Inspect first sample to determine if current folder is a double-underscore release
      const initialSampleBasename = directScenes[0]?.files?.[0]?.basename || "";
      const initialSampleNoExt = initialSampleBasename.replace(/\.[^/.]+$/, "");
      const isInitialDunder = /^([A-Za-z0-9]{2,8})__([A-Z]+(?:_[A-Z]+)*)_+(.+?)(?:__[a-zA-Z0-9]{4,10})?$/.test(initialSampleNoExt);
      const dunderPattern = "^(?<code>[A-Za-z0-9]+)__(?<performers>[A-Z]+(?:_[A-Z]+)*)_+(?<title>.+?)__(?:[a-zA-Z0-9]+)(?:\\.[^.]+)?$";

      const [builderMode, setBuilderMode] = useState("guided"); // "guided" | "raw"
      const [sampleIndex, setSampleIndex] = useState(0);
      const [pattern, setPattern] = useState(() => (isInitialDunder ? dunderPattern : PRESETS[1].pattern));
      const [caseInsensitive, setCaseInsensitive] = useState(() => !isInitialDunder);
      const [flexibleDelimiters, setFlexibleDelimiters] = useState(true);
      const [cleanSpaces, setCleanSpaces] = useState(true);
      const [titleCase, setTitleCase] = useState(true);
      const [normalizeDate, setNormalizeDate] = useState(true);
      const [previewFilter, setPreviewFilter] = useState("all"); // "all" | "matched" | "unmatched"
      const [chunks, setChunks] = useState([]);
      const [activeSplitChunkId, setActiveSplitChunkId] = useState(null); // Chunk ID currently being split
      const [selectedSceneIds, setSelectedSceneIds] = useState(() => new Set());
      const [isExecuting, setIsExecuting] = useState(false);
      const [progressText, setProgressText] = useState("");

      // --- PATH CLUES & STASH-BOX STATE ---
      const [pathClues, setPathClues] = useState([]);
      const [availableStashBoxes, setAvailableStashBoxes] = useState([]);
      const [selectedStashBox, setSelectedStashBox] = useState("");
      const [isCloudQuerying, setIsCloudQuerying] = useState(false);
      const [cloudMatches, setCloudMatches] = useState({});

      const sampleScene = directScenes[sampleIndex] || directScenes[0];
      const sampleRawBasename = sampleScene?.files?.[0]?.basename || "";
      const sampleWithoutExt = sampleRawBasename.replace(/\\.[^/.]+$/, "");

      // Helper: escape regex literal
      const escapeRegex = (s) => s.replace(/[-/\\^$*+?.()|[\]{}]/g, "\\$&");

      // Initialize Path Clues from directory hierarchy
      useEffect(() => {
        const fullSamplePath = sampleScene?.files?.[0]?.path || currentPath || "";
        const normalized = fullSamplePath.replace(/\\/g, "/");
        const dirParts = normalized.split("/").filter(Boolean);
        if (dirParts.length > 0 && dirParts[dirParts.length - 1].includes(".")) {
          dirParts.pop();
        }

        const relevantParts = dirParts.slice(-3);
        const initialClues = relevantParts.map((part, idx) => {
          const isParent = (idx === relevantParts.length - 1);
          const isGrandparent = (idx === relevantParts.length - 2);
          let role = "ignore";
          if (isParent) role = "studio";
          else if (isGrandparent && /^vr|4k|1080p|uhd$/i.test(part)) role = "tag";
          return { name: part, role, verifiedStudioId: null };
        });

        setPathClues(initialClues);

        if (initialClues.length > 0) {
          const parentClue = initialClues[initialClues.length - 1];
          gqlFetch(
            `query CheckStudioClue($name: String!) {
              findStudios(studio_filter: { name: { value: $name, modifier: EQUALS } }) {
                studios { id name }
              }
            }`,
            { name: parentClue.name }
          )
            .then((res) => {
              const matchedStudio = res?.findStudios?.studios?.[0];
              if (matchedStudio) {
                setPathClues((prev) =>
                  prev.map((c) => (c.name === parentClue.name ? { ...c, role: "studio", verifiedStudioId: matchedStudio.id } : c))
                );
              }
            })
            .catch(() => {});
        }

        gqlFetch(`query GetStashBoxesConfig {
          configuration {
            general {
              stashBoxes {
                name
                endpoint
                api_key
              }
            }
          }
        }`)
          .then((res) => {
            const boxes = res?.configuration?.general?.stashBoxes || [];
            setAvailableStashBoxes(boxes);
            if (boxes.length > 0) {
              setSelectedStashBox(boxes[0].endpoint);
            }
          })
          .catch(() => {});
      }, [sampleIndex, currentPath]);

      const handleSetPathClueRole = (segmentName, newRole) => {
        setPathClues((prev) => prev.map((c) => (c.name === segmentName ? { ...c, role: newRole } : c)));
      };

      const activeStudioClue = useMemo(() => {
        const clue = pathClues.find((c) => c.role === "studio");
        return clue ? clue.name : "";
      }, [pathClues]);

      const activePerformerClue = useMemo(() => {
        const clue = pathClues.find((c) => c.role === "performer");
        return clue ? clue.name : "";
      }, [pathClues]);

      // Compile regex directly from visual chunks by inspecting actual separators in sampleWithoutExt
      const compileRegexFromChunks = (currentChunks, sampleText) => {
        if (!currentChunks || currentChunks.length === 0) return;

        let cursor = 0;
        let regex = "^";
        let hasUppercaseOnlyGroup = false;

        currentChunks.forEach((chunk, idx) => {
          const isLast = (idx === currentChunks.length - 1);
          const chunkText = chunk.text;
          const pos = sampleText.indexOf(chunkText, cursor);

          // If there is literal separator text between the previous chunk and this chunk
          if (pos > cursor) {
            const sepText = sampleText.substring(cursor, pos);
            if (sepText === "__") {
              regex += "__";
            } else if (/^_+$/.test(sepText)) {
              regex += "_+";
            } else if (sepText.includes(" - ")) {
              regex += "\\s*-\\s*";
            } else if (/^\\s+$/.test(sepText)) {
              regex += "\\s+";
            } else {
              regex += escapeRegex(sepText);
            }
          }

          // Build field pattern
          if (chunk.fieldId === "ignore") {
            regex += isLast ? "(?:.+)" : "(?:[a-zA-Z0-9]+)";
          } else if (chunk.fieldId === "code") {
            if (/^\\d+$/.test(chunkText)) {
              regex += "(?<code>\\d+)";
            } else {
              // Code must NOT include underscores
              regex += "(?<code>[A-Za-z0-9]+)";
            }
          } else if (chunk.fieldId === "studio") {
            if (/^[A-Za-z]+$/.test(chunkText)) {
              regex += "(?<studio>[A-Za-z]+)";
            } else {
              regex += "(?<studio>[A-Za-z0-9]+)";
            }
          } else if (chunk.fieldId === "performers") {
            if (/^[A-Z_]+$/.test(chunkText)) {
              hasUppercaseOnlyGroup = true;
              regex += "(?<performers>[A-Z]+(?:_[A-Z]+)*)";
            } else {
              regex += "(?<performers>[A-Za-z]+(?:[\\s_][A-Za-z]+)*)";
            }
          } else if (chunk.fieldId === "title") {
            regex += isLast ? "(?<title>.+)" : "(?<title>.+?)";
          } else if (chunk.fieldId === "date") {
            regex += "(?<date>\\d{4}[-._]\\d{2}[-._]\\d{2}|\\d{6,8})";
          } else if (chunk.fieldId === "duration") {
            regex += "(?<duration>\\d+(?:m|min|s|sec)?|\\d+:\\d+(?::\\d+)?)";
          }

          cursor = pos >= 0 ? (pos + chunkText.length) : cursor;
        });

        // Trailing separator / hash
        if (cursor < sampleText.length) {
          const trailing = sampleText.substring(cursor);
          if (trailing === "__") regex += "__";
          else if (/^_+$/.test(trailing)) regex += "_+";
          else regex += escapeRegex(trailing);
        }

        regex += "(?:\\.[^.]+)?$";
        setPattern(regex);

        // If the performer group relies on uppercase, automatically enforce case-sensitivity
        if (hasUppercaseOnlyGroup) {
          setCaseInsensitive(false);
        }
      };

      // Auto-detect chunks from filename
      const autoDetectFromFilename = (filename, forcedDelimiter = null) => {
        if (!filename) return;

        // Pattern: MM2821__BIANNA_ARSON_Shoot_closeup_XXX__1q2wxz
        const dunderFull = filename.match(/^([A-Za-z0-9]{2,8})__([A-Z]+(?:_[A-Z]+)*)_+(.+?)__(?:[a-zA-Z0-9]+)$/);
        if (dunderFull && !forcedDelimiter) {
          const detectedChunks = [
            { id: 1, text: dunderFull[1], fieldId: "code" },
            { id: 2, text: dunderFull[2], fieldId: "performers" },
            { id: 3, text: dunderFull[3], fieldId: "title" },
            { id: 4, text: filename.substring(filename.lastIndexOf("__") + 2), fieldId: "ignore" },
          ];
          setChunks(detectedChunks);
          compileRegexFromChunks(detectedChunks, filename);
          return;
        }

        let delimiter = forcedDelimiter;
        if (!delimiter) {
          if (filename.includes("__")) delimiter = "__";
          else if (filename.includes(" - ")) delimiter = " - ";
          else if (filename.includes("_")) delimiter = "_";
          else if (filename.includes(".")) delimiter = ".";
          else delimiter = " ";
        }

        const rawParts = filename.split(delimiter).map((p) => p.trim()).filter(Boolean);
        const detectedChunks = [];

        rawParts.forEach((part, idx) => {
          let fieldId = "title";
          if (/^(1080p|2160p|4k|720p|480p|hevc|x264|x265|h264|h265|web-dl|aac|uhd|hd|sd|vr|60fps|3dh|sbs)$/i.test(part)) {
            fieldId = "ignore";
          } else if (idx === rawParts.length - 1 && /^[a-zA-Z0-9]{5,8}$/.test(part)) {
            fieldId = "ignore";
          } else if (/^\\d{4}[-._]\\d{2}[-._]\\d{2}$/.test(part) || /^\\d{6,8}$/.test(part)) {
            fieldId = "date";
          } else if (/^[A-Za-z0-9]{2,6}[-_]?[0-9]{2,5}$/i.test(part) || /^[A-Z]{2,}\\d{2,}$/i.test(part)) {
            fieldId = "code";
          } else if (/^\\d+[mhms]$/i.test(part) || /^\\d+:\\d+(?::\\d+)?$/.test(part)) {
            fieldId = "duration";
          } else if (idx === 0 && rawParts.length > 1) {
            fieldId = "studio";
          } else if (idx === rawParts.length - 1) {
            fieldId = "title";
          } else if (idx === 1 && rawParts.length > 2) {
            fieldId = "performers";
          }

          detectedChunks.push({
            id: Date.now() + idx,
            text: part,
            fieldId,
          });
        });

        setChunks(detectedChunks);
        compileRegexFromChunks(detectedChunks, filename);
      };

      // Run initial auto-detection on mount or sample switch
      useEffect(() => {
        if (sampleWithoutExt) {
          autoDetectFromFilename(sampleWithoutExt);
        }
      }, [sampleIndex]);

      // Change field role of a chunk
      const handleSetChunkField = (chunkId, newFieldId) => {
        const updated = chunks.map((c) => (c.id === chunkId ? { ...c, fieldId: newFieldId } : c));
        setChunks(updated);
        compileRegexFromChunks(updated, sampleWithoutExt);
      };

      // Edit text of a chunk directly
      const handleEditChunkText = (chunkId, newText) => {
        const updated = chunks.map((c) => (c.id === chunkId ? { ...c, text: newText } : c));
        setChunks(updated);
        compileRegexFromChunks(updated, sampleWithoutExt);
      };

      // Delete a chunk
      const handleDeleteChunk = (chunkId) => {
        const updated = chunks.filter((c) => c.id !== chunkId);
        setChunks(updated);
        compileRegexFromChunks(updated, sampleWithoutExt);
      };

      // Split a chunk into two chunks at a specific position or split string
      const handleSplitChunk = (chunkId, part1, part2, field1, field2) => {
        const idx = chunks.findIndex((c) => c.id === chunkId);
        if (idx === -1) return;

        const newChunk1 = { id: Date.now(), text: part1, fieldId: field1 || chunks[idx].fieldId };
        const newChunk2 = { id: Date.now() + 1, text: part2, fieldId: field2 || "title" };

        const updated = [...chunks.slice(0, idx), newChunk1, newChunk2, ...chunks.slice(idx + 1)];
        setChunks(updated);
        setActiveSplitChunkId(null);
        compileRegexFromChunks(updated, sampleWithoutExt);
      };

      // Merge chunk with next chunk
      const handleMergeWithNext = (idx) => {
        if (idx >= chunks.length - 1) return;
        const current = chunks[idx];
        const next = chunks[idx + 1];
        const merged = {
          ...current,
          text: `${current.text} ${next.text}`,
        };
        const updated = [...chunks.slice(0, idx), merged, ...chunks.slice(idx + 2)];
        setChunks(updated);
        compileRegexFromChunks(updated, sampleWithoutExt);
      };

      // Helper to clean extracted text
      const cleanExtracted = (fieldId, rawVal) => {
        if (!rawVal) return "";
        let val = rawVal.trim();
        if (fieldId === "title") {
          val = val.replace(/__+/g, " - ").replace(/[_.]+/g, " ").replace(/\\s+/g, " ").trim();
          if (titleCase) {
            val = val.replace(/\\w\\S*/g, (txt) => txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase());
            val = val.replace(/\\bXxx\\b/g, "XXX");
            val = val.replace(/\\b4k\\b/g, "4K");
          }
        } else if (fieldId === "studio" || fieldId === "performers") {
          val = val.replace(/__+/g, ", ").replace(/[_.]+/g, " ").replace(/\\s+/g, " ").trim();
          if (titleCase) {
            val = val.replace(/\\w\\S*/g, (txt) => txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase());
          }
        } else if (fieldId === "date") {
          if (normalizeDate) {
            val = val.replace(/[._]/g, "-");
            if (/^\\d{8}$/.test(val)) {
              val = `${val.substring(0, 4)}-${val.substring(4, 6)}-${val.substring(6, 8)}`;
            }
          }
        }
        return val;
      };

      // Compute parsed matches in real-time
      const parsedResults = useMemo(() => {
        let re = null;
        try {
          re = new RegExp(pattern, caseInsensitive ? "i" : "");
        } catch (e) {
          return { error: e.message, items: [] };
        }

        const items = directScenes.map((scene) => {
          const rawBasename = scene.files?.[0]?.basename || "";
          const nameWithoutExt = rawBasename.replace(/\\.[^/.]+$/, "");
          const match = re.exec(nameWithoutExt) || re.exec(rawBasename);

          if (!match || !match.groups) {
            return { scene, rawBasename, matched: false, groups: {} };
          }
          return { scene, rawBasename, matched: true, groups: match.groups };
        });

        return { error: null, items };
      }, [pattern, caseInsensitive, directScenes]);

      // Query Stash-box for all matched scenes
      const handleQueryStashBox = async () => {
        if (!selectedStashBox) return;
        setIsCloudQuerying(true);
        setProgressText("Querying Stash-box for scene metadata...");

        const newCloudMatches = { ...cloudMatches };
        const matchedItems = parsedResults.items.filter((i) => i.matched);

        for (let i = 0; i < matchedItems.length; i++) {
          const item = matchedItems[i];
          const queryCode = item.groups.code || item.groups.title || "";
          if (!queryCode) continue;

          setProgressText(`Querying Stash-box (${i + 1}/${matchedItems.length}): ${queryCode}...`);

          try {
            const sRes = await gqlFetch(
              `query ScrapeSceneFromBox($source: ScraperSourceInput!, $input: ScrapeSingleSceneInput!) {
                scrapeSingleScene(source: $source, input: $input) {
                  title
                  details
                  url
                  date
                  code
                  studio { name }
                  performers { name }
                  tags { name }
                }
              }`,
              {
                source: { stash_box_endpoint: selectedStashBox },
                input: { query: queryCode.trim() },
              }
            );

            const scraped = sRes?.scrapeSingleScene?.[0];
            if (scraped) {
              newCloudMatches[item.scene.id] = scraped;
            }
          } catch (err) {
            console.warn(`Stash-box scrape error for ${queryCode}:`, err);
          }
        }

        setCloudMatches(newCloudMatches);
        setIsCloudQuerying(false);
        setProgressText(`Completed Stash-box resolution. Found ${Object.keys(newCloudMatches).length} verified matches.`);
      };

      useEffect(() => {
        const matchedIds = new Set(parsedResults.items.filter((i) => i.matched).map((i) => i.scene.id));
        setSelectedSceneIds(matchedIds);
      }, [parsedResults]);

      const matchedCount = parsedResults.items.filter((i) => i.matched).length;
      const unmatchedCount = parsedResults.items.length - matchedCount;

      const filteredItems = useMemo(() => {
        if (previewFilter === "matched") return parsedResults.items.filter((i) => i.matched);
        if (previewFilter === "unmatched") return parsedResults.items.filter((i) => !i.matched);
        return parsedResults.items;
      }, [parsedResults, previewFilter]);

      const handleToggleSelectScene = (sceneId) => {
        const next = new Set(selectedSceneIds);
        if (next.has(sceneId)) next.delete(sceneId);
        else next.add(sceneId);
        setSelectedSceneIds(next);
      };

      const handleSelectAllMatched = () => {
        if (selectedSceneIds.size === matchedCount) {
          setSelectedSceneIds(new Set());
        } else {
          setSelectedSceneIds(new Set(parsedResults.items.filter((i) => i.matched).map((i) => i.scene.id)));
        }
      };

      const handleExecute = async () => {
        const scenesToUpdate = parsedResults.items.filter((i) => i.matched && selectedSceneIds.has(i.scene.id));
        if (scenesToUpdate.length === 0) return;
        setIsExecuting(true);
        setProgressText(`Starting updates for ${scenesToUpdate.length} scenes...`);

        try {
          let success = 0;

          for (let i = 0; i < scenesToUpdate.length; i++) {
            const item = scenesToUpdate[i];
            const cloud = cloudMatches[item.scene.id];
            setProgressText(`Updating scene ${i + 1}/${scenesToUpdate.length}: ${item.rawBasename}...`);

            const updateInput = { id: item.scene.id };
            const { title, date, code, studio, performers } = item.groups;

            const finalTitle = cloud?.title || cleanExtracted("title", title);
            const finalDate = cloud?.date || cleanExtracted("date", date);
            const finalCode = cloud?.code || (code || "").trim();
            const finalStudio = cloud?.studio?.name || cleanExtracted("studio", studio) || activeStudioClue;
            const finalPerformers = cloud?.performers ? cloud.performers.map((p) => p.name).join(", ") : (cleanExtracted("performers", performers) || activePerformerClue);

            if (finalTitle) updateInput.title = finalTitle;
            if (finalDate && /^\\d{4}-\\d{2}-\\d{2}$/.test(finalDate)) {
              updateInput.date = finalDate;
            }
            if (finalCode) {
              updateInput.code = finalCode;
            }
            if (cloud?.details) {
              updateInput.details = cloud.details;
            }

            if (finalStudio) {
              const sRes = await gqlFetch(
                `query FindStudio($name: String!) {
                  findStudios(studio_filter: { name: { value: $name, modifier: EQUALS } }) {
                    studios { id name }
                  }
                }`,
                { name: finalStudio }
              );
              const found = sRes?.findStudios?.studios?.[0];
              if (found) updateInput.studio_id = found.id;
            }

            if (finalPerformers) {
              const pNames = finalPerformers.split(/,|&|\\band\\b/i).map((s) => s.trim()).filter(Boolean);
              const pIds = [];
              for (const pName of pNames) {
                const pRes = await gqlFetch(
                  `query FindPerformer($name: String!) {
                    findPerformers(performer_filter: { name: { value: $name, modifier: EQUALS } }) {
                      performers { id name }
                    }
                  }`,
                  { name: pName }
                );
                const found = pRes?.findPerformers?.performers?.[0];
                if (found) pIds.push(found.id);
              }
              if (pIds.length > 0) updateInput.performer_ids = pIds;
            }

            await gqlFetch(
              `mutation UpdateScene($input: SceneUpdateInput!) {
                sceneUpdate(input: $input) { id }
              }`,
              { input: updateInput }
            );
            success++;
          }

          setProgressText(`Successfully updated ${success} scenes with verified metadata!`);
          setTimeout(() => {
            clearCachedScenes();
            onApplied();
            onClose();
          }, 1200);
        } catch (err) {
          console.error(err);
          setProgressText(`Error: ${err.message}`);
          setIsExecuting(false);
        }
      };

      return React.createElement(
        "div",
        { className: "sfm-modal-backdrop", onClick: onClose },
        React.createElement(
          "div",
          { className: "sfm-modal-dialog sfm-modal-dialog-large sfm-parser-modal", onClick: (e) => e.stopPropagation() },
          React.createElement(
            "div",
            { className: "sfm-modal-header d-flex justify-content-between align-items-center" },
            React.createElement(
              "div",
              { className: "d-flex align-items-center gap-3" },
              React.createElement("h5", { className: "mb-0" }, React.createElement(IconSearch, { size: 16, color: "#88c0d0", className: "mr-2" }), "Customizable Filename & Path Resolver"),
              React.createElement(
                "div",
                { className: "btn-group btn-group-sm sfm-builder-mode-tabs ml-3" },
                React.createElement(
                  "button",
                  {
                    type: "button",
                    className: `btn btn-sm ${builderMode === "guided" ? "btn-info font-weight-bold" : "btn-outline-secondary"} py-0 px-3`,
                    onClick: () => setBuilderMode("guided"),
                  },
                  React.createElement(IconSparkles, { size: 13, className: "mr-1 text-info" }), "Interactive Blocks"
                ),
                React.createElement(
                  "button",
                  {
                    type: "button",
                    className: `btn btn-sm ${builderMode === "raw" ? "btn-info font-weight-bold" : "btn-outline-secondary"} py-0 px-3`,
                    onClick: () => setBuilderMode("raw"),
                  },
                  React.createElement(IconSettings, { size: 13, className: "mr-1 text-info" }), "Raw Regex"
                )
              )
            ),
            React.createElement("button", { className: "close text-light", onClick: onClose }, "×")
          ),
          React.createElement(
            "div",
            { className: "sfm-modal-body" },
            // Section 1: Directory Path Clues
            React.createElement(
              "div",
              { className: "sfm-path-clues-card p-2 px-3 mb-3 rounded bg-dark border border-secondary" },
              React.createElement(
                "div",
                { className: "d-flex justify-content-between align-items-center mb-2 flex-wrap gap-2" },
                React.createElement(
                  "div",
                  { className: "d-flex align-items-center gap-2" },
                  React.createElement("span", { className: "badge badge-info d-inline-flex align-items-center" }, React.createElement(IconFolder, { size: 11, className: "mr-1" }), "Path Clues"),
                  React.createElement("span", { className: "small text-muted" }, "Folder hierarchy context inferred from filesystem:")
                ),
                availableStashBoxes.length > 0 &&
                  React.createElement(
                    "div",
                    { className: "d-flex align-items-center gap-2" },
                    React.createElement("span", { className: "small text-light" }, React.createElement(IconGlobe, { size: 12, className: "mr-1 text-info" }), "Stash-box:"),
                    React.createElement(
                      "select",
                      {
                        className: "form-control form-control-sm bg-dark text-info border-secondary py-0",
                        style: { width: "auto", height: "24px", fontSize: "0.78rem" },
                        value: selectedStashBox,
                        onChange: (e) => setSelectedStashBox(e.target.value),
                      },
                      availableStashBoxes.map((box) =>
                        React.createElement("option", { key: box.endpoint, value: box.endpoint }, `${box.name} (${box.endpoint})`)
                      )
                    ),
                    React.createElement(
                      "button",
                      {
                        type: "button",
                        className: "btn btn-xs btn-primary font-weight-bold py-0 px-2",
                        disabled: isCloudQuerying || matchedCount === 0,
                        onClick: handleQueryStashBox,
                        title: "Query Stash-box using Code and Path clues to fetch canonical metadata",
                      },
                      React.createElement(IconGlobe, { size: 13, className: "mr-1" }), isCloudQuerying ? "Querying..." : "Query Stash-box"
                    )
                  )
              ),
              React.createElement(
                "div",
                { className: "d-flex align-items-center flex-wrap gap-2" },
                pathClues.map((clue, idx) =>
                  React.createElement(
                    "div",
                    {
                      key: clue.name,
                      className: "sfm-path-clue-pill d-inline-flex align-items-center p-1 px-2 rounded bg-black border border-secondary",
                    },
                    React.createElement("span", { className: "text-muted small mr-1" }, idx === pathClues.length - 1 ? "Parent:" : "Folder:"),
                    React.createElement("span", { className: "font-weight-bold text-light mr-2", style: { fontFamily: "monospace" } }, clue.name),
                    React.createElement(
                      "select",
                      {
                        className: "form-control form-control-sm border-0 py-0 px-1 font-weight-bold",
                        style: {
                          width: "auto",
                          height: "22px",
                          fontSize: "0.75rem",
                          backgroundColor: clue.role === "studio" ? "#81a1c1" : clue.role === "performer" ? "#d08770" : clue.role === "tag" ? "#ebcb8b" : "#4c566a",
                          color: "#1e222a",
                          borderRadius: "3px",
                        },
                        value: clue.role,
                        onChange: (e) => handleSetPathClueRole(clue.name, e.target.value),
                      },
                      React.createElement("option", { value: "studio" }, "Studio Clue"),
                      React.createElement("option", { value: "performer" }, "Performer Clue"),
                      React.createElement("option", { value: "tag" }, "Tag Clue"),
                      React.createElement("option", { value: "ignore" }, "Ignore")
                    ),
                    clue.verifiedStudioId &&
                      React.createElement("span", { className: "badge badge-success ml-2 py-0 px-1", title: "Matched verified Studio in local Stash database" }, "✓ DB Studio")
                  )
                )
              )
            ),
            // Section 2: Interactive Field Customization Blocks
            builderMode === "guided"
              ? React.createElement(
                  "div",
                  { className: "sfm-guided-card p-3 mb-3 rounded bg-dark border border-secondary" },
                  // Sample File Toolbar
                  React.createElement(
                    "div",
                    { className: "d-flex justify-content-between align-items-center mb-2 flex-wrap gap-2" },
                    React.createElement(
                      "div",
                      { className: "d-flex align-items-center gap-2" },
                      React.createElement("span", { className: "badge badge-secondary" }, "Sample File"),
                      React.createElement("span", { className: "font-weight-bold text-light", style: { fontFamily: "monospace" } }, sampleWithoutExt)
                    ),
                    directScenes.length > 1 &&
                      React.createElement(
                        "div",
                        { className: "d-flex align-items-center gap-2" },
                        React.createElement(
                          "button",
                          {
                            type: "button",
                            className: "btn btn-xs btn-outline-secondary py-0 px-2",
                            disabled: sampleIndex <= 0,
                            onClick: () => setSampleIndex(Math.max(0, sampleIndex - 1)),
                          },
                          "◀ Prev"
                        ),
                        React.createElement("span", { className: "text-muted small" }, `${sampleIndex + 1} of ${directScenes.length}`),
                        React.createElement(
                          "button",
                          {
                            type: "button",
                            className: "btn btn-xs btn-outline-secondary py-0 px-2",
                            disabled: sampleIndex >= directScenes.length - 1,
                            onClick: () => setSampleIndex(Math.min(directScenes.length - 1, sampleIndex + 1)),
                          },
                          "Next ▶"
                        )
                      )
                  ),
                  // Word Chunks & Customization Action Bar
                  React.createElement(
                    "div",
                    { className: "mb-3" },
                    React.createElement(
                      "div",
                      { className: "d-flex justify-content-between align-items-center mb-1" },
                      React.createElement("label", { className: "small font-weight-bold text-muted mb-0" }, "CUSTOMIZE & ADJUST FIELDS:"),
                      React.createElement(
                        "div",
                        { className: "d-flex align-items-center gap-1" },
                        React.createElement("span", { className: "small text-muted mr-1" }, "Auto:"),
                        React.createElement(
                          "button",
                          {
                            type: "button",
                            className: "btn btn-xs btn-info font-weight-bold py-0 px-2 mr-1",
                            onClick: () => autoDetectFromFilename(sampleWithoutExt),
                            title: "Auto-detect fields using smart heuristics",
                          },
                          React.createElement(IconSparkles, { size: 12, className: "mr-1" }), "Auto-Detect"
                        ),
                        React.createElement(
                          "button",
                          {
                            type: "button",
                            className: "btn btn-xs btn-outline-secondary py-0 px-1",
                            onClick: () => autoDetectFromFilename(sampleWithoutExt, "__"),
                          },
                          '"__"'
                        ),
                        React.createElement(
                          "button",
                          {
                            type: "button",
                            className: "btn btn-xs btn-outline-secondary py-0 px-1",
                            onClick: () => autoDetectFromFilename(sampleWithoutExt, " - "),
                          },
                          '" - "'
                        ),
                        React.createElement(
                          "button",
                          {
                            type: "button",
                            className: "btn btn-xs btn-outline-secondary py-0 px-1",
                            onClick: () => autoDetectFromFilename(sampleWithoutExt, "_"),
                          },
                          '"_"'
                        )
                      )
                    ),
                    // Word block items with Split, Edit, Merge, and Role Dropdown
                    React.createElement(
                      "div",
                      { className: "d-flex align-items-center flex-wrap gap-2 p-2 rounded bg-black border border-secondary" },
                      chunks.map((chunk, idx) => {
                        const fObj = FIELDS.find((f) => f.id === chunk.fieldId) || FIELDS[0];
                        const isSplitting = activeSplitChunkId === chunk.id;

                        // Calculate split suggestions (letters/digits, underscores, dashes)
                        const splitSuggestions = [];
                        const text = chunk.text;
                        const ldMatch = text.match(/^([A-Za-z]+)(\\d+)$/);
                        if (ldMatch) {
                          splitSuggestions.push({ p1: ldMatch[1], p2: ldMatch[2], f1: "studio", f2: "code", label: `"${ldMatch[1]}" (Studio) + "${ldMatch[2]}" (Code)` });
                        }
                        if (text.includes("_")) {
                          const parts = text.split("_");
                          if (parts.length > 1) {
                            splitSuggestions.push({ p1: parts[0], p2: parts.slice(1).join("_"), f1: chunk.fieldId, f2: "title", label: `"${parts[0]}" + "${parts.slice(1).join("_")}"` });
                            splitSuggestions.push({ p1: parts.slice(0, -1).join("_"), p2: parts[parts.length - 1], f1: chunk.fieldId, f2: "ignore", label: `"${parts.slice(0, -1).join("_")}" + "${parts[parts.length - 1]}"` });
                          }
                        }

                        return React.createElement(
                          "div",
                          {
                            key: chunk.id,
                            className: "sfm-chunk-box d-inline-flex flex-column rounded p-1 mr-1 mb-1 position-relative",
                            style: { border: `1px solid ${fObj.color}`, backgroundColor: "#1a1f2c" },
                          },
                          React.createElement(
                            "div",
                            { className: "d-flex align-items-center" },
                            React.createElement(
                              "span",
                              {
                                className: "font-weight-bold px-2 py-0",
                                style: { fontFamily: "monospace", fontSize: "0.88rem", color: "#eceff4" },
                                title: "Click to split this field or change its assignment",
                              },
                              chunk.text
                            ),
                            React.createElement(
                              "select",
                              {
                                className: "form-control form-control-sm border-0 py-0 px-1 font-weight-bold mr-1",
                                style: {
                                  width: "auto",
                                  height: "22px",
                                  fontSize: "0.76rem",
                                  backgroundColor: fObj.color,
                                  color: "#1e222a",
                                  borderRadius: "3px",
                                  cursor: "pointer",
                                },
                                value: chunk.fieldId,
                                onChange: (e) => handleSetChunkField(chunk.id, e.target.value),
                              },
                              FIELDS.map((f) => React.createElement("option", { key: f.id, value: f.id }, f.label))
                            ),
                            // ✂️ Split Button
                            React.createElement(
                              "button",
                              {
                                type: "button",
                                className: `btn btn-xs ${isSplitting ? "btn-warning" : "btn-outline-secondary"} py-0 px-1 mr-1`,
                                onClick: () => setActiveSplitChunkId(isSplitting ? null : chunk.id),
                                title: "Break / Split this field into two separate fields",
                              },
                              React.createElement(IconScissors, { size: 11 })
                            ),
                            // ▶ Merge with next button
                            idx < chunks.length - 1 &&
                              React.createElement(
                                "button",
                                {
                                  type: "button",
                                  className: "btn btn-xs btn-link text-muted p-0 mr-1",
                                  onClick: () => handleMergeWithNext(idx),
                                  title: "Merge with next field",
                                },
                                "▶"
                              ),
                            // ✕ Delete chunk button
                            React.createElement(
                              "button",
                              {
                                type: "button",
                                className: "btn btn-xs text-muted p-0 px-1",
                                onClick: () => handleDeleteChunk(chunk.id),
                                title: "Remove field",
                              },
                              "×"
                            )
                          ),
                          // Interactive Split Popover Bar
                          isSplitting &&
                            React.createElement(
                              "div",
                              {
                                className: "p-2 mt-1 rounded bg-black border border-warning shadow",
                                style: { minWidth: "220px", zIndex: 10 },
                              },
                              React.createElement("div", { className: "small font-weight-bold text-warning mb-1 d-flex align-items-center" }, React.createElement(IconScissors, { size: 12, className: "mr-1" }), `Break apart "${chunk.text}":`),
                              splitSuggestions.map((sug, sIdx) =>
                                React.createElement(
                                  "button",
                                  {
                                    key: sIdx,
                                    type: "button",
                                    className: "btn btn-xs btn-outline-info text-left d-block w-100 mb-1 py-1 px-2 font-weight-bold",
                                    style: { fontSize: "0.75rem" },
                                    onClick: () => handleSplitChunk(chunk.id, sug.p1, sug.p2, sug.f1, sug.f2),
                                  },
                                  `Break into: ${sug.label}`
                                )
                              ),
                              // Halfway custom split fallback
                              splitSuggestions.length === 0 &&
                                React.createElement(
                                  "div",
                                  { className: "d-flex align-items-center gap-1" },
                                  React.createElement(
                                    "button",
                                    {
                                      type: "button",
                                      className: "btn btn-xs btn-info py-0 px-2",
                                      onClick: () => {
                                        const half = Math.floor(chunk.text.length / 2);
                                        handleSplitChunk(chunk.id, chunk.text.substring(0, half), chunk.text.substring(half), chunk.fieldId, "title");
                                      },
                                    },
                                    "Split in half"
                                  )
                                )
                            )
                        );
                      })
                    )
                  ),
                  // Cleaner & Delimiter Settings
                  React.createElement(
                    "div",
                    { className: "d-flex align-items-center flex-wrap gap-3 small text-muted pt-2 border-top border-secondary" },
                    React.createElement(
                      "div",
                      { className: "d-flex align-items-center gap-1 cursor-pointer" },
                      React.createElement("input", {
                        type: "checkbox",
                        id: "sfm-clean-spaces",
                        checked: cleanSpaces,
                        onChange: (e) => setCleanSpaces(e.target.checked),
                      }),
                      React.createElement("label", { htmlFor: "sfm-clean-spaces", className: "mb-0 ml-1 text-light cursor-pointer" }, "Replace _ and . with spaces")
                    ),
                    React.createElement(
                      "div",
                      { className: "d-flex align-items-center gap-1 cursor-pointer" },
                      React.createElement("input", {
                        type: "checkbox",
                        id: "sfm-clean-titlecase",
                        checked: titleCase,
                        onChange: (e) => setTitleCase(e.target.checked),
                      }),
                      React.createElement("label", { htmlFor: "sfm-clean-titlecase", className: "mb-0 ml-1 text-light cursor-pointer" }, "Title Case")
                    ),
                    React.createElement(
                      "div",
                      { className: "d-flex align-items-center gap-1 cursor-pointer" },
                      React.createElement("input", {
                        type: "checkbox",
                        id: "sfm-clean-normdate",
                        checked: normalizeDate,
                        onChange: (e) => setNormalizeDate(e.target.checked),
                      }),
                      React.createElement("label", { htmlFor: "sfm-clean-normdate", className: "mb-0 ml-1 text-light cursor-pointer" }, "Normalize Date (YYYY-MM-DD)")
                    )
                  )
                )
              : React.createElement(
                  "div",
                  { className: "sfm-raw-builder-section mb-3" },
                  React.createElement(
                    "div",
                    { className: "form-group mb-2" },
                    React.createElement("label", { className: "small font-weight-bold" }, "Preset Patterns"),
                    React.createElement(
                      "select",
                      {
                        className: "form-control form-control-sm bg-dark text-light border-secondary",
                        onChange: (e) => {
                          const chosen = PRESETS.find((p) => p.pattern === e.target.value);
                          setPattern(e.target.value);
                          if (chosen && chosen.caseInsensitive !== undefined) {
                            setCaseInsensitive(chosen.caseInsensitive);
                          }
                        },
                      },
                      PRESETS.map((p) => React.createElement("option", { key: p.label, value: p.pattern }, p.label))
                    )
                  )
                ),
            // Pattern Display & Options
            React.createElement(
              "div",
              { className: "form-group mb-3" },
              React.createElement(
                "div",
                { className: "d-flex justify-content-between align-items-center mb-1" },
                React.createElement("label", { className: "small font-weight-bold mb-0" }, "Active Regular Expression"),
                React.createElement(
                  "div",
                  { className: "d-flex align-items-center gap-2 small text-muted" },
                  React.createElement("input", {
                    type: "checkbox",
                    id: "sfm-case-sens",
                    checked: caseInsensitive,
                    onChange: (e) => setCaseInsensitive(e.target.checked),
                  }),
                  React.createElement("label", { htmlFor: "sfm-case-sens", className: "mb-0 cursor-pointer" }, "Case insensitive (?i)")
                )
              ),
              React.createElement("input", {
                type: "text",
                className: "form-control font-weight-bold bg-dark text-info border-secondary sfm-regex-input",
                value: pattern,
                readOnly: builderMode === "guided",
                onChange: (e) => setPattern(e.target.value),
                style: { fontFamily: "monospace", fontSize: "0.9rem" },
              })
            ),
            parsedResults.error &&
              React.createElement("div", { className: "alert alert-danger py-2 px-3 small" }, `Regex Error: ${parsedResults.error}`),
            // Preview Filter Tabs & Count Header
            React.createElement(
              "div",
              { className: "d-flex justify-content-between align-items-center mb-2 flex-wrap gap-2" },
              React.createElement(
                "div",
                { className: "btn-group btn-group-sm" },
                React.createElement(
                  "button",
                  {
                    type: "button",
                    className: `btn btn-sm ${previewFilter === "all" ? "btn-secondary font-weight-bold" : "btn-outline-secondary"} py-0 px-2`,
                    onClick: () => setPreviewFilter("all"),
                  },
                  `All (${parsedResults.items.length})`
                ),
                React.createElement(
                  "button",
                  {
                    type: "button",
                    className: `btn btn-sm ${previewFilter === "matched" ? "btn-success font-weight-bold" : "btn-outline-secondary"} py-0 px-2`,
                    onClick: () => setPreviewFilter("matched"),
                  },
                  `Matched (${matchedCount})`
                ),
                React.createElement(
                  "button",
                  {
                    type: "button",
                    className: `btn btn-sm ${previewFilter === "unmatched" ? "btn-warning font-weight-bold" : "btn-outline-secondary"} py-0 px-2`,
                    onClick: () => setPreviewFilter("unmatched"),
                  },
                  `Unmatched (${unmatchedCount})`
                )
              ),
              React.createElement(
                "div",
                { className: "d-flex align-items-center gap-2" },
                React.createElement(
                  "button",
                  {
                    type: "button",
                    className: "btn btn-xs btn-outline-info py-0 px-2",
                    onClick: handleSelectAllMatched,
                  },
                  selectedSceneIds.size === matchedCount && matchedCount > 0 ? "Deselect All Matched" : "Select All Matched"
                ),
                React.createElement("span", { className: "badge badge-info" }, `${selectedSceneIds.size} of ${matchedCount} matched selected for update`)
              )
            ),
            // Live Preview Table
            React.createElement(
              "div",
              { className: "sfm-parser-table-wrap mb-3" },
              React.createElement(
                "table",
                { className: "sfm-parser-table table table-dark table-sm table-striped" },
                React.createElement(
                  "thead",
                  null,
                  React.createElement(
                    "tr",
                    null,
                    React.createElement(
                      "th",
                      { style: { width: "36px", textAlign: "center" } },
                      React.createElement("input", {
                        type: "checkbox",
                        checked: matchedCount > 0 && selectedSceneIds.size === matchedCount,
                        onChange: handleSelectAllMatched,
                      })
                    ),
                    React.createElement("th", null, "Filename"),
                    React.createElement("th", null, "Title"),
                    React.createElement("th", null, "Date"),
                    React.createElement("th", null, "StudioCode"),
                    React.createElement("th", null, "Studio"),
                    React.createElement("th", null, "Performers"),
                    React.createElement("th", { style: { width: "95px", textAlign: "center" } }, "Source"),
                    React.createElement("th", { style: { width: "80px", textAlign: "center" } }, "Status")
                  )
                ),
                React.createElement(
                  "tbody",
                  null,
                  filteredItems.map((item) => {
                    const isSelected = selectedSceneIds.has(item.scene.id);
                    const cloud = cloudMatches[item.scene.id];

                    const displayTitle = cloud?.title || cleanExtracted("title", item.groups.title);
                    const displayDate = cloud?.date || cleanExtracted("date", item.groups.date);
                    const displayCode = cloud?.code || item.groups.code || "—";
                    const displayStudio = cloud?.studio?.name || cleanExtracted("studio", item.groups.studio) || activeStudioClue || "—";
                    const displayPerformers = cloud?.performers ? cloud.performers.map((p) => p.name).join(", ") : (cleanExtracted("performers", item.groups.performers) || activePerformerClue || "—");

                    const isFromPathStudio = !cloud && !item.groups.studio && activeStudioClue;

                    return React.createElement(
                      "tr",
                      {
                        key: item.scene.id,
                        style: { cursor: item.matched ? "pointer" : "default", opacity: item.matched ? 1 : 0.65 },
                        onClick: () => item.matched && handleToggleSelectScene(item.scene.id),
                      },
                      React.createElement(
                        "td",
                        { style: { textAlign: "center" } },
                        item.matched &&
                          React.createElement("input", {
                            type: "checkbox",
                            checked: isSelected,
                            onChange: () => handleToggleSelectScene(item.scene.id),
                            onClick: (e) => e.stopPropagation(),
                          })
                      ),
                      React.createElement("td", { className: "text-truncate", style: { maxWidth: "180px" }, title: item.rawBasename }, item.rawBasename),
                      React.createElement("td", { className: "text-info font-weight-bold" }, displayTitle || "—"),
                      React.createElement("td", null, displayDate || "—"),
                      React.createElement("td", null, displayCode),
                      React.createElement(
                        "td",
                        null,
                        displayStudio !== "—"
                          ? React.createElement(
                              "span",
                              null,
                              displayStudio,
                              isFromPathStudio && React.createElement("span", { className: "badge badge-dark text-info ml-1 py-0", title: "Resolved from Directory Path Clue" }, React.createElement(IconFolder, { size: 11, className: "mr-1" }), "Path")
                            )
                          : "—"
                      ),
                      React.createElement("td", null, displayPerformers),
                      React.createElement(
                        "td",
                        { style: { textAlign: "center" } },
                        cloud
                          ? React.createElement("span", { className: "badge badge-primary py-0 px-1" }, React.createElement(IconGlobe, { size: 11, className: "mr-1" }), "Stash-box")
                          : item.matched
                          ? React.createElement("span", { className: "badge badge-dark text-muted py-0 px-1" }, React.createElement(IconFolder, { size: 11, className: "mr-1" }), "Path+Token")
                          : "—"
                      ),
                      React.createElement(
                        "td",
                        { style: { textAlign: "center" } },
                        item.matched
                          ? React.createElement("span", { className: "badge badge-success" }, "Matched")
                          : React.createElement("span", { className: "badge badge-secondary" }, "No Match")
                      )
                    );
                  })
                )
              )
            ),
            progressText && React.createElement("div", { className: "alert alert-info py-2 px-3 small" }, progressText)
          ),
          React.createElement(
            "div",
            { className: "sfm-modal-footer" },
            React.createElement("button", { className: "btn btn-secondary btn-sm", onClick: onClose }, "Cancel"),
            React.createElement(
              "button",
              {
                className: "btn btn-primary btn-sm font-weight-bold",
                disabled: isExecuting || selectedSceneIds.size === 0,
                onClick: handleExecute,
              },
              isExecuting ? "Executing Updates..." : `Apply to ${selectedSceneIds.size} Selected Scenes`
            )
          )
        )
      );
    }

    function BatchMetadataModal({ currentFolder, sceneCount, sceneIds, onClose, onApplied }) {
      const [studioName, setStudioName] = useState("");
      const [addPerformer, setAddPerformer] = useState("");
      const [addTag, setAddTag] = useState("");
      const [rating, setRating] = useState("");
      const [isSubmitting, setIsSubmitting] = useState(false);
      const [message, setMessage] = useState("");

      const handleApply = async () => {
        setIsSubmitting(true);
        setMessage("Processing batch assignments...");

        try {
          const input = { ids: sceneIds };

          if (studioName.trim()) {
            const sRes = await gqlFetch(
              `query FindStudio($name: String!) {
                findStudios(studio_filter: { name: { value: $name, modifier: EQUALS } }) {
                  studios { id name }
                }
              }`,
              { name: studioName.trim() }
            );
            const studio = sRes?.findStudios?.studios?.[0];
            if (studio) {
              input.studio_id = studio.id;
            } else {
              setMessage(`Studio "${studioName}" not found in database.`);
              setIsSubmitting(false);
              return;
            }
          }

          if (addPerformer.trim()) {
            const pRes = await gqlFetch(
              `query FindPerformer($name: String!) {
                findPerformers(performer_filter: { name: { value: $name, modifier: EQUALS } }) {
                  performers { id name }
                }
              }`,
              { name: addPerformer.trim() }
            );
            const performer = pRes?.findPerformers?.performers?.[0];
            if (performer) {
              input.performer_ids = { ids: [performer.id], mode: "ADD" };
            } else {
              setMessage(`Performer "${addPerformer}" not found in database.`);
              setIsSubmitting(false);
              return;
            }
          }

          if (addTag.trim()) {
            const tRes = await gqlFetch(
              `query FindTag($name: String!) {
                findTags(tag_filter: { name: { value: $name, modifier: EQUALS } }) {
                  tags { id name }
                }
              }`,
              { name: addTag.trim() }
            );
            let tag = tRes?.findTags?.tags?.[0];
            if (!tag) {
              // Create tag if not exists
              const createRes = await gqlFetch(
                `mutation CreateTag($name: String!) {
                  tagCreate(input: { name: $name }) { id name }
                }`,
                { name: addTag.trim() }
              );
              tag = createRes?.tagCreate;
            }
            if (tag) {
              input.tag_ids = { ids: [tag.id], mode: "ADD" };
            }
          }

          if (rating !== "") {
            const num = parseInt(rating, 10);
            if (!isNaN(num) && num >= 0 && num <= 100) {
              input.rating100 = num;
            }
          }

          if (!input.studio_id && !input.performer_ids && !input.tag_ids && input.rating100 === undefined) {
            setMessage("Please fill out at least one field to batch update.");
            setIsSubmitting(false);
            return;
          }

          await gqlFetch(
            `mutation BatchAssign($input: BulkSceneUpdateInput!) {
              bulkSceneUpdate(input: $input) { id }
            }`,
            { input }
          );

          setMessage(`Successfully updated ${sceneIds.length} scenes.`);
          setTimeout(() => {
            clearCachedScenes();
            onApplied();
            onClose();
          }, 1200);
        } catch (err) {
          console.error(err);
          setMessage(`Error: ${err.message}`);
          setIsSubmitting(false);
        }
      };

      return React.createElement(
        "div",
        { className: "sfm-modal-backdrop", onClick: onClose },
        React.createElement(
          "div",
          { className: "sfm-modal-dialog", onClick: (e) => e.stopPropagation() },
          React.createElement(
            "div",
            { className: "sfm-modal-header" },
            React.createElement("h5", { className: "mb-0 d-flex align-items-center" }, React.createElement(IconEdit, { size: 16, color: "#88c0d0", className: "mr-2" }), `Batch Edit: "${currentFolder}"`),
            React.createElement("button", { className: "close text-light", onClick: onClose }, "×")
          ),
          React.createElement(
            "div",
            { className: "sfm-modal-body" },
            React.createElement("p", { className: "text-muted small mb-3" }, `Apply shared metadata to all ${sceneCount} scenes inside this folder.`),
            React.createElement(
              "div",
              { className: "form-group mb-3" },
              React.createElement("label", { className: "small font-weight-bold" }, "Assign Studio"),
              React.createElement("input", {
                type: "text",
                className: "form-control bg-dark text-light border-secondary",
                placeholder: "e.g. Wicked Pictures",
                value: studioName,
                onChange: (e) => setStudioName(e.target.value),
              })
            ),
            React.createElement(
              "div",
              { className: "form-group mb-3" },
              React.createElement("label", { className: "small font-weight-bold" }, "Add Performer"),
              React.createElement("input", {
                type: "text",
                className: "form-control bg-dark text-light border-secondary",
                placeholder: "e.g. Angela White",
                value: addPerformer,
                onChange: (e) => setAddPerformer(e.target.value),
              })
            ),
            React.createElement(
              "div",
              { className: "form-group mb-3" },
              React.createElement("label", { className: "small font-weight-bold" }, "Add Tag (Created automatically if new)"),
              React.createElement("input", {
                type: "text",
                className: "form-control bg-dark text-light border-secondary",
                placeholder: "e.g. 4K, VR, Favorites",
                value: addTag,
                onChange: (e) => setAddTag(e.target.value),
              })
            ),
            React.createElement(
              "div",
              { className: "form-group mb-3" },
              React.createElement("label", { className: "small font-weight-bold" }, "Set Rating (Stars)"),
              React.createElement(
                "select",
                {
                  className: "form-control bg-dark text-light border-secondary",
                  value: rating,
                  onChange: (e) => setRating(e.target.value),
                },
                React.createElement("option", { value: "" }, "Keep existing ratings"),
                React.createElement("option", { value: "100" }, "★★★★★ (5 Stars - 100%)"),
                React.createElement("option", { value: "80" }, "★★★★☆ (4 Stars - 80%)"),
                React.createElement("option", { value: "60" }, "★★★☆☆ (3 Stars - 60%)"),
                React.createElement("option", { value: "40" }, "★★☆☆☆ (2 Stars - 40%)"),
                React.createElement("option", { value: "20" }, "★☆☆☆☆ (1 Star - 20%)"),
                React.createElement("option", { value: "0" }, "Clear Rating (0%)")
              )
            ),
            message && React.createElement("div", { className: "alert alert-info py-2 px-3 small mt-2" }, message)
          ),
          React.createElement(
            "div",
            { className: "sfm-modal-footer" },
            React.createElement("button", { className: "btn btn-secondary btn-sm", onClick: onClose }, "Cancel"),
            React.createElement(
              "button",
              { className: "btn btn-primary btn-sm", disabled: isSubmitting, onClick: handleApply },
              isSubmitting ? "Updating..." : `Apply to ${sceneCount} Scenes`
            )
          )
        )
      );
    }

    // ==========================================
    // Scene Card Component with Hover Preview (Feature 3)
    // ==========================================
    function SceneCard({ scene, onPlay, isSelected, onToggleSelect, showFolderBadge, currentPath }) {
      const [isHovered, setIsHovered] = useState(false);
      const thumbUrl = scene.paths?.screenshot || `/scene/${scene.id}/screenshot`;
      const previewVideoUrl = scene.paths?.preview || `/scene/${scene.id}/preview`;
      const studioName = scene.studio?.name;
      const performers = scene.performers?.map((p) => p.name).join(", ");
      const duration = formatDuration(scene.files?.[0]?.duration);
      const resolution = scene.files?.[0]?.height ? (scene.files[0].height >= 2160 ? "4K" : scene.files[0].height >= 1440 ? "1440p" : scene.files[0].height >= 1080 ? "1080p" : scene.files[0].height >= 720 ? "720p" : null) : null;

      return React.createElement(
        "div",
        { className: `card scene-card sfm-scene-card sfm-native-scene-card ${isSelected ? "sfm-card-selected" : ""}` },
        // Selection Checkbox Overlay
        React.createElement(
          "div",
          {
            className: `sfm-card-select-wrap ${isSelected ? "sfm-selected" : ""}`,
            onClick: (e) => {
              e.stopPropagation();
              onToggleSelect(scene.id);
            },
            title: isSelected ? "Deselect Scene" : "Select Scene",
          },
          React.createElement("input", {
            type: "checkbox",
            checked: !!isSelected,
            onChange: () => {},
            className: "sfm-card-checkbox",
          })
        ),
        React.createElement(
          "div",
          {
            className: "card-image-container image-container sfm-scene-thumb-container",
            onMouseEnter: () => setIsHovered(true),
            onMouseLeave: () => setIsHovered(false),
            onClick: () => onPlay(scene),
          },
          React.createElement("img", {
            src: thumbUrl,
            alt: scene.title || "Scene",
            className: "card-image sfm-scene-thumb",
            loading: "lazy",
          }),
          isHovered &&
            React.createElement("video", {
              src: previewVideoUrl,
              autoPlay: true,
              loop: true,
              muted: true,
              playsInline: true,
              className: "sfm-scene-preview-video",
            }),
          React.createElement(
            "div",
            { className: "sfm-play-overlay" },
            React.createElement("span", { style: { fontSize: "1.2rem", marginLeft: "2px" } }, "▶")
          ),
          duration && React.createElement("div", { className: "sfm-duration-badge" }, duration),
          resolution && React.createElement("div", { className: "sfm-resolution-badge" }, resolution)
        ),
        React.createElement(
          "div",
          { className: "card-section scene-card__details sfm-scene-info p-2" },
          React.createElement(
            "div",
            { className: "scene-card__title" },
            React.createElement(
              "a",
              {
                href: `/scenes/${scene.id}`,
                target: "_blank",
                rel: "noreferrer",
                className: "sfm-scene-title font-weight-bold",
                title: scene.title || scene.files?.[0]?.basename,
              },
              scene.title || scene.files?.[0]?.basename || `Scene #${scene.id}`
            )
          ),
          studioName &&
            React.createElement(
              "div",
              { className: "badge badge-primary text-truncate mb-1", style: { maxWidth: "100%" } },
              studioName
            ),
          performers && React.createElement("div", { className: "text-truncate small text-info mb-1" }, performers),
          showFolderBadge && scene._folderPath && (() => {
            const relFolder = currentPath && scene._folderPath.startsWith(currentPath + "/")
              ? scene._folderPath.slice(currentPath.length + 1)
              : (currentPath === scene._folderPath ? "" : scene._folderPath);
            return relFolder ? React.createElement("div", { className: "text-truncate small text-muted mb-1 d-flex align-items-center", title: `Folder: ${scene._folderPath}` }, React.createElement(IconFolder, { size: 11, className: "mr-1 text-info" }), relFolder) : null;
          })(),
          React.createElement(
            "div",
            { className: "sfm-scene-meta d-flex justify-content-between align-items-center small text-muted mt-1" },
            React.createElement("span", null, scene.date || "No date"),
            scene.rating100 &&
              React.createElement("span", { className: "text-warning" }, `★ ${(scene.rating100 / 20).toFixed(1)}`)
          )
        )
      );
    }

    // ==========================================
    // Detailed Table/List View Component (Milestone 2)
    // ==========================================
    function SceneTableView({ scenes, onPlay, selectedIds, onToggleSelect, onSelectAll, showFolderBadge, currentPath }) {
      const allSelected = scenes.length > 0 && scenes.every((s) => selectedIds.has(s.id));

      return React.createElement(
        "div",
        { className: "sfm-table-wrap" },
        React.createElement(
          "table",
          { className: "sfm-data-table" },
          React.createElement(
            "thead",
            null,
            React.createElement(
              "tr",
              null,
              React.createElement(
                "th",
                { style: { width: "40px", textAlign: "center" } },
                React.createElement("input", {
                  type: "checkbox",
                  checked: allSelected,
                  onChange: onSelectAll,
                  title: "Select All / None",
                })
              ),
              React.createElement("th", { style: { width: "80px" } }, "Preview"),
              React.createElement("th", null, "Title & Filename"),
              React.createElement("th", { style: { width: "130px" } }, "Studio"),
              React.createElement("th", { style: { width: "150px" } }, "Performers"),
              React.createElement("th", { style: { width: "85px" } }, "Duration"),
              React.createElement("th", { style: { width: "90px" } }, "Size"),
              React.createElement("th", { style: { width: "100px" } }, "Date"),
              React.createElement("th", { style: { width: "85px" } }, "Rating"),
              React.createElement("th", { style: { width: "90px", textAlign: "center" } }, "Actions")
            )
          ),
          React.createElement(
            "tbody",
            null,
            scenes.map((scene) => {
              const isSelected = selectedIds.has(scene.id);
              const thumbUrl = scene.paths?.screenshot || `/scene/${scene.id}/screenshot`;
              const duration = formatDuration(scene.files?.[0]?.duration);
              const size = formatBytes(scene.files?.[0]?.size);
              const studioName = scene.studio?.name;
              const performers = scene.performers?.map((p) => p.name).join(", ");
              const filename = scene.files?.[0]?.basename || "";

              return React.createElement(
                "tr",
                { key: scene.id, className: isSelected ? "sfm-row-selected" : "" },
                React.createElement(
                  "td",
                  { style: { textAlign: "center" } },
                  React.createElement("input", {
                    type: "checkbox",
                    checked: isSelected,
                    onChange: () => onToggleSelect(scene.id),
                  })
                ),
                React.createElement(
                  "td",
                  null,
                  React.createElement(
                    "div",
                    {
                      className: "sfm-table-thumb-wrap",
                      onClick: () => onPlay(scene),
                      title: "Click to play inline",
                    },
                    React.createElement("img", {
                      src: thumbUrl,
                      alt: scene.title || "",
                      className: "sfm-table-thumb",
                      loading: "lazy",
                    }),
                    React.createElement("span", { className: "sfm-table-play-icon" }, "▶")
                  )
                ),
                React.createElement(
                  "td",
                  null,
                  React.createElement(
                    "a",
                    {
                      href: `/scenes/${scene.id}`,
                      target: "_blank",
                      rel: "noreferrer",
                      className: "sfm-table-title",
                    },
                    scene.title || filename || `Scene #${scene.id}`
                  ),
                  filename &&
                    scene.title &&
                    React.createElement("div", { className: "sfm-table-subtext" }, filename),
                  showFolderBadge && scene._folderPath && (() => {
                    const relFolder = currentPath && scene._folderPath.startsWith(currentPath + "/")
                      ? scene._folderPath.slice(currentPath.length + 1)
                      : (currentPath === scene._folderPath ? "" : scene._folderPath);
                    return relFolder ? React.createElement("div", { className: "sfm-table-subtext text-muted d-flex align-items-center" }, React.createElement(IconFolder, { size: 10, className: "mr-1 text-info" }), relFolder) : null;
                  })()
                ),
                React.createElement(
                  "td",
                  null,
                  studioName
                    ? React.createElement("span", { className: "badge badge-primary text-truncate d-inline-block", style: { maxWidth: "120px" } }, studioName)
                    : React.createElement("span", { className: "text-muted small" }, "—")
                ),
                React.createElement(
                  "td",
                  null,
                  performers
                    ? React.createElement("span", { className: "text-info small text-truncate d-inline-block", style: { maxWidth: "140px" } }, performers)
                    : React.createElement("span", { className: "text-muted small" }, "—")
                ),
                React.createElement("td", { className: "small text-muted" }, duration || "—"),
                React.createElement("td", { className: "small text-muted" }, size),
                React.createElement("td", { className: "small text-muted" }, scene.date || "—"),
                React.createElement(
                  "td",
                  null,
                  scene.rating100
                    ? React.createElement("span", { className: "text-warning small" }, `★ ${(scene.rating100 / 20).toFixed(1)}`)
                    : React.createElement("span", { className: "text-muted small" }, "—")
                ),
                React.createElement(
                  "td",
                  { style: { textAlign: "center" } },
                  React.createElement(
                    "div",
                    { className: "btn-group btn-group-sm" },
                    React.createElement(
                      "button",
                      {
                        className: "btn btn-outline-info py-0 px-2",
                        onClick: () => onPlay(scene),
                        title: "Play video",
                      },
                      "▶"
                    ),
                    React.createElement(
                      "a",
                      {
                        href: `/scenes/${scene.id}`,
                        target: "_blank",
                        rel: "noreferrer",
                        className: "btn btn-outline-secondary py-0 px-2",
                        title: "Open scene details",
                      },
                      "↗"
                    )
                  )
                )
              );
            })
          )
        )
      );
    }


    // ==========================================
    // Filenames Only Table View Component (for Easy Bulk Editing)
    // ==========================================
    function SceneNamesTableView({ scenes, onPlay, selectedIds, onToggleSelect, onSelectAll, showFolderBadge, currentPath }) {
      const allSelected = scenes.length > 0 && scenes.every((s) => selectedIds.has(s.id));

      return React.createElement(
        "div",
        { className: "sfm-table-wrap sfm-names-table-wrap" },
        React.createElement(
          "table",
          { className: "sfm-data-table sfm-names-table" },
          React.createElement(
            "thead",
            null,
            React.createElement(
              "tr",
              null,
              React.createElement(
                "th",
                { style: { width: "36px", textAlign: "center" } },
                React.createElement("input", {
                  type: "checkbox",
                  checked: allSelected,
                  onChange: onSelectAll,
                  title: "Select All / None",
                })
              ),
              React.createElement("th", null, "File Name (Basename)"),
              React.createElement("th", { style: { minWidth: "180px" } }, "Title"),
              showFolderBadge && React.createElement("th", { style: { width: "160px" } }, "Folder"),
              React.createElement("th", { style: { width: "90px" } }, "Duration"),
              React.createElement("th", { style: { width: "90px" } }, "Size"),
              React.createElement("th", { style: { width: "70px", textAlign: "center" } }, "Play")
            )
          ),
          React.createElement(
            "tbody",
            null,
            scenes.map((scene) => {
              const isSelected = selectedIds.has(scene.id);
              const filename = scene.files?.[0]?.basename || "Unknown file";
              const duration = formatDuration(scene.files?.[0]?.duration);
              const size = formatBytes(scene.files?.[0]?.size);

              return React.createElement(
                "tr",
                {
                  key: scene.id,
                  className: `sfm-names-row ${isSelected ? "sfm-row-selected" : ""}`,
                  onClick: (e) => {
                    if (e.target.tagName !== "INPUT" && e.target.tagName !== "BUTTON" && !e.target.closest("button")) {
                      onToggleSelect(scene.id);
                    }
                  },
                  style: { cursor: "pointer" },
                  title: "Click row to toggle selection",
                },
                React.createElement(
                  "td",
                  { style: { textAlign: "center" } },
                  React.createElement("input", {
                    type: "checkbox",
                    checked: isSelected,
                    onChange: () => onToggleSelect(scene.id),
                    onClick: (e) => e.stopPropagation(),
                  })
                ),
                React.createElement(
                  "td",
                  null,
                  React.createElement(
                    "span",
                    { className: "sfm-filename-text font-weight-bold text-light", style: { fontFamily: "monospace", fontSize: "0.88rem" } },
                    filename
                  )
                ),
                React.createElement(
                  "td",
                  { className: "text-truncate", style: { maxWidth: "240px" } },
                  scene.title || React.createElement("span", { className: "text-muted font-italic" }, "No title")
                ),
                showFolderBadge && React.createElement(
                  "td",
                  null,
                  scene._folderPath
                    ? React.createElement("span", { className: "badge badge-dark text-muted", title: scene._folderPath }, scene._folderPath)
                    : "-"
                ),
                React.createElement("td", { className: "text-muted small" }, duration),
                React.createElement("td", { className: "text-muted small" }, size),
                React.createElement(
                  "td",
                  { style: { textAlign: "center" } },
                  React.createElement(
                    "button",
                    {
                      type: "button",
                      className: "btn btn-xs btn-outline-info py-0 px-2",
                      onClick: (e) => {
                        e.stopPropagation();
                        onPlay(scene);
                      },
                      title: "Play video",
                    },
                    "▶"
                  )
                )
              );
            })
          )
        )
      );
    }

    // ==========================================
    // Modal: Plugin Settings & Troubleshooting Tasks
    // ==========================================
    function SettingsAndTasksModal({ isOpen, onClose, settings, onSaveSettings, onTriggerRebuild, onResetDefaults }) {
      const [formData, setFormData] = useState({
        default_transcode_method: settings?.default_transcode_method || "direct",
        fallback_transcode_method: settings?.fallback_transcode_method || "hls",
        root_library_path: settings?.root_library_path || "",
        folder_view_mode: settings?.folder_view_mode || "cards",
        scene_view_mode: settings?.scene_view_mode || "cards",
        default_sort_field: settings?.default_sort_field || "name",
        default_sort_direction: settings?.default_sort_direction || "asc",
        folder_card_size: settings?.folder_card_size || 160,
        scene_card_size: settings?.scene_card_size || 240,
        remember_last_path: settings?.remember_last_path !== false,
        auto_rebuild_tree_on_start: !!settings?.auto_rebuild_tree_on_start,
      });
      const [isSaving, setIsSaving] = useState(false);
      const [saveNotice, setSaveNotice] = useState("");

      useEffect(() => {
        if (isOpen && settings) {
          setFormData({
            default_transcode_method: settings?.default_transcode_method || "direct",
            fallback_transcode_method: settings?.fallback_transcode_method || "hls",
            root_library_path: settings?.root_library_path || "",
            folder_view_mode: settings?.folder_view_mode || "cards",
            scene_view_mode: settings?.scene_view_mode || "cards",
            default_sort_field: settings?.default_sort_field || "name",
            default_sort_direction: settings?.default_sort_direction || "asc",
            folder_card_size: settings?.folder_card_size || 160,
            scene_card_size: settings?.scene_card_size || 240,
            remember_last_path: settings?.remember_last_path !== false,
            auto_rebuild_tree_on_start: !!settings?.auto_rebuild_tree_on_start,
          });
        }
      }, [isOpen, settings]);

      const handleChange = (key, value) => {
        setFormData((prev) => ({ ...prev, [key]: value }));
      };

      const handleSave = async () => {
        setIsSaving(true);
        setSaveNotice("Saving to Stash configuration...");
        try {
          await onSaveSettings(formData);
          setSaveNotice("✓ Saved to Stash config.yml!");
          setTimeout(() => {
            setSaveNotice("");
            onClose();
          }, 1000);
        } catch (e) {
          setSaveNotice(`Error: ${e.message}`);
        } finally {
          setIsSaving(false);
        }
      };

      if (!isOpen) return null;

      return React.createElement(
        "div",
        { className: "sfm-modal-backdrop", onClick: onClose },
        React.createElement(
          "div",
          {
            className: "sfm-modal-dialog",
            style: { maxWidth: "680px", width: "95%" },
            onClick: (e) => e.stopPropagation(),
          },
          React.createElement(
            "div",
            { className: "sfm-modal-header" },
            React.createElement("h5", { className: "mb-0" }, React.createElement(IconSettings, { size: 18, color: "#88c0d0", className: "mr-2" }), "Stash File Manager — Settings & Tasks"),
            React.createElement("button", { className: "close text-light", onClick: onClose }, "×")
          ),
          React.createElement(
            "div",
            { className: "sfm-modal-body", style: { maxHeight: "75vh", overflowY: "auto" } },
            saveNotice &&
              React.createElement(
                "div",
                { className: `alert ${saveNotice.startsWith("✓") ? "alert-success" : "alert-info"} py-2` },
                saveNotice
              ),

            // Section 1: Video Playback & Transcoding
            React.createElement("h6", { className: "text-primary border-bottom border-secondary pb-1 mb-3 d-flex align-items-center" }, React.createElement(IconFilm, { size: 15, color: "#88c0d0", className: "mr-2" }), "Video Playback & Transcoding"),
            React.createElement(
              "div",
              { className: "form-group mb-3" },
              React.createElement("label", { className: "small font-weight-bold" }, "Default Playback Stream Mode"),
              React.createElement(
                "select",
                {
                  className: "form-control bg-dark text-light border-secondary",
                  value: formData.default_transcode_method,
                  onChange: (e) => handleChange("default_transcode_method", e.target.value),
                },
                React.createElement("option", { value: "direct" }, "Direct Stream (Raw file - fastest, native containers)"),
                React.createElement("option", { value: "webm" }, "WebM Transcode (Progressive transcode, broad compatibility)"),
                React.createElement("option", { value: "hls" }, "HLS Stream (.m3u8 adaptive segmented stream)")
              ),
              React.createElement(
                "small",
                { className: "form-text text-muted" },
                "Configures the default playback stream method for the Binge Reel Player and floating PIP player."
              )
            ),
            React.createElement(
              "div",
              { className: "form-group mb-3" },
              React.createElement("label", { className: "small font-weight-bold" }, "Fallback Transcode Mode (Non-Native Formats)"),
              React.createElement(
                "select",
                {
                  className: "form-control bg-dark text-light border-secondary",
                  value: formData.fallback_transcode_method,
                  onChange: (e) => handleChange("fallback_transcode_method", e.target.value),
                },
                React.createElement("option", { value: "hls" }, "HLS Stream (.m3u8 adaptive stream - recommended)"),
                React.createElement("option", { value: "webm" }, "WebM Transcode (Progressive container)")
              ),
              React.createElement(
                "small",
                { className: "form-text text-muted" },
                "Used automatically when playing non-native video formats (.avi, .flv, .wmv, .mpg)."
              )
            ),

            // Section 2: Navigation & Root Library Path
            React.createElement("h6", { className: "text-primary border-bottom border-secondary pb-1 mb-3 mt-4 d-flex align-items-center" }, React.createElement(IconFolder, { size: 15, color: "#88c0d0", className: "mr-2" }), "Navigation & Library Root"),
            React.createElement(
              "div",
              { className: "form-group mb-3" },
              React.createElement("label", { className: "small font-weight-bold" }, "Root Library Path Override"),
              React.createElement("input", {
                type: "text",
                className: "form-control bg-dark text-light border-secondary",
                placeholder: "Leave empty to auto-detect Stash library paths",
                value: formData.root_library_path,
                onChange: (e) => handleChange("root_library_path", e.target.value),
              }),
              React.createElement(
                "small",
                { className: "form-text text-muted" },
                "Set an explicit root path (e.g. /data/videos or D:\\Media) to anchor File Manager navigation."
              )
            ),
            React.createElement(
              "div",
              { className: "form-group form-check mb-3" },
              React.createElement("input", {
                type: "checkbox",
                className: "form-check-input",
                id: "sfm_chk_remember_path",
                checked: formData.remember_last_path,
                onChange: (e) => handleChange("remember_last_path", e.target.checked),
              }),
              React.createElement(
                "label",
                { className: "form-check-label small font-weight-bold", htmlFor: "sfm_chk_remember_path" },
                "Remember Last Visited Folder Across Sessions"
              )
            ),

            // Section 3: View Modes & Card Sizes
            React.createElement("h6", { className: "text-primary border-bottom border-secondary pb-1 mb-3 mt-4 d-flex align-items-center" }, React.createElement(IconGrid, { size: 15, color: "#88c0d0", className: "mr-2" }), "View Modes & Layout Preferences"),
            React.createElement(
              "div",
              { className: "row" },
              React.createElement(
                "div",
                { className: "col-sm-6 form-group mb-3" },
                React.createElement("label", { className: "small font-weight-bold" }, "Default Folder View Mode"),
                React.createElement(
                  "select",
                  {
                    className: "form-control bg-dark text-light border-secondary",
                    value: formData.folder_view_mode,
                    onChange: (e) => handleChange("folder_view_mode", e.target.value),
                  },
                  React.createElement("option", { value: "cards" }, "Cards (Thumbnails)"),
                  React.createElement("option", { value: "list" }, "List (Compact)"),
                  React.createElement("option", { value: "details" }, "Details (Table with Stats)")
                )
              ),
              React.createElement(
                "div",
                { className: "col-sm-6 form-group mb-3" },
                React.createElement("label", { className: "small font-weight-bold" }, "Default Scene View Mode"),
                React.createElement(
                  "select",
                  {
                    className: "form-control bg-dark text-light border-secondary",
                    value: formData.scene_view_mode,
                    onChange: (e) => handleChange("scene_view_mode", e.target.value),
                  },
                  React.createElement("option", { value: "cards" }, "Cards (16:9 Grid)"),
                  React.createElement("option", { value: "table" }, "Table (Metadata Columns)"),
                  React.createElement("option", { value: "names" }, "Names (Filenames Only)")
                )
              )
            ),
            React.createElement(
              "div",
              { className: "row" },
              React.createElement(
                "div",
                { className: "col-sm-6 form-group mb-3" },
                React.createElement("label", { className: "small font-weight-bold" }, `Folder Card Size: ${formData.folder_card_size}px`),
                React.createElement("input", {
                  type: "range",
                  className: "form-control-range",
                  min: 120,
                  max: 300,
                  step: 10,
                  value: formData.folder_card_size,
                  onChange: (e) => handleChange("folder_card_size", Number(e.target.value)),
                })
              ),
              React.createElement(
                "div",
                { className: "col-sm-6 form-group mb-3" },
                React.createElement("label", { className: "small font-weight-bold" }, `Scene Card Size: ${formData.scene_card_size}px`),
                React.createElement("input", {
                  type: "range",
                  className: "form-control-range",
                  min: 160,
                  max: 420,
                  step: 10,
                  value: formData.scene_card_size,
                  onChange: (e) => handleChange("scene_card_size", Number(e.target.value)),
                })
              )
            ),

            // Section 4: Native Stash Tasks & Troubleshooting
            React.createElement("h6", { className: "text-primary border-bottom border-secondary pb-1 mb-3 mt-4 d-flex align-items-center" }, React.createElement(IconRefresh, { size: 15, color: "#88c0d0", className: "mr-2" }), "Stash Plugin Tasks & Troubleshooting"),
            React.createElement(
              "p",
              { className: "small text-muted mb-3" },
              "These operations are registered as native tasks under ",
              React.createElement("code", { className: "text-warning" }, "Settings → Tasks → Plugin Tasks"),
              "."
            ),
            React.createElement(
              "div",
              { className: "d-flex flex-wrap gap-2 mb-3" },
              React.createElement(
                "button",
                {
                  className: "btn btn-outline-info btn-sm mr-2 mb-2",
                  onClick: onTriggerRebuild,
                  title: "Clear all local cache and query Stash for fresh folder hierarchies",
                },
                React.createElement(IconRefresh, { size: 14, className: "mr-1" }), "Rescan & Rebuild Tree"
              ),
              React.createElement(
                "button",
                {
                  className: "btn btn-outline-danger btn-sm mr-2 mb-2",
                  onClick: onResetDefaults,
                  title: "Reset all plugin settings back to initial factory defaults",
                },
                React.createElement(IconAlert, { size: 14, className: "mr-1" }), "Reset All Settings to Default"
              ),
              React.createElement(
                "a",
                {
                  href: "/settings?tab=plugins",
                  target: "_blank",
                  rel: "noopener noreferrer",
                  className: "btn btn-outline-secondary btn-sm mr-2 mb-2",
                },
                "↗ Open Stash Plugins Page"
              ),
              React.createElement(
                "a",
                {
                  href: "/settings?tab=tasks",
                  target: "_blank",
                  rel: "noopener noreferrer",
                  className: "btn btn-outline-secondary btn-sm mb-2",
                },
                "↗ Open Stash Tasks Page"
              )
            )
          ),
          React.createElement(
            "div",
            { className: "sfm-modal-footer d-flex justify-content-between align-items-center" },
            React.createElement(
              "span",
              { className: "small text-muted" },
              "Settings are saved to Stash config and synchronized across browsers."
            ),
            React.createElement(
              "div",
              null,
              React.createElement("button", { className: "btn btn-secondary btn-sm mr-2", onClick: onClose }, "Cancel"),
              React.createElement(
                "button",
                { className: "btn btn-primary btn-sm", onClick: handleSave, disabled: isSaving },
                React.createElement(IconCheck, { size: 14, className: "mr-1" }), isSaving ? "Saving..." : "Save to Stash Config"
              )
            )
          )
        )
      );
    }

    // ==========================================
    // Main App Component (Features 5, 1, 2, 3, 4)
    // ==========================================
    function FileManagerView({ onClose, initialPath }) {
      const [trie, setTrie] = useState(null);
      
      const historyStack = useRef([]);

      // History & Folder Memory Synchronization
      const [currentPath, setCurrentPath] = useState(() => {
        if (typeof initialPath === "string") return normalizePath(initialPath);
        const fromHash = getPathFromHash();
        if (fromHash !== null) return fromHash;
        return normalizePath(localStorage.getItem("sfm_last_folder_path") || "");
      });

      const navigateToFolder = useCallback((nextPath) => {
        const normalizedNext = normalizePath(nextPath);
        if (normalizedNext !== currentPath) {
          historyStack.current.push(currentPath);
        }
        setCurrentPath(normalizedNext);
        localStorage.setItem("sfm_last_folder_path", normalizedNext);
        const targetHash = buildHashForPath(normalizedNext);
        const currentHashDecoded = normalizePath(getPathFromHash());
        if (currentHashDecoded !== normalizedNext) {
          const nextDepth = getNextSfmDepth();
          window.history.pushState({ sfmPath: normalizedNext, sfmDepth: nextDepth }, "", targetHash);
        }
      }, [currentPath]);

      // Handle in-app Go Back (steps backward through folder history)
      const handleGoBackInHistory = useCallback(() => {
        if (historyStack.current.length > 0) {
          const prev = historyStack.current.pop();
          const normalizedPrev = normalizePath(prev);
          setCurrentPath(normalizedPrev);
          localStorage.setItem("sfm_last_folder_path", normalizedPrev);
          const targetHash = buildHashForPath(normalizedPrev);
          if (normalizePath(getPathFromHash()) !== normalizedPrev) {
            window.history.pushState({ sfmPath: normalizedPrev }, "", targetHash);
          }
        } else if (currentPath) {
          const segs = currentPath.split("/").filter(Boolean);
          const parent = segs.slice(0, -1).join("/");
          navigateToFolder(parent);
        }
      }, [currentPath, navigateToFolder]);

      const handleGoUpOneLevel = useCallback(() => {
        if (!currentPath) return;
        const segs = currentPath.split("/").filter(Boolean);
        const parent = segs.slice(0, -1).join("/");
        navigateToFolder(parent);
      }, [currentPath, navigateToFolder]);

      // Custom event listener for inter-component folder navigation
      useEffect(() => {
        const handleCustomPath = (e) => {
          if (e.detail && typeof e.detail.path === "string") {
            const p = normalizePath(e.detail.path);
            if (e.detail.view) {
              setShowFolderProfile(true);
              setCurrentProfilePage(e.detail.view === "discover" ? 1 : 0);
            } else if (e.detail.view === null && !e.detail.sceneId) {
              setShowFolderProfile(false);
            }
            if (e.detail.sceneId) {
              const allAvailable = window.__SFM_GLOBAL_CACHE__?.scenes || [];
              const found = allAvailable.find((s) => String(s.id) === String(e.detail.sceneId)) || { id: e.detail.sceneId };
              setPlayingScene(found);
            }
            if (e.detail.isBrowserNav) {
              if (p !== currentPath) {
                setCurrentPath(p);
                localStorage.setItem("sfm_last_folder_path", p);
              }
            } else {
              navigateToFolder(p);
            }
          }
        };
        window.addEventListener("sfm:set-path", handleCustomPath);
        return () => window.removeEventListener("sfm:set-path", handleCustomPath);
      }, [navigateToFolder, currentPath]);

      const [loading, setLoading] = useState(true);
      const [statusText, setStatusText] = useState("Checking cache...");
      const [refreshKey, setRefreshKey] = useState(0);
      const [notification, setNotification] = useState("");
      
      // Feature 2: Search & Sort
      const [searchQuery, setSearchQuery] = useState("");
      const searchInputRef = useRef(null);
      const [folderSort, setFolderSort] = useState("name_asc");
      const [sceneSort, setSceneSort] = useState("title_asc");

      // Feature 4: Hide Empty Folders
      const [hideEmpty, setHideEmpty] = useState(() => {
        try {
          return window.localStorage.getItem("sfm_hide_empty") === "true";
        } catch (e) {
          return false;
        }
      });

      // Collapsible Subfolders & Files Sections
      const [isSubfoldersCollapsed, setIsSubfoldersCollapsed] = useState(() => {
        try {
          return window.localStorage.getItem("sfm_subfolders_collapsed") === "true";
        } catch (e) {
          return false;
        }
      });

      const [isFilesCollapsed, setIsFilesCollapsed] = useState(() => {
        try {
          return window.localStorage.getItem("sfm_files_collapsed") === "true";
        } catch (e) {
          return false;
        }
      });

      // Include Sub-folders Toggle State (persisted in localStorage)
      const [includeSubfolders, setIncludeSubfolders] = useState(() => {
        try {
          return window.localStorage.getItem("sfm_include_subfolders") === "true";
        } catch (e) {
          return false;
        }
      });

      const handleToggleIncludeSubfolders = useCallback((val) => {
        setIncludeSubfolders(val);
        try {
          window.localStorage.setItem("sfm_include_subfolders", String(val));
        } catch (e) {}
      }, []);

      // Sort by Folder First State (persisted in localStorage, defaults to true)
      const [sortByFolderFirst, setSortByFolderFirst] = useState(() => {
        try {
          const val = window.localStorage.getItem("sfm_sort_by_folder_first");
          return val === null ? true : val === "true";
        } catch (e) {
          return true;
        }
      });

      const handleToggleSortByFolderFirst = useCallback((val) => {
        setSortByFolderFirst(val);
        try {
          window.localStorage.setItem("sfm_sort_by_folder_first", String(val));
        } catch (e) {}
      }, []);

      const handleToggleSubfoldersCollapsed = useCallback(() => {
        setIsSubfoldersCollapsed((prev) => {
          const next = !prev;
          try {
            window.localStorage.setItem("sfm_subfolders_collapsed", String(next));
          } catch (e) {}
          return next;
        });
      }, []);

      const handleToggleFilesCollapsed = useCallback(() => {
        setIsFilesCollapsed((prev) => {
          const next = !prev;
          try {
            window.localStorage.setItem("sfm_files_collapsed", String(next));
          } catch (e) {}
          return next;
        });
      }, []);

      // Scene View Mode: Card vs List Views
      const [viewMode, setViewMode] = useState(() => {
        try {
          return window.localStorage.getItem("sfm_view_mode") || "grid";
        } catch (e) {
          return "grid";
        }
      });

      // Thumbnail Card Size States (Persisted in localStorage)
      const [folderCardSize, setFolderCardSize] = useState(() => {
        try {
          return Number(window.localStorage.getItem("sfm_folder_card_size")) || 160;
        } catch (e) {
          return 160;
        }
      });
      const handleSetFolderCardSize = (size) => {
        setFolderCardSize(size);
        try {
          window.localStorage.setItem("sfm_folder_card_size", String(size));
        } catch (e) {}
      };

      const [folderListWidth, setFolderListWidth] = useState(() => {
        try {
          return Number(window.localStorage.getItem("sfm_folder_list_width")) || 220;
        } catch (e) {
          return 220;
        }
      });
      const handleSetFolderListWidth = (width) => {
        setFolderListWidth(width);
        try {
          window.localStorage.setItem("sfm_folder_list_width", String(width));
        } catch (e) {}
      };

      const [sceneCardSize, setSceneCardSize] = useState(() => {
        try {
          return Number(window.localStorage.getItem("sfm_scene_card_size")) || 240;
        } catch (e) {
          return 240;
        }
      });
      const handleSetSceneCardSize = (size) => {
        setSceneCardSize(size);
        try {
          window.localStorage.setItem("sfm_scene_card_size", String(size));
        } catch (e) {}
      };

      // Folder View Mode: Compact Cards vs List vs Detail Table
      const [folderViewMode, setFolderViewMode] = useState(() => {
        try {
          return window.localStorage.getItem("sfm_folder_view_mode") || "cards";
        } catch (e) {
          return "cards";
        }
      });
      const handleSetFolderViewMode = (mode) => {
        setFolderViewMode(mode);
        try {
          window.localStorage.setItem("sfm_folder_view_mode", mode);
        } catch (e) {}
      };

      // Milestone 1: Scene Multi-Selection
      const [selectedSceneIds, setSelectedSceneIds] = useState(new Set());

      // Modals
      const [showBatchModal, setShowBatchModal] = useState(false);
      const [showParserModal, setShowParserModal] = useState(false);
      const [showSettingsModal, setShowSettingsModal] = useState(false);
      const initialHashState = parseHashState();
      const [playingScene, setPlayingScene] = useState(() => {
        if (initialHashState?.sceneId) {
          return { id: initialHashState.sceneId };
        }
        return null;
      });

      // Progressive Feed Windowing State (Social Media Infinite Chunking Optimization)
      const SCENE_CHUNK_SIZE = 48;
      const [visibleSceneCount, setVisibleSceneCount] = useState(SCENE_CHUNK_SIZE);
      const sceneSentinelRef = useRef(null);
      const isSceneLoadingRef = useRef(false);

      // Folder Profile & Discover State (Sub-Route Hash Synchronization)
      const [showFolderProfile, setShowFolderProfile] = useState(() => {
        return initialHashState?.view === "profile" || initialHashState?.view === "discover";
      });
      const [currentProfilePage, setCurrentProfilePage] = useState(() => {
        return initialHashState?.view === "discover" ? 1 : 0;
      });

      const handleOpenFolderProfile = useCallback((page = 0) => {
        setShowFolderProfile(true);
        setCurrentProfilePage(page);
        const viewName = page === 1 ? "discover" : "profile";
        // Profile view hash must NOT have sceneId so that hitting back returns to folder view, never replaying video
        const targetHash = buildHashForPath(currentPath, viewName, null);
        if (window.location.hash !== targetHash) {
          const nextDepth = getNextSfmDepth();
          window.history.pushState({ sfmPath: currentPath, sfmView: viewName, sfmDepth: nextDepth }, "", targetHash);
        }
      }, [currentPath]);

      const handleCloseFolderProfile = useCallback(() => {
        setShowFolderProfile(false);
        const curDepth = (window.history.state && typeof window.history.state.sfmDepth === "number") ? window.history.state.sfmDepth : 0;
        if (curDepth > 1 && window.location.hash.includes("view=")) {
          window.history.back();
        } else {
          const targetHash = buildHashForPath(currentPath, null, null);
          if (window.location.hash !== targetHash) {
            window.history.replaceState({ sfmPath: currentPath, sfmDepth: Math.max(1, curDepth) }, "", targetHash);
          }
        }
      }, [currentPath, playingScene]);

      const [customPlayerScenes, setCustomPlayerScenes] = useState(null);
      const isClosingPlayerRef = useRef(false);

      const handleOpenProfileFromPlayer = useCallback((targetPath) => {
        if (typeof document !== "undefined" && document.fullscreenElement) {
          document.exitFullscreen().catch(() => {});
        }
        setPlayingScene(null);
        setCustomPlayerScenes(null);
        const p = normalizePath(targetPath);
        setCurrentPath(p);
        setShowFolderProfile(true);
        setCurrentProfilePage(0);
        // Replace active video playback with profile view in history so old video doesn't linger underneath
        const curDepth = (window.history.state && typeof window.history.state.sfmDepth === "number") ? window.history.state.sfmDepth : 1;
        const targetHash = buildHashForPath(p, "profile", null);
        window.history.replaceState({ sfmPath: p, sfmView: "profile", inPlayerProfile: false, sfmDepth: curDepth }, "", targetHash);
      }, []);

      const handlePlayScene = useCallback((s, queue = null) => {
        if (!s) return;
        const sFolder = resolveSceneFolder(s, trie);
        if (sFolder && !s._folderPath) {
          s._folderPath = sFolder;
        }

        // Resolve companion scenes for this scene's actual directory so total video count and next sequence never break
        let effectiveQueue = null;
        if (trie && sFolder) {
          const node = trie.getNode(sFolder);
          if (node && Array.isArray(node.directScenes) && node.directScenes.length > 0) {
            effectiveQueue = node.directScenes;
          }
        }
        if (!effectiveQueue && Array.isArray(queue) && queue.length > 0) {
          effectiveQueue = queue;
        }

        // True only if currently actively watching a video in player (not on profile/explore view)
        const isCurrentlyViewingVideo = Boolean(
          window.location.hash.includes("scene=") &&
          !window.location.hash.includes("view=")
        );

        setPlayingScene(s);
        setCustomPlayerScenes(effectiveQueue);
        setShowFolderProfile(false); // Dismiss standalone profile overlay so video player immediately displays!

        // When playing a video, hash is #file-manager?path=...&scene=... (without view=profile)
        // This ensures the previous history entry (#file-manager?path=...&view=profile) is preserved as the immediate back destination!
        const targetHash = buildHashForPath(sFolder || currentPath, null, s.id);
        if (window.location.hash !== targetHash) {
          if (!isCurrentlyViewingVideo) {
            // Initial transition into the player from folder or profile view: push history entry
            const nextDepth = getNextSfmDepth();
            window.history.pushState({ sfmPath: sFolder || currentPath, sfmView: null, sfmScene: s.id, sfmDepth: nextDepth }, "", targetHash);
          } else {
            // Already inside active video playback: replaceState so swiping or queue advance doesn't create duplicate history entries
            const curDepth = (window.history.state && typeof window.history.state.sfmDepth === "number") ? window.history.state.sfmDepth : 1;
            window.history.replaceState({ sfmPath: sFolder || currentPath, sfmView: null, sfmScene: s.id, sfmDepth: curDepth }, "", targetHash);
          }
        }
      }, [currentPath, trie]);

      const handleClosePlayer = useCallback(() => {
        if (typeof document !== "undefined" && document.fullscreenElement) {
          document.exitFullscreen().catch(() => {});
        }
        isClosingPlayerRef.current = true;
        setPlayingScene(null);
        setCustomPlayerScenes(null);
        const curDepth = (window.history.state && typeof window.history.state.sfmDepth === "number") ? window.history.state.sfmDepth : 0;
        if (curDepth > 1 && window.location.hash.includes("scene=")) {
          window.history.back();
        } else {
          const currentView = showFolderProfile ? (currentProfilePage === 1 ? "discover" : "profile") : null;
          const targetHash = buildHashForPath(currentPath, currentView, null);
          if (window.location.hash !== targetHash) {
            window.history.replaceState({ sfmPath: currentPath, sfmView: currentView, sfmDepth: Math.max(1, curDepth) }, "", targetHash);
          }
          isClosingPlayerRef.current = false;
        }
      }, [currentPath, showFolderProfile, currentProfilePage]);
      const [pluginSettings, setPluginSettings] = useState(null);

      // Load native Stash plugin configuration on mount
      useEffect(() => {
        let isMounted = true;
        fetchStashPluginSettings().then((cfg) => {
          if (!isMounted || !cfg) return;
          setPluginSettings(cfg);
          if (cfg.default_transcode_method) {
            window.__SFM_DEFAULT_TRANSCODE_METHOD__ = cfg.default_transcode_method;
            if (!window.localStorage.getItem("sfm_stream_mode")) {
              try { window.localStorage.setItem("sfm_stream_mode", cfg.default_transcode_method); } catch(e) {}
            }
          }
          if (cfg.fallback_transcode_method) {
            window.__SFM_FALLBACK_TRANSCODE_METHOD__ = cfg.fallback_transcode_method;
          }
          if (cfg.root_library_path && !currentPath) {
            if (cfg.remember_last_path === false || !window.localStorage.getItem("sfm_last_folder_path")) {
              setCurrentPath(normalizePath(cfg.root_library_path));
            }
          }
          if (cfg.folder_view_mode && !window.localStorage.getItem("sfm_folder_view_mode")) {
            setFolderViewMode(cfg.folder_view_mode);
          }
          if (cfg.scene_view_mode && !window.localStorage.getItem("sfm_view_mode")) {
            if (cfg.scene_view_mode === "cards") setViewMode("grid");
            else if (cfg.scene_view_mode === "names") setViewMode("names");
            else setViewMode("list");
          }
          if (cfg.folder_card_size && !window.localStorage.getItem("sfm_folder_card_size")) {
            setFolderCardSize(Number(cfg.folder_card_size));
          }
          if (cfg.scene_card_size && !window.localStorage.getItem("sfm_scene_card_size")) {
            setSceneCardSize(Number(cfg.scene_card_size));
          }
          if (cfg.auto_rebuild_tree_on_start) {
            fetchCatalog(true);
          }
        });
        return () => { isMounted = false; };
      }, []);

      const handleToggleViewMode = (mode) => {
        setViewMode(mode);
        try {
          window.localStorage.setItem("sfm_view_mode", mode);
        } catch (e) {}
      };

      const handleToggleSelect = (id) => {
        setSelectedSceneIds((prev) => {
          const next = new Set(prev);
          if (next.has(id)) next.delete(id);
          else next.add(id);
          return next;
        });
      };

      const handleClearSelection = () => {
        setSelectedSceneIds(new Set());
      };

      // Save hide empty preference
      const handleToggleHideEmpty = (val) => {
        setHideEmpty(val);
        try {
          window.localStorage.setItem("sfm_hide_empty", val ? "true" : "false");
        } catch (e) {}
      };

      // Feature 5: High-Performance Progressive Indexing & Multi-Tier Caching
      const fetchCatalog = useCallback(async (forceBypassCache = false) => {
        setLoading(true);
        try {
          const loadedTrie = await ensureCatalog(forceBypassCache, (status) => setStatusText(status));
          if (loadedTrie) {
            setTrie(loadedTrie);
          }
        } catch (err) {
          console.error(err);
          setNotification("Failed to load library: " + (err && err.message ? err.message : String(err)));
        } finally {
          setLoading(false);
        }
      }, []);

      useEffect(() => {
        fetchCatalog(refreshKey > 0);
      }, [fetchCatalog, refreshKey]);

      const handleRescan = async () => {
        window.__SFM_GLOBAL_CACHE__.trie = null;
        window.__SFM_GLOBAL_CACHE__.scenes = null;
        await idbClear();
        setRefreshKey((k) => k + 1);
      };

      const currentNode = useMemo(() => {
        if (!trie) return null;
        let node = trie.getNode(currentPath);
        if (!node && currentPath) {
          // If currentPath had an old un-rebased prefix (e.g. "data/folder"), strip first segment and try
          const sub = currentPath.split("/").slice(1).join("/");
          if (sub && trie.getNode(sub)) {
            setCurrentPath(sub);
            return trie.getNode(sub);
          }
          setCurrentPath("");
          return trie.root;
        }
        return node || trie.root;
      }, [trie, currentPath]);

      // Feature 2 & 4: Subfolders filtering and sorting
      const filteredAndSortedSubfolders = useMemo(() => {
        if (!currentNode) return [];
        let list = Object.keys(currentNode.folders);

        if (hideEmpty) {
          list = list.filter((f) => currentNode.folders[f].allSceneIds.size > 0);
        }

        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          list = list.filter((f) => f.toLowerCase().includes(q));
        }

        list.sort((a, b) => {
          if (folderSort === "name_desc") return b.localeCompare(a);
          if (folderSort === "count_desc") {
            return currentNode.folders[b].allSceneIds.size - currentNode.folders[a].allSceneIds.size;
          }
          if (folderSort === "count_asc") {
            return currentNode.folders[a].allSceneIds.size - currentNode.folders[b].allSceneIds.size;
          }
          return a.localeCompare(b);
        });

        return list;
      }, [currentNode, hideEmpty, searchQuery, folderSort]);

      // Feature 2: Scenes filtering and sorting (with recursive subfolders support & folder-first sorting)
      const filteredAndSortedScenes = useMemo(() => {
        if (!currentNode) return [];

        const sceneComparator = (a, b) => {
          if (sceneSort === "title_desc") {
            return (b.title || b.files?.[0]?.basename || "").localeCompare(a.title || a.files?.[0]?.basename || "");
          }
          if (sceneSort === "date_desc") {
            return (b.date || "").localeCompare(a.date || "");
          }
          if (sceneSort === "date_asc") {
            return (a.date || "").localeCompare(b.date || "");
          }
          if (sceneSort === "rating_desc") {
            return (b.rating100 || 0) - (a.rating100 || 0);
          }
          if (sceneSort === "duration_desc") {
            return (b.files?.[0]?.duration || 0) - (a.files?.[0]?.duration || 0);
          }
          if (sceneSort === "size_desc") {
            return (b.files?.[0]?.size || 0) - (a.files?.[0]?.size || 0);
          }
          return (a.title || a.files?.[0]?.basename || "").localeCompare(b.title || b.files?.[0]?.basename || "");
        };

        const sortFolderKeys = (keys, parentNode) => {
          return [...keys].sort((a, b) => {
            if (folderSort === "name_desc") return b.localeCompare(a);
            if (folderSort === "count_desc") {
              return (parentNode.folders[b]?.allSceneIds?.size || 0) - (parentNode.folders[a]?.allSceneIds?.size || 0);
            }
            if (folderSort === "count_asc") {
              return (parentNode.folders[a]?.allSceneIds?.size || 0) - (parentNode.folders[b]?.allSceneIds?.size || 0);
            }
            return a.localeCompare(b);
          });
        };

        let list = [];
        if (includeSubfolders) {
          if (sortByFolderFirst) {
            // Hierarchical folder sort: traverse subfolders in folderSort order, then direct scenes of this node
            const seenIds = new Set();
            const collectHierarchy = (node) => {
              const collected = [];
              if (!node) return collected;

              // 1. Visit subfolders in folderSort order
              if (node.folders) {
                const sortedKeys = sortFolderKeys(Object.keys(node.folders), node);
                for (const k of sortedKeys) {
                  const child = node.folders[k];
                  collected.push(...collectHierarchy(child));
                }
              }

              // 2. Direct scenes in this node, sorted by sceneSort
              if (node.directScenes && node.directScenes.length > 0) {
                const directCopy = [...node.directScenes];
                directCopy.sort(sceneComparator);
                for (const s of directCopy) {
                  if (s && s.id && !seenIds.has(s.id)) {
                    seenIds.add(s.id);
                    collected.push(s);
                  }
                }
              }

              return collected;
            };

            list = collectHierarchy(currentNode);
          } else {
            list = getAllDescendantScenes(currentNode);
            list.sort(sceneComparator);
          }
        } else {
          list = [...currentNode.directScenes];
          list.sort(sceneComparator);
        }

        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          list = list.filter((s) => {
            const title = (s.title || "").toLowerCase();
            const file = (s.files?.[0]?.basename || "").toLowerCase();
            const studio = (s.studio?.name || "").toLowerCase();
            const performers = (s.performers || []).map((p) => p.name.toLowerCase()).join(" ");
            return title.includes(q) || file.includes(q) || studio.includes(q) || performers.includes(q);
          });
        }

        return list;
      }, [currentNode, includeSubfolders, searchQuery, sceneSort, folderSort, sortByFolderFirst]);

      // Reset visible window to 48 scenes whenever path, search query, sorting, or recursive subfolder toggles change
      useEffect(() => {
        setVisibleSceneCount(SCENE_CHUNK_SIZE);
      }, [currentPath, searchQuery, sceneSort, folderSort, includeSubfolders, sortByFolderFirst]);

      // Infinite scroll sentinel: automatically appends next 48 scenes as user scrolls down
      useEffect(() => {
        if (typeof IntersectionObserver === "undefined") return;
        const sentinel = sceneSentinelRef.current;
        if (!sentinel) return;

        const observer = new IntersectionObserver(
          (entries) => {
            const first = entries[0];
            if (first.isIntersecting && !isSceneLoadingRef.current) {
              if (visibleSceneCount < filteredAndSortedScenes.length) {
                isSceneLoadingRef.current = true;
                setVisibleSceneCount((prev) => Math.min(prev + SCENE_CHUNK_SIZE, filteredAndSortedScenes.length));
                setTimeout(() => {
                  isSceneLoadingRef.current = false;
                }, 100);
              }
            }
          },
          { root: null, rootMargin: "350px 0px", threshold: 0.05 }
        );

        observer.observe(sentinel);
        return () => observer.disconnect();
      }, [visibleSceneCount, filteredAndSortedScenes.length]);

      // Sliced visible scenes: renders only visible chunk to guarantee zero lag, zero hanging, and 95% less RAM usage!
      const visibleScenes = useMemo(() => {
        return filteredAndSortedScenes.slice(0, visibleSceneCount);
      }, [filteredAndSortedScenes, visibleSceneCount]);

      const allDescendantIds = currentNode ? Array.from(currentNode.allSceneIds) : [];
      const currentFolderName = currentPath.split("/").filter(Boolean).pop() || "Stash";

      const handleAutoDetect = async () => {
        if (!currentPath) return;
        setNotification(`Checking for matching Studio or Performer for "${currentFolderName}"...`);

        try {
          const [sRes, pRes] = await Promise.all([
            gqlFetch(
              `query FindStudio($name: String!) {
                findStudios(studio_filter: { name: { value: $name, modifier: EQUALS } }) {
                  studios { id name }
                }
              }`,
              { name: currentFolderName }
            ),
            gqlFetch(
              `query FindPerformer($name: String!) {
                findPerformers(performer_filter: { name: { value: $name, modifier: EQUALS } }) {
                  performers { id name }
                }
              }`,
              { name: currentFolderName }
            ),
          ]);

          const studio = sRes?.findStudios?.studios?.[0];
          const performer = pRes?.findPerformers?.performers?.[0];

          if (!studio && !performer) {
            setNotification(`No exact database match found for "${currentFolderName}". Use 'Batch Edit' to specify manually.`);
            return;
          }

          const matches = [];
          const input = { ids: allDescendantIds };
          if (studio) {
            input.studio_id = studio.id;
            matches.push(`Studio: ${studio.name}`);
          }
          if (performer) {
            input.performer_ids = { ids: [performer.id], mode: "ADD" };
            matches.push(`Performer: ${performer.name}`);
          }

          if (window.confirm(`Auto-detected ${matches.join(" and ")}. Apply to all ${allDescendantIds.length} scenes in this folder?`)) {
            await gqlFetch(
              `mutation ApplyAutoMatch($input: BulkSceneUpdateInput!) {
                bulkSceneUpdate(input: $input) { id }
              }`,
              { input }
            );
            setNotification(`Successfully assigned ${matches.join(" & ")} to ${allDescendantIds.length} scenes.`);
            handleRescan();
          }
        } catch (err) {
          setNotification(`Error: ${err.message}`);
        }
      };

      const openInNativeGrid = () => {
        if (!currentPath) {
          window.open("/scenes", "_blank");
          return;
        }
        const node = trie?.getNode(currentPath);
        const targetPath = node?.diskPath || currentPath;
        const filterCriterion = {
          type: "path",
          value: targetPath,
          modifier: "MATCHES_REGEX",
        };
        localStorage.setItem("sfm_last_folder_path", currentPath);
        const currentHash = buildHashForPath(currentPath);
        if (window.location.hash !== currentHash) {
          window.history.replaceState({ sfmPath: currentPath }, "", currentHash);
        }
        // Open native scene card grid in a new tab so the current folder location remains open and intact!
        window.open(`/scenes?c=${encodeURIComponent(JSON.stringify(filterCriterion))}`, "_blank");
      };

      // Milestone 3: Folder-Scoped Metadata Scan
      const handleScanFolder = async () => {
        const node = trie?.getNode(currentPath);
        const targetPath = node?.diskPath || currentPath || trie?.root?.diskPath || "";
        const label = targetPath ? `"${targetPath}"` : "all Stash libraries";
        setNotification(`Starting Stash filesystem scan for: ${label}...`);
        try {
          const mutation = `
            mutation ScanPath($paths: [String!]) {
              metadataScan(input: { paths: $paths })
            }
          `;
          await gqlFetch(mutation, { paths: targetPath ? [targetPath] : [] });
          setNotification(`Stash scan task triggered for ${label}. Check Settings -> Tasks.`);
        } catch (e) {
          setNotification(`Scan failed: ${e.message}`);
        }
      };

      const handleSelectAllFolderScenes = useCallback(() => {
        if (selectedSceneIds.size > 0) {
          setSelectedSceneIds(new Set());
        } else {
          const visibleIds = filteredAndSortedScenes.map((s) => s.id);
          setSelectedSceneIds(new Set(visibleIds));
        }
      }, [selectedSceneIds, filteredAndSortedScenes]);

      // Listen to popstate (browser back/forward) and hash changes to navigate folders, profiles, and players without closing
      useEffect(() => {
        const handleLocationChange = () => {
          const state = parseHashState();
          if (state === null) {
            return;
          }

          // 1. Path synchronization
          if (state.path !== currentPath) {
            setCurrentPath(state.path);
            localStorage.setItem("sfm_last_folder_path", state.path);
          }

          // 2. View synchronization (profile vs discover vs folder)
          if (state.view === "profile" || state.view === "discover") {
            setShowFolderProfile(true);
            setCurrentProfilePage(state.view === "discover" ? 1 : 0);
            if (playingScene) {
              setPlayingScene(null);
              setCustomPlayerScenes(null);
            }
            isClosingPlayerRef.current = false;
            return;
          } else {
            setShowFolderProfile(false);
          }

          // 3. Scene player synchronization
          if (isClosingPlayerRef.current) {
            if (state.sceneId) {
              // The browser popped into a previous scene entry from an old navigation chain.
              // Strip sceneId so it NEVER reopens an unwanted previous video!
              const targetHash = buildHashForPath(state.path || currentPath, null, null);
              window.history.replaceState({ ...window.history.state, sfmScene: null }, "", targetHash);
            }
            isClosingPlayerRef.current = false;
            setPlayingScene(null);
            setCustomPlayerScenes(null);
            return;
          }

          if (state.sceneId) {
            if (!playingScene || String(playingScene.id) !== String(state.sceneId)) {
              const allAvailable = window.__SFM_GLOBAL_CACHE__?.scenes || (currentNode ? currentNode.directScenes : []);
              const found = allAvailable.find((s) => String(s.id) === String(state.sceneId)) || { id: state.sceneId };
              setPlayingScene(found);
            }
          } else {
            if (playingScene) {
              setPlayingScene(null);
              setCustomPlayerScenes(null);
            }
          }
        };
        window.addEventListener("popstate", handleLocationChange);
        window.addEventListener("hashchange", handleLocationChange);
        return () => {
          window.removeEventListener("popstate", handleLocationChange);
          window.removeEventListener("hashchange", handleLocationChange);
        };
      }, [currentPath, playingScene, showFolderProfile, currentNode]);

      // Directory Keyboard Shortcuts (Milestone 1)
      useEffect(() => {
        const handleDirectoryKeyDown = (e) => {
          if (loading || playingScene || showSettingsModal || showBatchModal || showParserModal) {
            return;
          }

          const activeEl = document.activeElement;
          const isInputActive = activeEl && (["INPUT", "TEXTAREA", "SELECT"].includes(activeEl.tagName) || activeEl.isContentEditable);

          if (e.key === "Escape") {
            if (isInputActive) {
              if (searchQuery) {
                setSearchQuery("");
              }
              activeEl.blur();
              return;
            }
            if (selectedSceneIds.size > 0) {
              e.preventDefault();
              setSelectedSceneIds(new Set());
              return;
            }
            if (onClose) {
              e.preventDefault();
              onClose();
              return;
            }
          }

          if (isInputActive) return;

          if (e.key === "/" && !e.ctrlKey && !e.metaKey && !e.altKey) {
            e.preventDefault();
            searchInputRef.current?.focus();
            return;
          }

          if (e.key === "Backspace" || (e.altKey && e.key === "ArrowLeft")) {
            if (currentPath) {
              e.preventDefault();
              handleGoUpOneLevel();
              return;
            }
          }

          if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "a") {
            e.preventDefault();
            handleSelectAllFolderScenes();
            return;
          }
        };

        window.addEventListener("keydown", handleDirectoryKeyDown);
        return () => window.removeEventListener("keydown", handleDirectoryKeyDown);
      }, [
        loading,
        playingScene,
        showSettingsModal,
        showBatchModal,
        showParserModal,
        currentPath,
        searchQuery,
        selectedSceneIds,
        handleGoUpOneLevel,
        handleSelectAllFolderScenes,
        onClose,
      ]);

      if (loading) {
        return React.createElement(
          "div",
          { className: "sfm-workspace-overlay" },
          React.createElement(
            "div",
            { className: "sfm-workspace-header" },
            React.createElement("div", { className: "sfm-workspace-title" }, React.createElement(IconFolder, { size: 20, color: "#88c0d0" }), React.createElement("span", { className: "ml-2" }, "Stash File Manager")),
            onClose && React.createElement("button", { className: "sfm-workspace-close", onClick: onClose }, "✕ Close")
          ),
          React.createElement(
            "div",
            { className: "sfm-workspace-content text-center py-5" },
            React.createElement("div", { className: "spinner-border text-info mb-3", style: { width: "3rem", height: "3rem" } }),
            React.createElement("h4", null, "Indexing File System Hierarchy..."),
            React.createElement("p", { className: "text-muted" }, statusText)
          )
        );
      }





      const segments = currentPath ? currentPath.split("/").filter(Boolean) : [];

      const isOverlayActive = Boolean(showFolderProfile || playingScene);

      return React.createElement(
        "div",
        { className: `sfm-workspace-overlay ${isOverlayActive ? "sfm-overlay-open" : ""}` },
        // Header (Clean branding & window control - hidden when overlay is active)
        React.createElement(
          "div",
          {
            className: "sfm-workspace-header",
            style: isOverlayActive ? { display: "none" } : undefined,
          },
          // Left: Workspace Branding
          React.createElement(
            "div",
            { className: "sfm-workspace-title" },
            React.createElement(IconFolder, { size: 22, color: "#88c0d0" }),
            React.createElement("span", { className: "ml-2" }, "Stash File Manager"),
            trie && React.createElement(
              "span",
              { className: "sfm-stat-pill badge badge-dark ml-2 font-weight-normal" },
              React.createElement("strong", { style: { color: "#88c0d0" } }, trie.root.allSceneIds.size),
              React.createElement("span", { className: "ml-1 text-muted" }, "total scenes")
            )
          ),
          // Right: Close Button
          onClose && React.createElement("button", { className: "sfm-workspace-close", onClick: onClose }, "✕ Close")
        ),
        // Scrollable Body
        React.createElement(
          "div",
          {
            className: "sfm-workspace-content",
            style: isOverlayActive ? { display: "none" } : undefined,
          },
          // Folder Navigation Control Line (Multi-Line: Path Navigation & Quick Controls)
          React.createElement(
            "div",
            { className: "sfm-nav-control-line mb-3" },
            // Line 1: [◀] [▲] | 🏠 Stash › ... › Folder | [counts and size with colored digits] | [Scan] [Grid] | ... [Settings]
            React.createElement(
              "div",
              { className: "sfm-nav-line sfm-nav-line-path d-flex align-items-center justify-content-between flex-wrap gap-2" },
              React.createElement(
                "div",
                { className: "sfm-breadcrumbs-wrap d-flex align-items-center flex-wrap" },
                // Back & Up (Icons only, hover tooltip, grouped 2 as 1)
                React.createElement(
                  "div",
                  { className: "btn-group btn-group-sm mr-2 sfm-nav-history-group" },
                  React.createElement(
                    "button",
                    {
                      type: "button",
                      className: "btn btn-sm btn-outline-secondary py-0 px-2",
                      onClick: handleGoBackInHistory,
                      disabled: historyStack.current.length === 0 && !currentPath,
                      title: "Go back to previous folder (Alt+Left)",
                    },
                    React.createElement(IconArrowLeft, { size: 14 })
                  ),
                  React.createElement(
                    "button",
                    {
                      type: "button",
                      className: "btn btn-sm btn-outline-secondary py-0 px-2",
                      onClick: handleGoUpOneLevel,
                      disabled: !currentPath,
                      title: "Go up to parent directory (Backspace)",
                    },
                    React.createElement(IconArrowUp, { size: 14 })
                  )
                ),
                // Path Root: Stash (with Home Icon)
                React.createElement(
                  "button",
                  {
                    type: "button",
                    className: `sfm-crumb-btn ${!currentPath ? "sfm-crumb-active" : ""}`,
                    onClick: () => navigateToFolder(""),
                    title: "Return to Stash Root",
                  },
                  React.createElement(IconHome, { size: 14, color: "#88c0d0" }),
                  React.createElement("span", { className: "ml-1 font-weight-bold" }, "Stash")
                ),
                // Segments
                segments.map((seg, idx) => {
                  const p = segments.slice(0, idx + 1).join("/");
                  const isLast = idx === segments.length - 1;
                  return React.createElement(
                    React.Fragment,
                    { key: p },
                    React.createElement("span", { className: "sfm-crumb-separator" }, "›"),
                    React.createElement(
                      "button",
                      {
                        type: "button",
                        className: `sfm-crumb-btn ${isLast ? "sfm-crumb-active" : ""}`,
                        onClick: () => navigateToFolder(p),
                        title: seg,
                      },
                      seg
                    )
                  );
                }),
                // Counts and size with colored digits
                React.createElement(
                  "span",
                  { className: "sfm-stat-pill ml-2 badge badge-dark font-weight-normal" },
                  React.createElement("strong", { style: { color: "#88c0d0" } }, currentNode ? currentNode.directScenes.length : 0),
                  React.createElement("span", { className: "sfm-stat-label" }, "direct"),
                  React.createElement("span", { className: "sfm-stat-dot" }, "·"),
                  React.createElement("strong", { style: { color: "#81a1c1" } }, allDescendantIds.length),
                  React.createElement("span", { className: "sfm-stat-label" }, "in tree"),
                  React.createElement("span", { className: "sfm-stat-paren" }, "("),
                  React.createElement("strong", { style: { color: "#a3be8c" } }, formatBytes(currentNode?.totalSize)),
                  React.createElement("span", { className: "sfm-stat-paren" }, ")")
                ),
                // Scan and Grid (Icons only, hover tooltip, grouped 2 as 1)
                React.createElement(
                  "div",
                  { className: "btn-group btn-group-sm ml-2 sfm-nav-actions-group" },
                  React.createElement(
                    "button",
                    {
                      type: "button",
                      className: "btn btn-sm btn-outline-secondary py-0 px-2",
                      onClick: handleScanFolder,
                      title: currentPath ? `Trigger Stash filesystem scan on "${currentPath}"` : "Trigger Stash filesystem scan on all libraries",
                    },
                    React.createElement(IconScan, { size: 14 })
                  ),
                  React.createElement(
                    "button",
                    {
                      type: "button",
                      className: "btn btn-sm btn-outline-secondary py-0 px-2",
                      onClick: () => handleOpenFolderProfile(0),
                      title: "Open Folder Profile & Video Wall (Explore Mode)",
                    },
                    React.createElement(IconGrid, { size: 14 })
                  )
                )
              ),
              // Settings (aligned and anchored to the right of Line 1)
              React.createElement(
                "button",
                {
                  type: "button",
                  className: "sfm-workspace-settings-btn ml-auto",
                  onClick: () => setShowSettingsModal(true),
                  title: "Stash Settings & Plugin Tasks",
                },
                React.createElement(IconGear, { size: 14, color: "currentColor" }),
                "Settings"
              )
            ),
            // Line 2: [folder sort / scene sort] [the search box (stretch till fit)] [batch edit / parse (anchor right)]
            React.createElement(
              "div",
              { className: "sfm-nav-line sfm-nav-line-controls d-flex align-items-center gap-2 mt-2" },
              // Left: [folder sort / scene sort]
              React.createElement(
                "div",
                { className: "sfm-sort-group d-flex align-items-center gap-2 flex-shrink-0" },
                React.createElement(
                  "div",
                  { className: "d-flex align-items-center sfm-sort-item" },
                  React.createElement("span", { className: "sfm-sort-label mr-1 text-muted small" }, "Folders:"),
                  React.createElement(
                    "select",
                    {
                      className: "sfm-sort-select",
                      value: folderSort,
                      onChange: (e) => setFolderSort(e.target.value),
                      title: "Sort Subfolders",
                    },
                    React.createElement("option", { value: "name_asc" }, "Name (A-Z)"),
                    React.createElement("option", { value: "name_desc" }, "Name (Z-A)"),
                    React.createElement("option", { value: "count_desc" }, "Count (High-Low)"),
                    React.createElement("option", { value: "count_asc" }, "Count (Low-High)")
                  )
                ),
                React.createElement(
                  "div",
                  { className: "d-flex align-items-center sfm-sort-item" },
                  React.createElement("span", { className: "sfm-sort-label mr-1 text-muted small" }, "Scenes:"),
                  React.createElement(
                    "select",
                    {
                      className: "sfm-sort-select",
                      value: sceneSort,
                      onChange: (e) => setSceneSort(e.target.value),
                      title: "Sort Scenes",
                    },
                    React.createElement("option", { value: "title_asc" }, "Title (A-Z)"),
                    React.createElement("option", { value: "title_desc" }, "Title (Z-A)"),
                    React.createElement("option", { value: "date_desc" }, "Date (Newest)"),
                    React.createElement("option", { value: "date_asc" }, "Date (Oldest)"),
                    React.createElement("option", { value: "rating_desc" }, "Rating (Highest)"),
                    React.createElement("option", { value: "duration_desc" }, "Duration (Longest)"),
                    React.createElement("option", { value: "size_desc" }, "Size (Largest)")
                  )
                )
              ),
              // Center: [the search box (stretch till fit)]
              React.createElement(
                "div",
                { className: "sfm-search-wrap sfm-search-stretch flex-grow-1 mx-3" },
                React.createElement(
                  "span",
                  { className: "sfm-search-icon" },
                  React.createElement(IconSearch, { size: 14, color: "#81a1c1" })
                ),
                React.createElement("input", {
                  ref: searchInputRef,
                  type: "text",
                  className: "sfm-search-input w-100",
                  placeholder: "Search folder or scenes by title, studio, performer... (Press / to focus)",
                  value: searchQuery,
                  onChange: (e) => setSearchQuery(e.target.value),
                }),
                searchQuery &&
                  React.createElement(
                    "button",
                    {
                      type: "button",
                      className: "sfm-search-clear",
                      onClick: () => {
                        setSearchQuery("");
                        searchInputRef.current?.focus();
                      },
                      title: "Clear search (Esc)",
                    },
                    React.createElement(IconX, { size: 10, color: "currentColor" })
                  )
              ),
              // Right: [batch edit / parse (align and anchor to right)]
              React.createElement(
                "div",
                { className: "btn-group btn-group-sm sfm-tools-group flex-shrink-0 ml-auto" },
                React.createElement(
                  "button",
                  {
                    type: "button",
                    className: "btn btn-sm btn-outline-secondary py-1 px-2",
                    onClick: () => setShowBatchModal(true),
                    title: "Batch Edit Scenes",
                  },
                  React.createElement(IconEdit, { size: 13, className: "mr-1" }),
                  "Batch Edit"
                ),
                React.createElement(
                  "button",
                  {
                    type: "button",
                    className: "btn btn-sm btn-outline-secondary py-1 px-2",
                    onClick: () => setShowParserModal(true),
                    title: "Parse Filenames with Regex",
                  },
                  React.createElement(IconSearch, { size: 13, className: "mr-1" }),
                  "Parse"
                )
              )
            )
          ),
          // Subfolders Section (Customizable Views: Cards, List, Detail Table)
          (filteredAndSortedSubfolders.length > 0 || (includeSubfolders && Object.keys(currentNode?.folders || {}).length > 0)) &&
            React.createElement(
              "div",
              { className: "mb-4" },
              React.createElement(
                "div",
                { className: "d-flex justify-content-between align-items-center mb-2 flex-wrap gap-2" },
                React.createElement(
                  "div",
                  { className: "d-flex align-items-center flex-wrap" },
                  React.createElement(
                    "div",
                    {
                      className: "sfm-section-title-box sfm-section-header mb-0 sfm-collapsible-title",
                      onClick: handleToggleSubfoldersCollapsed,
                      title: isSubfoldersCollapsed ? "Click to expand Subfolders" : "Click to collapse Subfolders",
                      style: { cursor: "pointer", userSelect: "none" },
                    },
                    React.createElement(
                      "span",
                      { className: "sfm-collapse-chevron mr-2 text-info font-weight-bold" },
                      isSubfoldersCollapsed ? "▶" : "▼"
                    ),
                    React.createElement("span", { className: "sfm-section-title-label" }, "Sub-folders"),
                    React.createElement(
                      "span",
                      { className: "badge badge-dark sfm-section-count-badge font-weight-normal" },
                      React.createElement("strong", { style: { color: "#88c0d0" } }, filteredAndSortedSubfolders.length)
                    ),
                    isSubfoldersCollapsed &&
                      React.createElement("span", { className: "text-muted small ml-2 font-italic sfm-collapsed-indicator", style: { display: "none" } }, "(collapsed)")
                  ),
                  // Toggle 1: Include Sub-Folders (Bold, 2 color states matching status indicators)
                  React.createElement(
                    "button",
                    {
                      type: "button",
                      className: `badge sfm-badge-btn sfm-state-pill ml-2 font-weight-bold sfm-pill-subfolders ${includeSubfolders ? "sfm-state-active" : "sfm-state-inactive"}`,
                      onClick: (e) => {
                        e.stopPropagation();
                        handleToggleIncludeSubfolders(!includeSubfolders);
                      },
                      title: includeSubfolders
                        ? "Click to exclude sub-folders (show direct folder files only)"
                        : "Click to recursively include scenes from all sub-folders",
                    },
                    "Include Sub-Folders"
                  ),
                  // Toggle 2: Group by Folder (Bold, 2 color states matching status indicators)
                  React.createElement(
                    "button",
                    {
                      type: "button",
                      className: `badge sfm-badge-btn sfm-state-pill ml-2 font-weight-bold sfm-pill-foldersort ${sortByFolderFirst ? "sfm-state-active" : "sfm-state-inactive"}`,
                      onClick: (e) => {
                        e.stopPropagation();
                        handleToggleSortByFolderFirst(!sortByFolderFirst);
                      },
                      title: sortByFolderFirst
                        ? "Click to disable folder grouping and sort all scenes altogether"
                        : "Click to group and sort scenes by folder order first",
                    },
                    "Group by Folder"
                  ),
                  // Toggle 3: Hide Empty (Bold, 2 color states matching status indicators, unified padding)
                  React.createElement(
                    "button",
                    {
                      type: "button",
                      className: `badge sfm-badge-btn sfm-state-pill ml-2 font-weight-bold sfm-pill-hideempty ${hideEmpty ? "sfm-state-active" : "sfm-state-inactive"}`,
                      onClick: (e) => {
                        e.stopPropagation();
                        handleToggleHideEmpty(!hideEmpty);
                      },
                      title: "Hide empty subfolders",
                    },
                    "Hide Empty"
                  )
                ),
                !isSubfoldersCollapsed &&
                  React.createElement(
                    "div",
                    { className: "d-flex align-items-center justify-content-end flex-wrap gap-2 ml-auto" },
                    folderViewMode === "cards" &&
                      React.createElement(
                        "div",
                        {
                          className: "d-flex align-items-center sfm-size-slider-wrap mr-2",
                          title: `Adjust folder card thumbnail size: ${folderCardSize}px`,
                        },
                        React.createElement(IconZoom, { size: 12, color: "#81a1c1" }),
                        React.createElement("input", {
                          type: "range",
                          className: "sfm-size-slider",
                          min: 120,
                          max: 300,
                          step: 10,
                          value: folderCardSize,
                          onChange: (e) => handleSetFolderCardSize(Number(e.target.value)),
                        })
                      ),
                    folderViewMode === "list" &&
                      React.createElement(
                        "div",
                        {
                          className: "d-flex align-items-center sfm-size-slider-wrap mr-2",
                          title: `Adjust folder list box length: ${folderListWidth}px`,
                        },
                        React.createElement(IconWidth, { size: 12, color: "#81a1c1" }),
                        React.createElement("input", {
                          type: "range",
                          className: "sfm-size-slider",
                          min: 140,
                          max: 420,
                          step: 10,
                          value: folderListWidth,
                          onChange: (e) => handleSetFolderListWidth(Number(e.target.value)),
                        })
                      ),
                    React.createElement(
                      "div",
                      { className: "btn-group btn-group-sm sfm-view-toggle-group" },
                      React.createElement(
                        "button",
                        {
                          type: "button",
                          className: `btn btn-sm ${folderViewMode === "cards" ? "btn-info" : "btn-outline-secondary"} py-0 px-2`,
                          onClick: () => { setIsSubfoldersCollapsed(false); handleSetFolderViewMode("cards"); },
                          title: "Compact Cards View",
                        },
                        "Cards"
                      ),
                      React.createElement(
                        "button",
                        {
                          type: "button",
                          className: `btn btn-sm ${folderViewMode === "list" ? "btn-info" : "btn-outline-secondary"} py-0 px-2`,
                          onClick: () => { setIsSubfoldersCollapsed(false); handleSetFolderViewMode("list"); },
                          title: "Compact List View",
                        },
                        "List"
                      ),
                      React.createElement(
                        "button",
                        {
                          type: "button",
                          className: `btn btn-sm ${folderViewMode === "detail" ? "btn-info" : "btn-outline-secondary"} py-0 px-2`,
                          onClick: () => { setIsSubfoldersCollapsed(false); handleSetFolderViewMode("detail"); },
                          title: "Detail Table View",
                        },
                        "Details"
                      )
                    )
                  )
              ),
              // Render Folder View based on mode (if not collapsed)
              !isSubfoldersCollapsed &&
                (folderViewMode === "cards"
                  ? React.createElement(
                  "div",
                  {
                    className: "sfm-folder-cards-grid",
                    style: { "--sfm-folder-card-size": `${folderCardSize}px` },
                  },
                  filteredAndSortedSubfolders.map((folderName) => {
                    const childNode = currentNode.folders[folderName];
                    const count = childNode ? childNode.allSceneIds.size : 0;
                    const size = childNode ? formatBytes(childNode.totalSize) : "0 B";
                    const nextPath = currentPath ? `${currentPath}/${folderName}` : folderName;
                    const firstSceneId = childNode && childNode.allSceneIds && childNode.allSceneIds.size > 0 ? childNode.allSceneIds.values().next().value : null;
                    const firstScene = firstSceneId ? ((window.__SFM_GLOBAL_CACHE__?.scenes || []).find(s => String(s.id) === String(firstSceneId)) || null) : null;
                    const folderThumb = firstScene?.paths?.screenshot || "";
                    const subCount = childNode ? Object.keys(childNode.folders).length : 0;

                    return React.createElement(
                      "div",
                      {
                        key: folderName,
                        className: "card studio-card sfm-native-folder-card sfm-folder-card sfm-folder-card-compact",
                        style: { width: `${folderCardSize}px`, minWidth: `${Math.min(130, folderCardSize)}px` },
                        onClick: () => navigateToFolder(nextPath),
                        title: `${folderName} (${count} scenes, ${size})`,
                      },
                      React.createElement(
                        "div",
                        { className: "card-image-container image-container sfm-folder-cover-container" },
                        folderThumb
                          ? React.createElement("img", {
                              src: folderThumb,
                              alt: folderName,
                              className: "card-image sfm-folder-cover-img",
                              loading: "lazy",
                            })
                          : React.createElement(
                              "div",
                              { className: "sfm-folder-cover-placeholder d-flex align-items-center justify-content-center" },
                              React.createElement(IconFolderCard, { size: Math.max(28, Math.min(48, Math.round(folderCardSize * 0.22))), color: "#81a1c1" })
                            ),
                        React.createElement(
                          "div",
                          { className: "sfm-folder-type-badge" },
                          React.createElement(IconFolder, { size: 12, color: "#ffffff" }),
                          React.createElement("span", { className: "ml-1" }, "FOLDER")
                        ),
                        React.createElement(
                          "div",
                          { className: "sfm-folder-card-hover-actions" },
                          count > 0 && React.createElement(
                            "button",
                            {
                              type: "button",
                              className: "btn btn-sm btn-primary sfm-folder-quick-btn",
                              onClick: (e) => {
                                e.stopPropagation();
                                const q = (window.__SFM_GLOBAL_CACHE__?.scenes || []).filter(s => childNode.allSceneIds.has(s.id));
                                if (q.length > 0) handlePlayScene(q[0], q);
                              },
                              title: "Play all scenes in Binge Reel",
                            },
                            "▶ Reel"
                          ),
                          React.createElement(
                            "button",
                            {
                              type: "button",
                              className: "btn btn-sm btn-secondary sfm-folder-quick-btn ml-1",
                              onClick: (e) => {
                                e.stopPropagation();
                                navigateToFolder(nextPath);
                                setShowFolderProfile(true);
                                setCurrentProfilePage(0);
                              },
                              title: "Open Video Wall",
                            },
                            "▦ Wall"
                          )
                        ),
                        React.createElement(
                          "div",
                          { className: "sfm-folder-thumb-badges" },
                          React.createElement("span", { className: "badge badge-secondary sfm-badge" }, React.createElement("strong", { style: { color: "#88c0d0" } }, count), " scenes"),
                          count > 0 && React.createElement("span", { className: "badge badge-dark sfm-badge ml-1" }, size)
                        )
                      ),
                      React.createElement(
                        "div",
                        { className: "card-section sfm-folder-card-details p-2" },
                        React.createElement("h5", { className: "card-title sfm-folder-name text-truncate mb-1 font-weight-bold", title: folderName }, folderName),
                        React.createElement(
                          "div",
                          { className: "card-subtitle text-muted small text-truncate d-flex align-items-center justify-content-between" },
                          React.createElement("span", null, subCount > 0 ? `${subCount} subfolders` : "Folder"),
                          React.createElement("span", { className: "badge badge-dark text-info" }, `/${folderName}`)
                        )
                      )
                    );
                  })
                )
              : folderViewMode === "list"
                ? React.createElement(
                  "div",
                  {
                    className: "sfm-folder-list-grid",
                    style: { "--sfm-folder-list-width": `${folderListWidth}px` },
                  },
                  filteredAndSortedSubfolders.map((folderName) => {
                    const childNode = currentNode.folders[folderName];
                    const count = childNode ? childNode.allSceneIds.size : 0;
                    const size = childNode ? formatBytes(childNode.totalSize) : "0 B";
                    const nextPath = currentPath ? `${currentPath}/${folderName}` : folderName;
                    return React.createElement(
                      "div",
                      {
                        key: folderName,
                        className: "sfm-folder-list-item",
                        onClick: () => navigateToFolder(nextPath),
                        title: `${folderName} (${count} scenes, ${size})`,
                      },
                      React.createElement("div", { className: "sfm-folder-list-icon" }, React.createElement(IconFolderCard, { size: 18, color: "#81a1c1" })),
                      React.createElement("div", { className: "sfm-folder-list-name text-truncate font-weight-bold" }, folderName),
                      React.createElement("span", { className: "sfm-folder-list-badge" }, React.createElement("strong", { style: { color: "#88c0d0" } }, count))
                    );
                  })
                )
                : React.createElement(
                  "div",
                  { className: "table-responsive mb-3" },
                  React.createElement(
                    "table",
                    { className: "table table-dark table-sm sfm-folder-table" },
                    React.createElement(
                      "thead",
                      null,
                      React.createElement(
                        "tr",
                        null,
                        React.createElement("th", { style: { minWidth: "200px" } }, "Folder Name"),
                        React.createElement("th", { style: { width: "110px" } }, "Type"),
                        React.createElement("th", { style: { width: "120px" } }, "Scenes"),
                        React.createElement("th", { style: { width: "110px" } }, "Size"),
                        React.createElement("th", { style: { width: "140px", textAlign: "right" } }, "Actions")
                      )
                    ),
                    React.createElement(
                      "tbody",
                      null,
                      filteredAndSortedSubfolders.map((folderName) => {
                        const childNode = currentNode.folders[folderName];
                        const count = childNode ? childNode.allSceneIds.size : 0;
                        const size = childNode ? formatBytes(childNode.totalSize) : "0 B";
                        const nextPath = currentPath ? `${currentPath}/${folderName}` : folderName;
                        return React.createElement(
                          "tr",
                          {
                            key: folderName,
                            className: "sfm-folder-table-row",
                            onClick: () => navigateToFolder(nextPath),
                            title: `Navigate into ${folderName}`,
                          },
                          React.createElement(
                            "td",
                            null,
                            React.createElement(
                              "div",
                              { className: "d-flex align-items-center" },
                              React.createElement("span", { className: "mr-2" }, React.createElement(IconFolderCard, { size: 18, color: "#81a1c1" })),
                              React.createElement("span", { className: "sfm-folder-table-name font-weight-bold" }, folderName)
                            )
                          ),
                          React.createElement("td", { className: "text-muted small" }, "Directory"),
                          React.createElement("td", null, React.createElement("span", { className: "badge badge-dark" }, React.createElement("strong", { style: { color: "#88c0d0" } }, count), " scenes")),
                          React.createElement("td", { className: "text-muted small" }, size),
                          React.createElement(
                            "td",
                            { style: { textAlign: "right" } },
                            React.createElement(
                              "button",
                              {
                                className: "btn btn-sm btn-outline-info py-0 px-2 mr-1",
                                onClick: (e) => {
                                  e.stopPropagation();
                                  const filter = { type: "path", value: nextPath, modifier: "MATCHES_REGEX" };
                                  window.open(`/scenes?c=${encodeURIComponent(JSON.stringify(filter))}`, "_blank");
                                },
                                title: "Open folder in Stash native scene grid (new tab)",
                              },
                              "↗ Grid"
                            ),
                            React.createElement(
                              "button",
                              {
                                className: "btn btn-sm btn-outline-secondary py-0 px-2",
                                onClick: async (e) => {
                                  e.stopPropagation();
                                  try {
                                    await gqlFetch(`mutation ScanPath($paths: [String!]) { metadataScan(input: { paths: $paths }) }`, { paths: [nextPath] });
                                    setNotification(`Scan triggered for "${nextPath}". Check Settings -> Tasks.`);
                                  } catch (err) {
                                    setNotification(`Scan error: ${err.message}`);
                                  }
                                },
                                title: "Trigger Stash filesystem scan for this folder",
                              },
                              React.createElement(IconSearch, { size: 12, className: "mr-1" }), "Scan"
                            )
                          )
                        );
                      })
                    )
                  )
                ))
            ),
          // Direct Scenes Section (Milestone 1 & 2)
          filteredAndSortedScenes.length > 0 &&
            React.createElement(
              "div",
              { className: "mb-4" },
              React.createElement(
                "div",
                { className: "d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2 position-relative" },
                // Left group: Title + count + indicator 1 + indicator 2
                React.createElement(
                  "div",
                  { className: "d-flex align-items-center flex-wrap" },
                  React.createElement(
                    "div",
                    {
                      className: "sfm-section-title-box sfm-section-header mb-0 sfm-collapsible-title",
                      onClick: handleToggleFilesCollapsed,
                      title: isFilesCollapsed ? "Click to expand Files" : "Click to collapse Files",
                      style: { cursor: "pointer", userSelect: "none" },
                    },
                    React.createElement(
                      "span",
                      { className: "sfm-collapse-chevron mr-2 text-info font-weight-bold" },
                      isFilesCollapsed ? "▶" : "▼"
                    ),
                    React.createElement("span", { className: "sfm-section-title-label" }, "Files / Scenes"),
                    React.createElement(
                      "span",
                      { className: "badge badge-dark sfm-section-count-badge font-weight-normal" },
                      React.createElement("strong", { style: { color: "#88c0d0" } }, filteredAndSortedScenes.length)
                    ),
                    isFilesCollapsed &&
                      React.createElement("span", { className: "text-muted small ml-2 font-italic sfm-collapsed-indicator", style: { display: "none" } }, "(collapsed)")
                  ),
                  // Status Button 1: Sub-Folders Included / Excluded (Interactive & aligned with line 1 toggle)
                  React.createElement(
                    "button",
                    {
                      type: "button",
                      className: `badge sfm-badge-btn sfm-stat-pill sfm-badge-indicator sfm-state-pill ml-2 font-weight-bold sfm-pill-subfolders ${includeSubfolders ? "sfm-state-active" : "sfm-state-inactive"}`,
                      onClick: (e) => {
                        e.stopPropagation();
                        handleToggleIncludeSubfolders(!includeSubfolders);
                      },
                      title: includeSubfolders ? "Sub-folders are included in scenes view (Click to exclude)" : "Sub-folders are excluded from scenes view (Click to include)",
                    },
                    includeSubfolders ? "Sub-Folders Included" : "Sub-Folders Excluded"
                  ),
                  // Status Button 2: Grouped by Folder / Sorted Altogether (Interactive & aligned with line 1 toggle)
                  React.createElement(
                    "button",
                    {
                      type: "button",
                      className: `badge sfm-badge-btn sfm-stat-pill sfm-badge-indicator sfm-state-pill ml-2 font-weight-bold sfm-pill-foldersort ${sortByFolderFirst ? "sfm-state-active" : "sfm-state-inactive"}`,
                      onClick: (e) => {
                        e.stopPropagation();
                        handleToggleSortByFolderFirst(!sortByFolderFirst);
                      },
                      title: sortByFolderFirst ? "Scenes ordered by folder sort first (Click to sort altogether)" : "Scenes sorted altogether across all folders (Click to group by folder)",
                    },
                    sortByFolderFirst ? "Grouped by Folder" : "Sorted Altogether"
                  )
                ),
                // Center: [select all (centered)]
                !isFilesCollapsed &&
                  React.createElement(
                    "div",
                    { className: "d-flex align-items-center justify-content-center flex-grow-1 mx-2" },
                    React.createElement(
                      "button",
                      {
                        type: "button",
                        className: `btn btn-sm ${selectedSceneIds.size > 0 ? "btn-primary font-weight-bold" : "btn-outline-secondary"} py-0 px-3 sfm-pill-selectall`,
                        onClick: handleSelectAllFolderScenes,
                        title: selectedSceneIds.size > 0 ? `Click to deselect all (${selectedSceneIds.size} selected)` : "Select all visible scenes in folder",
                      },
                      selectedSceneIds.size > 0 ? `${selectedSceneIds.size} Selected` : "Select All"
                    )
                  ),
                // Right: slider + [Cards, Table, Names]
                !isFilesCollapsed &&
                  React.createElement(
                    "div",
                    { className: "d-flex align-items-center justify-content-end flex-wrap gap-2 ml-auto" },
                    viewMode === "grid" &&
                      React.createElement(
                        "div",
                        {
                          className: "d-flex align-items-center sfm-size-slider-wrap mr-2",
                          title: `Adjust scene thumbnail card size: ${sceneCardSize}px (up to 10 per row)`,
                        },
                        React.createElement(IconZoom, { size: 12, color: "#81a1c1" }),
                        React.createElement("input", {
                          type: "range",
                          className: "sfm-size-slider",
                          min: 110,
                          max: 460,
                          step: 10,
                          value: sceneCardSize,
                          onChange: (e) => handleSetSceneCardSize(Number(e.target.value)),
                        })
                      ),
                    React.createElement(
                      "div",
                      { className: "btn-group btn-group-sm sfm-view-toggle-group" },
                      React.createElement(
                        "button",
                        {
                          type: "button",
                          className: `btn btn-sm ${viewMode === "grid" ? "btn-info" : "btn-outline-secondary"} py-0 px-2`,
                          onClick: () => handleToggleViewMode("grid"),
                          title: "16:9 Thumbnail Cards View",
                        },
                        "Cards"
                      ),
                      React.createElement(
                        "button",
                        {
                          type: "button",
                          className: `btn btn-sm ${viewMode === "list" ? "btn-info" : "btn-outline-secondary"} py-0 px-2`,
                          onClick: () => handleToggleViewMode("list"),
                          title: "Detailed Metadata Table View",
                        },
                        "Table"
                      ),
                      React.createElement(
                        "button",
                        {
                          type: "button",
                          className: `btn btn-sm ${viewMode === "names" ? "btn-info" : "btn-outline-secondary"} py-0 px-2`,
                          onClick: () => handleToggleViewMode("names"),
                          title: "Filenames Only (for Easy Bulk Selection & Regex)",
                        },
                        "Names"
                      )
                    )
                  )
              ),
              !isFilesCollapsed &&
                React.createElement(
                  React.Fragment,
                  null,
                  viewMode === "list"
                    ? React.createElement(SceneTableView, {
                      scenes: visibleScenes,
                      onPlay: (s) => handlePlayScene(s),
                      selectedIds: selectedSceneIds,
                      onToggleSelect: handleToggleSelect,
                      onSelectAll: handleSelectAllFolderScenes,
                      showFolderBadge: includeSubfolders,
                      currentPath,
                    })
                  : viewMode === "names"
                    ? React.createElement(SceneNamesTableView, {
                      scenes: visibleScenes,
                      onPlay: (s) => handlePlayScene(s),
                      selectedIds: selectedSceneIds,
                      onToggleSelect: handleToggleSelect,
                      onSelectAll: handleSelectAllFolderScenes,
                      showFolderBadge: includeSubfolders,
                      currentPath,
                    })
                  : React.createElement(
                      "div",
                      {
                        className: "sfm-scene-cards-grid",
                        style: { "--sfm-scene-card-size": `${sceneCardSize}px` },
                      },
                      visibleScenes.map((scene) =>
                        React.createElement(SceneCard, {
                          key: scene.id,
                          scene,
                          onPlay: () => handlePlayScene(scene),
                          isSelected: selectedSceneIds.has(scene.id),
                          onToggleSelect: handleToggleSelect,
                          showFolderBadge: includeSubfolders,
                          currentPath,
                        })
                      )
                    ),
                  // Progressive Feed Load Sentinel & Memory Optimization Controls
                  React.createElement(
                    "div",
                    {
                      ref: sceneSentinelRef,
                      className: "sfm-scene-sentinel py-3 text-center w-100",
                    },
                    visibleSceneCount < filteredAndSortedScenes.length
                      ? React.createElement(
                          "div",
                          { className: "d-inline-flex flex-column align-items-center gap-1 text-muted small" },
                          React.createElement(
                            "span",
                            null,
                            `Showing ${visibleScenes.length} of ${filteredAndSortedScenes.length} scenes`
                          ),
                          React.createElement(
                            "button",
                            {
                              type: "button",
                              className: "btn btn-sm btn-outline-info px-3 py-1 mt-1 font-weight-bold",
                              onClick: () => setVisibleSceneCount((prev) => Math.min(prev + SCENE_CHUNK_SIZE, filteredAndSortedScenes.length)),
                            },
                            `Load Next ${Math.min(SCENE_CHUNK_SIZE, filteredAndSortedScenes.length - visibleScenes.length)} Scenes`
                          )
                        )
                      : filteredAndSortedScenes.length > SCENE_CHUNK_SIZE
                      ? React.createElement(
                          "span",
                          { className: "text-muted small font-italic" },
                          `✓ All ${filteredAndSortedScenes.length} scenes loaded`
                        )
                      : null
                  )
                )
            ),
          filteredAndSortedSubfolders.length === 0 &&
            filteredAndSortedScenes.length === 0 &&
            React.createElement(
              "div",
              { className: "text-center py-5 text-muted" },
              React.createElement("h5", null, searchQuery ? "No matching folders or scenes found." : "This folder contains no scanned media files."),
              searchQuery
                ? React.createElement("button", { className: "btn btn-outline-secondary mt-2", onClick: () => setSearchQuery("") }, "Clear Search")
                : React.createElement("button", { className: "btn btn-outline-secondary mt-2", onClick: () => navigateToFolder("") }, "Return to Stash")
            ),
          // Floating Bulk Action Bar (Centered Bottom)
          selectedSceneIds.size > 0 &&
            React.createElement(
              "div",
              { className: "sfm-floating-bulk-bar" },
              React.createElement(
                "div",
                { className: "sfm-bulk-inner" },
                // Selected counter doubles as Clear when clicked, styled exactly like center select button
                React.createElement(
                  "button",
                  {
                    type: "button",
                    className: "btn btn-sm btn-primary font-weight-bold py-0 px-3 sfm-pill-selectall sfm-bulk-select-btn",
                    onClick: handleClearSelection,
                    title: `Click to deselect all (${selectedSceneIds.size} selected)`,
                  },
                  `${selectedSceneIds.size} Selected`
                ),
                React.createElement(
                  "div",
                  { className: "btn-group btn-group-sm" },
                  React.createElement(
                    "button",
                    {
                      type: "button",
                      className: "btn btn-sm btn-outline-secondary py-1 px-2",
                      onClick: () => setShowBatchModal(true),
                      title: "Batch edit selected scenes",
                    },
                    React.createElement(IconEdit, { size: 13, className: "mr-1" }),
                    "Batch Edit"
                  ),
                  React.createElement(
                    "button",
                    {
                      type: "button",
                      className: "btn btn-sm btn-outline-secondary py-1 px-2",
                      onClick: () => setShowParserModal(true),
                      title: "Regex parse selected scenes",
                    },
                    React.createElement(IconSearch, { size: 13, className: "mr-1" }),
                    "Parse"
                  ),
                  React.createElement(
                    "button",
                    {
                      type: "button",
                      className: "btn btn-sm btn-outline-secondary py-1 px-2 d-inline-flex align-items-center justify-content-center",
                      onClick: () => {
                        const ids = Array.from(selectedSceneIds);
                        const filterCriterion = {
                          type: "ids",
                          value: ids,
                          modifier: "INCLUDES",
                        };
                        window.open(`/scenes?c=${encodeURIComponent(JSON.stringify(filterCriterion))}`, "_blank");
                      },
                      title: "Open selected scenes in Stash native grid (new tab)",
                    },
                    React.createElement(IconGrid, { size: 14 })
                  )
                )
              )
            ),
          // Modals
          showBatchModal &&
            React.createElement(BatchMetadataModal, {
              currentFolder: selectedSceneIds.size > 0 ? `${selectedSceneIds.size} selected scenes` : currentFolderName,
              sceneCount: selectedSceneIds.size > 0 ? selectedSceneIds.size : allDescendantIds.length,
              sceneIds: selectedSceneIds.size > 0 ? Array.from(selectedSceneIds) : allDescendantIds,
              onClose: () => setShowBatchModal(false),
              onApplied: () => {
                handleClearSelection();
                handleRescan();
              },
            }),
          showParserModal &&
            React.createElement(FilenameParserModal, {
              currentFolder: selectedSceneIds.size > 0 ? `${selectedSceneIds.size} selected scenes` : currentFolderName,
              currentPath: currentPath || "",
              directScenes: selectedSceneIds.size > 0
                ? (includeSubfolders
                    ? getAllDescendantScenes(currentNode).filter((s) => selectedSceneIds.has(s.id))
                    : (currentNode ? currentNode.directScenes.filter((s) => selectedSceneIds.has(s.id)) : []))
                : (includeSubfolders
                    ? getAllDescendantScenes(currentNode)
                    : (currentNode ? currentNode.directScenes : [])),
              onClose: () => setShowParserModal(false),
              onApplied: () => {
                handleClearSelection();
                handleRescan();
              },
            }),
          showSettingsModal &&
            React.createElement(SettingsAndTasksModal, {
              isOpen: showSettingsModal,
              onClose: () => setShowSettingsModal(false),
              settings: pluginSettings,
              onSaveSettings: async (newVals) => {
                await saveStashPluginSettings(newVals);
                setPluginSettings((prev) => ({ ...(prev || {}), ...newVals }));
                if (newVals.default_transcode_method) {
                  window.__SFM_DEFAULT_TRANSCODE_METHOD__ = newVals.default_transcode_method;
                  try { window.localStorage.setItem("sfm_stream_mode", newVals.default_transcode_method); } catch(e) {}
                }
                if (newVals.fallback_transcode_method) {
                  window.__SFM_FALLBACK_TRANSCODE_METHOD__ = newVals.fallback_transcode_method;
                }
                if (newVals.folder_view_mode) {
                  setFolderViewMode(newVals.folder_view_mode);
                  try { window.localStorage.setItem("sfm_folder_view_mode", newVals.folder_view_mode); } catch(e) {}
                }
                if (newVals.scene_view_mode) {
                  const m = newVals.scene_view_mode === "cards" ? "grid" : "table";
                  setViewMode(m);
                  try { window.localStorage.setItem("sfm_view_mode", m); } catch(e) {}
                }
                if (newVals.folder_card_size) {
                  setFolderCardSize(Number(newVals.folder_card_size));
                  try { window.localStorage.setItem("sfm_folder_card_size", String(newVals.folder_card_size)); } catch(e) {}
                }
                if (newVals.scene_card_size) {
                  setSceneCardSize(Number(newVals.scene_card_size));
                  try { window.localStorage.setItem("sfm_scene_card_size", String(newVals.scene_card_size)); } catch(e) {}
                }
                setNotification("✓ Settings saved to Stash config.yml");
                setTimeout(() => setNotification(""), 3500);
              },
              onTriggerRebuild: () => {
                setShowSettingsModal(false);
                handleRescan();
              },
              onResetDefaults: async () => {
                const defaults = {
                  default_transcode_method: "direct",
                  fallback_transcode_method: "hls",
                  root_library_path: "",
                  folder_view_mode: "cards",
                  scene_view_mode: "cards",
                  default_sort_field: "name",
                  default_sort_direction: "asc",
                  folder_card_size: 160,
                  scene_card_size: 240,
                  remember_last_path: true,
                  auto_rebuild_tree_on_start: false,
                };
                await saveStashPluginSettings(defaults);
                setPluginSettings(defaults);
                window.__SFM_DEFAULT_TRANSCODE_METHOD__ = "direct";
                try {
                  window.localStorage.removeItem("sfm_stream_mode");
                  window.localStorage.removeItem("sfm_folder_card_size");
                  window.localStorage.removeItem("sfm_scene_card_size");
                  window.localStorage.removeItem("sfm_folder_view_mode");
                  window.localStorage.removeItem("sfm_view_mode");
                } catch(e) {}
                setFolderCardSize(160);
                setSceneCardSize(240);
                setFolderViewMode("cards");
                setViewMode("grid");
                setShowSettingsModal(false);
                setNotification("✓ Settings reset to defaults");
                setTimeout(() => setNotification(""), 3500);
                handleRescan();
              }
            })
        ),
        showFolderProfile &&
            (() => {
              const activeProfilePath = (playingScene ? resolveSceneFolder(playingScene, trie) : null) || currentPath || "";
              const activeProfileName = activeProfilePath ? activeProfilePath.split("/").filter(Boolean).pop() : (currentFolderName || "Root");
              const activeDisplayPath = activeProfilePath ? `/${activeProfilePath}` : "/";

              return React.createElement(FolderProfileView, {
                folderName: activeProfileName,
                targetFolderPath: activeProfilePath,
                displayFolderPath: activeDisplayPath,
                scenes: filteredAndSortedScenes,
                currentScene: playingScene || filteredAndSortedScenes[0],
                posterUrl: (playingScene?.paths?.screenshot || filteredAndSortedScenes[0]?.paths?.screenshot) || "",
                isForceMobile: false,
                initialPage: currentProfilePage,
                onFolderChange: (newPath) => {
                  if (newPath !== currentPath) {
                    setCurrentPath(newPath);
                    localStorage.setItem("sfm_last_folder_path", newPath);
                  }
                },
                onPageChange: (newPage) => {
                  setCurrentProfilePage(newPage);
                  const viewName = newPage === 1 ? "discover" : "profile";
                  const targetHash = buildHashForPath(activeProfilePath, viewName, null);
                  if (window.location.hash !== targetHash) {
                    window.history.replaceState({ sfmPath: activeProfilePath, sfmView: viewName, sfmScene: null }, "", targetHash);
                  }
                },
                isInsidePlayer: false,
                onSelectScene: (s, q) => handlePlayScene(s, q),
                onCloseProfile: handleCloseFolderProfile,
                onNavigateToDirectory: (fPath) => {
                  handleCloseFolderProfile();
                  const dest = fPath !== undefined ? fPath : activeProfilePath;
                  if (dest !== currentPath) {
                    navigateToFolder(dest);
                  }
                },
                onPlayAll: (q) => {
                  const list = Array.isArray(q) && q.length > 0 ? q : filteredAndSortedScenes;
                  if (list.length > 0) {
                    handlePlayScene(list[0], list);
                  }
                },
                onShuffleAll: () => {
                  if (filteredAndSortedScenes.length > 0) {
                    const q = createShuffledQueue(filteredAndSortedScenes, filteredAndSortedScenes[0]);
                    handlePlayScene(q[0], q);
                  }
                },
              });
            })(),
          playingScene &&
            React.createElement(
              SafeErrorBoundary,
              { onReset: handleClosePlayer },
              React.createElement(BingeReelPlayerModal, {
                scene: playingScene,
                scenes: customPlayerScenes || filteredAndSortedScenes,
                onSelectScene: (s, q) => handlePlayScene(s, q),
                onClose: handleClosePlayer,
                onOpenProfile: handleOpenProfileFromPlayer,
                folderName: currentFolderName,
                currentPath: currentPath,
                onNavigateToFolder: (path) => {
                  handleClosePlayer();
                  navigateToFolder(path);
                },
              })
            )
      );
    }

    // Native Viewport Container Mounting & Lifecycle Management
    function getOrCreateWorkspaceRoot() {
      let root = document.getElementById("sfm-workspace-root");
      const mainContainer = (typeof document !== "undefined" && (document.querySelector(".main-container, main, #root .container-fluid, #root > div:nth-child(2)") || document.body)) || null;

      if (!root) {
        root = document.createElement("div");
        root.id = "sfm-workspace-root";
        root.className = "sfm-native-embedded-workspace";

        if (mainContainer && mainContainer !== document.body) {
          mainContainer.appendChild(root);
          mainContainer.setAttribute("data-sfm-embedded", "true");
        } else if (document.body) {
          document.body.appendChild(root);
        }
      } else if (mainContainer && root.parentElement === document.body && mainContainer !== document.body) {
        mainContainer.appendChild(root);
        mainContainer.setAttribute("data-sfm-embedded", "true");
      }
      return root;
    }

    function closeWorkspace() {
      const root = document.getElementById("sfm-workspace-root");
      if (root) {
        root.style.display = "none";
      }
      const mainContainer = typeof document !== "undefined" && document.querySelector(".main-container, main, #root .container-fluid, #root > div:nth-child(2)");
      if (mainContainer) {
        mainContainer.removeAttribute("data-sfm-active");
      }
      if (typeof document !== "undefined" && document.body) {
        document.body.removeAttribute("data-sfm-active");
        document.body.classList.remove("sfm-body-locked");
      }
      if (typeof window !== "undefined" && window.location?.hash?.startsWith("#file-manager")) {
        window.history.pushState(null, "", window.location.pathname + window.location.search);
      }
    }

    function openFileManager(targetPath, isBrowserNav = false, targetView = null, targetSceneId = null) {
      const state = parseHashState();
      const path = typeof targetPath === "string" ? normalizePath(targetPath) : (state !== null ? state.path : normalizePath(localStorage.getItem("sfm_last_folder_path") || ""));
      const view = targetView !== undefined && targetView !== null ? targetView : state?.view;
      const sceneId = targetSceneId !== undefined && targetSceneId !== null ? targetSceneId : state?.sceneId;

      const mainContainer = typeof document !== "undefined" && document.querySelector(".main-container, main, #root .container-fluid, #root > div:nth-child(2)");
      if (mainContainer) {
        mainContainer.setAttribute("data-sfm-active", "true");
      }
      if (typeof document !== "undefined" && document.body) {
        document.body.setAttribute("data-sfm-active", "true");
      }

      const root = getOrCreateWorkspaceRoot();
      if (root) {
        root.style.display = "block";
        if (!root._sfm_mounted) {
          root._sfm_mounted = true;
          ReactDOM.render(
            React.createElement(
              SafeErrorBoundary,
              { onReset: closeWorkspace },
              React.createElement(FileManagerView, { onClose: closeWorkspace, initialPath: path })
            ),
            root
          );
        } else {
          window.dispatchEvent(new CustomEvent("sfm:set-path", { detail: { path, isBrowserNav, view, sceneId } }));
        }
      }

      if (!isBrowserNav && typeof window !== "undefined") {
        const expectedHash = buildHashForPath(path, view, sceneId);
        if (window.location.hash !== expectedHash) {
          const nextDepth = getNextSfmDepth();
          window.history.pushState({ sfmPath: path, sfmView: view, sfmScene: sceneId, sfmDepth: nextDepth }, "", expectedHash);
        }
      }
    }

    // Listen to hash and popstate changes
    window.addEventListener("hashchange", () => {
      const state = parseHashState();
      const root = document.getElementById("sfm-workspace-root");
      if (state !== null) {
        if (root) {
          root.style.display = "block";
          window.dispatchEvent(new CustomEvent("sfm:set-path", { detail: { path: state.path, isBrowserNav: true } }));
        } else {
          openFileManager(state.path, true);
        }
      } else {
        if (root) {
          root.style.display = "none";
        }
      }
    });

    window.addEventListener("popstate", () => {
      const state = parseHashState();
      const root = document.getElementById("sfm-workspace-root");
      if (state !== null) {
        if (root) {
          root.style.display = "block";
          window.dispatchEvent(new CustomEvent("sfm:set-path", { detail: { path: state.path, isBrowserNav: true } }));
        } else {
          openFileManager(state.path, true);
        }
      } else {
        if (root) {
          root.style.display = "none";
        }
      }
    });

    if (window.location.hash.startsWith("#file-manager")) {
      setTimeout(() => openFileManager(undefined, true), 200);
      if (!window.history.state || typeof window.history.state.sfmDepth !== "number") {
        const state = parseHashState();
        window.history.replaceState({ ...window.history.state, sfmPath: state?.path || "", sfmDepth: 1 }, "", window.location.hash);
      }
    }

    if (register && register.route) {
      register.route("/plugin/file-manager", FileManagerView);
    }

    // ==========================================================================
    // Phase 4 (v3.0.0): Native Stash Platform Deep Embedding Components
    // ==========================================================================

    // Feature 1: Native Scene Card Overlay (Path Chip & 1-Click Hover Actions)
    function NativeSceneCardOverlay({ scene, folderPath }) {
      const [resolvedPath, setResolvedPath] = useState(() => {
        return folderPath || resolveSceneFolder(scene) || "";
      });

      useEffect(() => {
        let isMounted = true;
        const sceneId = scene?.id || scene?._id;
        if (!resolvedPath && sceneId) {
          const p = resolveSceneFolder(scene);
          if (p) {
            setResolvedPath(p);
          } else {
            // Fast single-scene on-demand GraphQL query (<10ms)
            if (typeof window !== "undefined" && typeof window.fetch === "function") {
              gqlFetch(`query FastSceneFolder($id: ID!) { findScene(id: $id) { id files { path } } }`, { id: sceneId })
                .then((data) => {
                  const filePath = data?.findScene?.files?.[0]?.path;
                  if (filePath && isMounted) {
                    const derived = deriveFolderFromPath(filePath);
                    if (derived) {
                      setResolvedPath(derived);
                      if (typeof scene === "object") {
                        scene._folderPath = derived;
                        if (!scene.files) scene.files = data.findScene.files;
                      }
                    }
                  }
                })
                .catch(() => {});
            }

            // Also load global catalog in background
            ensureCatalog().then((trie) => {
              if (isMounted && trie) {
                const fp = resolveSceneFolder(scene, trie);
                if (fp) setResolvedPath(fp);
              }
            }).catch(() => {});
          }
        }
        return () => { isMounted = false; };
      }, [scene, resolvedPath]);

      const p = resolvedPath || "";
      const displayPath = p ? (p.startsWith("/") ? p : `/${p}`) : "Folder";

      const handleOpenFolder = useCallback((e) => {
        if (e) {
          e.preventDefault();
          e.stopPropagation();
        }
        openFileManager(p);
      }, [p]);

      const handleOpenProfile = useCallback((e) => {
        if (e) {
          e.preventDefault();
          e.stopPropagation();
        }
        openFileManager(p, false, "profile");
      }, [p]);

      const handlePlayReel = useCallback((e) => {
        if (e) {
          e.preventDefault();
          e.stopPropagation();
        }
        openFileManager(p, false, null, scene?.id);
      }, [p, scene?.id]);

      return React.createElement(
        "div",
        {
          className: "sfm-native-card-chip-container",
          "data-sfm-card-chip": "true",
          onClick: (e) => e.stopPropagation(),
        },
        React.createElement(
          "span",
          {
            className: "sfm-native-card-path-chip",
            title: `Directory: ${displayPath}\nClick to browse directory in File Manager`,
            onClick: handleOpenFolder,
          },
          React.createElement(IconFolder, { size: 12 }),
          React.createElement("span", { className: "sfm-chip-text" }, displayPath)
        ),
        React.createElement(
          "div",
          { className: "sfm-native-card-quick-actions" },
          React.createElement(
            "button",
            {
              type: "button",
              className: "sfm-card-action-icon",
              title: `Browse "${displayPath}" in File Manager`,
              onClick: handleOpenFolder,
            },
            React.createElement(IconFolder, { size: 11 })
          ),
          React.createElement(
            "button",
            {
              type: "button",
              className: "sfm-card-action-icon",
              title: `Open Video Wall Profile for "${displayPath}"`,
              onClick: handleOpenProfile,
            },
            React.createElement(IconGrid, { size: 11 })
          ),
          React.createElement(
            "button",
            {
              type: "button",
              className: "sfm-card-action-icon",
              title: "Watch in Binge Reel Mode",
              onClick: handlePlayReel,
            },
            React.createElement(IconPlay, { size: 11 })
          )
        ),
        React.createElement(
          "div",
          { className: "sfm-native-card-hover-actions" },
          React.createElement(
            "button",
            {
              type: "button",
              className: "sfm-native-card-hover-btn",
              title: `Open folder "${displayPath}" in File Manager`,
              onClick: handleOpenFolder,
            },
            React.createElement(IconFolder, { size: 12 }),
            React.createElement("span", null, "Folder")
          )
        )
      );
    }

    // Feature 2: Native Scene Detail Directory Hierarchy Breadcrumb Component
    function NativeSceneDetailDirectoryHierarchy({ scene, folderPath }) {
      const [resolvedPath, setResolvedPath] = useState(() => {
        return folderPath || resolveSceneFolder(scene) || "";
      });

      useEffect(() => {
        let isMounted = true;
        if (!resolvedPath && scene) {
          const p = resolveSceneFolder(scene);
          if (p) {
            setResolvedPath(p);
          } else {
            ensureCatalog().then((trie) => {
              if (isMounted && trie) {
                const fp = resolveSceneFolder(scene, trie);
                if (fp) setResolvedPath(fp);
              }
            }).catch(() => {});
          }
        }
        return () => { isMounted = false; };
      }, [scene, resolvedPath]);

      const p = resolvedPath || "";
      const segments = p.split("/").filter(Boolean);

      const crumbs = [
        { name: "Root", path: "" },
        ...segments.map((seg, idx) => ({
          name: seg,
          path: segments.slice(0, idx + 1).join("/"),
        })),
      ];

      return React.createElement(
        "div",
        {
          className: "sfm-scene-detail-directory-row",
          id: "sfm-scene-hierarchy-row",
          "data-sfm-hierarchy": "true",
        },
        React.createElement(
          "div",
          { className: "sfm-scene-detail-dir-header" },
          React.createElement(
            "span",
            { className: "sfm-scene-detail-dir-label" },
            React.createElement(IconFolder, { size: 13 }),
            React.createElement("span", null, "Directory Hierarchy")
          ),
          React.createElement(
            "div",
            { className: "sfm-scene-detail-dir-actions" },
            React.createElement(
              "button",
              {
                type: "button",
                className: "btn btn-secondary btn-sm",
                style: { padding: "2px 8px", fontSize: "0.75rem", display: "inline-flex", alignItems: "center", gap: "4px" },
                title: `Open Video Wall Profile for "${p || "Root"}"`,
                onClick: (e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  openFileManager(p, false, "profile");
                },
              },
              React.createElement(IconGrid, { size: 12 }),
              React.createElement("span", null, "Profile Wall")
            )
          )
        ),
        React.createElement(
          "div",
          { className: "sfm-scene-detail-breadcrumbs" },
          crumbs.map((crumb, idx) =>
            React.createElement(
              React.Fragment,
              { key: crumb.path || "root" },
              idx > 0 && React.createElement("span", { className: "sfm-breadcrumb-sep" }, "›"),
              React.createElement(
                "span",
                {
                  className: "sfm-breadcrumb-item",
                  title: `Browse "${crumb.name}" in File Manager`,
                  onClick: (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    openFileManager(crumb.path);
                  },
                },
                idx === 0 ? React.createElement(IconFolder, { size: 11 }) : null,
                React.createElement("span", null, crumb.name)
              )
            )
          )
        )
      );
    }

    // Feature 2: Native Scene Detail Reel Mode Button
    function NativeSceneDetailReelButton({ scene, folderPath }) {
      const handleLaunchReel = useCallback((e) => {
        if (e) {
          e.preventDefault();
          e.stopPropagation();
        }
        const path = folderPath || resolveSceneFolder(scene);
        openFileManager(path, false, null, scene?.id);
      }, [scene, folderPath]);

      return React.createElement(
        "button",
        {
          type: "button",
          className: "btn btn-primary sfm-scene-reel-mode-btn",
          id: "sfm-scene-reel-btn",
          "data-sfm-reel-btn": "true",
          title: "Watch this directory in full-viewport Binge Reel Player",
          onClick: handleLaunchReel,
        },
        React.createElement(IconFilm, { size: 14 }),
        React.createElement("span", null, "Reel Mode")
      );
    }

    // Helper: Detect whether a node already contains our SFM addons
    function hasSfmAddon(node, key) {
      if (!node) return false;
      if (Array.isArray(node)) {
        return node.some((c) => hasSfmAddon(c, key));
      }
      if (React.isValidElement(node)) {
        if (node.key === key) return true;
        if (node.props && (node.props["data-sfm-card-chip"] || node.props["data-sfm-hierarchy"] || node.props["data-sfm-reel-btn"])) {
          return true;
        }
        if (node.props && node.props.details && hasSfmAddon(node.props.details, key)) {
          return true;
        }
        return hasSfmAddon(node.props && node.props.children, key);
      }
      return false;
    }

    function patchNativeSceneCard(props, res) {
      try {
        if (!props || !res || !React.isValidElement(res)) return res;
        const scene = props.scene || (props.id ? props : props.item || null);
        if (!scene || !scene.id) return res;
        // If res is GridCard and already has details with SceneCardDetails, avoid duplicate overlay on outer card
        if (res.props && res.props.details && React.isValidElement(res.props.details)) {
          return res;
        }
        if (hasSfmAddon(res, "sfm-native-card-addon")) return res;
        const folderPath = resolveSceneFolder(scene);
        const addon = React.createElement(NativeSceneCardOverlay, {
          key: "sfm-native-card-addon",
          scene: scene,
          folderPath: folderPath,
        });
        return appendNavChild(res, addon);
      } catch (err) {
        console.warn("[PathFileManager] patchNativeSceneCard error:", err);
        return res;
      }
    }

    function patchNativeSceneDetails(props, res) {
      try {
        if (!props || !res || !React.isValidElement(res)) return res;
        const scene = props.scene || (props.id ? props : props.item || null);
        if (!scene || !scene.id) return res;
        if (hasSfmAddon(res, "sfm-scene-hierarchy-addon")) return res;
        const folderPath = resolveSceneFolder(scene);
        const hierarchyRow = React.createElement(NativeSceneDetailDirectoryHierarchy, {
          key: "sfm-scene-hierarchy-addon",
          scene: scene,
          folderPath: folderPath,
        });
        return appendNavChild(res, hierarchyRow);
      } catch (err) {
        console.warn("[PathFileManager] patchNativeSceneDetails error:", err);
        return res;
      }
    }

    function patchNativeScenePlayer(props, res) {
      try {
        if (!props || !res || !React.isValidElement(res)) return res;
        const scene = props.scene || (props.id ? props : props.item || null);
        if (!scene || !scene.id) return res;
        if (hasSfmAddon(res, "sfm-scene-reel-btn-addon")) return res;
        const folderPath = resolveSceneFolder(scene);
        const reelBtn = React.createElement(NativeSceneDetailReelButton, {
          key: "sfm-scene-reel-btn-addon",
          scene: scene,
          folderPath: folderPath,
        });
        return appendNavChild(res, reelBtn);
      } catch (err) {
        console.warn("[PathFileManager] patchNativeScenePlayer error:", err);
        return res;
      }
    }


    // ==========================================================================
    // Navigation Bar Integration (Binge's Native PluginApi.patch Method)
    // Reference: https://github.com/ordureconnoisseur/binge
    // ==========================================================================
    const FOLDER_NAV_SVG_PATH = "M464 128H272l-64-64H48C21.49 64 0 85.49 0 112v288c0 26.51 21.49 48 48 48h416c26.51 0 48-21.49 48-48V176c0-26.51-21.49-48-48-48z";

    function FilesNavButton() {
      const [isActive, setIsActive] = useState(window.location.hash.startsWith("#file-manager"));

      useEffect(() => {
        const handleHash = () => {
          setIsActive(window.location.hash.startsWith("#file-manager"));
        };
        window.addEventListener("hashchange", handleHash);
        return () => window.removeEventListener("hashchange", handleHash);
      }, []);

      return React.createElement(
        "div",
        {
          className: "col-4 col-sm-3 col-md-2 col-lg-auto nav-link",
          id: "sfm-nav-container",
        },
        React.createElement(
          "a",
          {
            href: "#file-manager",
            id: "sfm-nav-button",
            title: "File Manager (Browse by Directory)",
            "aria-label": "File Manager",
            className: `minimal p-4 p-xl-2 d-flex d-xl-inline-block flex-column justify-content-between align-items-center btn btn-primary ${isActive ? "active" : ""}`.trim(),
            onClick: function (evt) {
              evt.preventDefault();
              openFileManager();
            },
          },
          React.createElement(
            "svg",
            {
              "aria-hidden": "true",
              focusable: "false",
              className: "svg-inline--fa fa-icon nav-menu-icon d-block d-xl-inline mb-2 mb-xl-0 mr-xl-1",
              role: "img",
              xmlns: "http://www.w3.org/2000/svg",
              viewBox: "0 0 512 512",
            },
            React.createElement("path", {
              fill: "currentColor",
              d: FOLDER_NAV_SVG_PATH,
            })
          ),
          React.createElement("span", null, "Files")
        )
      );
    }

    // Helper: recursively append a React element into the correct children container
    function appendNavChild(node, item) {
      if (!node) return item;
      if (!item) return node;
      if (Array.isArray(node)) {
        return node.concat(item);
      }
      if (!React.isValidElement(node)) {
        if (typeof node === "string" || typeof node === "number") {
          return React.createElement(React.Fragment, null, node, item);
        }
        // Safeguard: Never render non-renderable objects (like plain {}) as React children!
        return item;
      }

      const children = node.props && node.props.children;
      if (children === undefined || children === null) {
        return React.cloneElement(node, null, item);
      }
      if (Array.isArray(children)) {
        return React.cloneElement(node, null, ...children, item);
      }
      return React.cloneElement(node, null, children, item);
    }

    // Adaptor helpers for Stash PluginApi.patch hooks
    function makeAfterPatch(handler) {
      return function () {
        const props = arguments[0];
        const res = arguments.length > 1 ? arguments[arguments.length - 1] : null;
        return handler(props, res);
      };
    }

    function makeInsteadPatch(handler) {
      return function () {
        const next = arguments[arguments.length - 1];
        const originalArgs = Array.prototype.slice.call(arguments, 0, -1);
        const props = arguments[0];
        const res = typeof next === "function" ? next.apply(this, originalArgs) : null;
        return handler(props, res);
      };
    }

    // Method 1: Official PluginApi.patch.instead & patch.after
    if (window.PluginApi.patch) {
      try {
        function patchNav(props, res) {
          return appendNavChild(res, React.createElement(FilesNavButton, { key: "sfm-files-nav-item" }));
        }

        if (window.PluginApi.patch.instead) {
          window.PluginApi.patch.instead("MainNavBar.MenuItems", makeInsteadPatch(patchNav));
          window.PluginApi.patch.instead("SceneCard.Details", makeInsteadPatch(patchNativeSceneCard));
          window.PluginApi.patch.instead("SceneCard", makeInsteadPatch(patchNativeSceneCard));
          window.PluginApi.patch.instead("ScenePage", makeInsteadPatch(patchNativeSceneDetails));
          window.PluginApi.patch.instead("SceneDetails", makeInsteadPatch(patchNativeSceneDetails));
          window.PluginApi.patch.instead("SceneDetails.Sidebar", makeInsteadPatch(patchNativeSceneDetails));
          window.PluginApi.patch.instead("SceneFileInfoPanel", makeInsteadPatch(patchNativeSceneDetails));
          window.PluginApi.patch.instead("ScenePlayer", makeInsteadPatch(patchNativeScenePlayer));
        } else if (window.PluginApi.patch.after) {
          window.PluginApi.patch.after("MainNavBar.MenuItems", makeAfterPatch(patchNav));
          window.PluginApi.patch.after("SceneCard.Details", makeAfterPatch(patchNativeSceneCard));
          window.PluginApi.patch.after("SceneCard", makeAfterPatch(patchNativeSceneCard));
          window.PluginApi.patch.after("ScenePage", makeAfterPatch(patchNativeSceneDetails));
          window.PluginApi.patch.after("SceneDetails", makeAfterPatch(patchNativeSceneDetails));
          window.PluginApi.patch.after("SceneDetails.Sidebar", makeAfterPatch(patchNativeSceneDetails));
          window.PluginApi.patch.after("SceneFileInfoPanel", makeAfterPatch(patchNativeSceneDetails));
          window.PluginApi.patch.after("ScenePlayer", makeAfterPatch(patchNativeScenePlayer));
        }


        if (window.PluginApi.patch.before) {
          window.PluginApi.patch.before("CheckboxGroup", function (props) {
            try {
              if (!props || props.groupId !== "menu-items") return [props];
              if (!Array.isArray(props.items)) return [props];
              if (props.items.some(item => item.id === "files-manager")) return [props];
              return [Object.assign({}, props, {
                items: props.items.concat([{ id: "files-manager", headingID: "Files" }])
              })];
            } catch (err) {
              return [props];
            }
          });
        }
      } catch (err) {
        console.warn("[PathFileManager] MainNavBar.MenuItems patch failed:", err);
      }
    }

    // Method 2: Fallback DOM Injection (Ensures placement inside the .row container)
    function injectMainBarButtonFallback() {
      if (document.getElementById("sfm-nav-container") || document.getElementById("sfm-nav-button")) return;

      const anchor =
        document.querySelector('.navbar-nav a[href*="/scenes"]') ||
        document.querySelector('.navbar-nav a[href*="/images"]') ||
        document.querySelector('.navbar-nav a');

      if (!anchor) return;

      const colItem = anchor.closest("[class*='col-']") || anchor.closest(".nav-item") || anchor;
      const rowContainer = colItem.closest(".row") || colItem.parentElement;
      if (!rowContainer) return;

      const colClass = (colItem.getAttribute && colItem.getAttribute("class")) || "col-4 col-sm-3 col-md-2 col-lg-auto nav-link";

      const container = document.createElement("div");
      container.className = colClass;
      container.id = "sfm-nav-container";

      const a = document.createElement("a");
      a.href = "#file-manager";
      a.id = "sfm-nav-button";
      a.title = "File Manager (Browse by Directory)";
      a.setAttribute("aria-label", "File Manager");
      a.className = "minimal p-4 p-xl-2 d-flex d-xl-inline-block flex-column justify-content-between align-items-center btn btn-primary";
      a.addEventListener("click", function (evt) {
        evt.preventDefault();
        openFileManager();
      });

      const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
      svg.setAttribute("aria-hidden", "true");
      svg.setAttribute("focusable", "false");
      svg.setAttribute("role", "img");
      svg.setAttribute("viewBox", "0 0 512 512");
      svg.setAttribute("class", "svg-inline--fa fa-icon nav-menu-icon d-block d-xl-inline mb-2 mb-xl-0 mr-xl-1");

      const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
      path.setAttribute("fill", "currentColor");
      path.setAttribute("d", FOLDER_NAV_SVG_PATH);
      svg.appendChild(path);

      const span = document.createElement("span");
      span.textContent = "Files";

      a.appendChild(svg);
      a.appendChild(span);
      container.appendChild(a);

      rowContainer.appendChild(container);
    }

    // ==========================================================================
    // Phase 4: Fallback DOM Injection Observers for Native Cards & Scene Details
    // ==========================================================================
    function injectSceneCardsDOMFallback() {
      if (typeof document === "undefined" || !document.querySelectorAll || !document.querySelector) return;
      if (typeof window !== "undefined" && window.location?.hash?.startsWith("#file-manager")) return;
      const cardEls = document.querySelectorAll(".scene-card, .card.scene-card, .scene-cards-grid .card, .scene-card-grid .card, [class*='SceneCard']");
      if (!cardEls || cardEls.length === 0) return;

      cardEls.forEach((cardEl) => {
        if (cardEl.getAttribute("data-sfm-decorated") === "true") return;
        if (cardEl.querySelector("[data-sfm-card-chip]")) {
          cardEl.setAttribute("data-sfm-decorated", "true");
          return;
        }

        const linkEl = cardEl.querySelector('a[href*="/scenes/"]');
        if (!linkEl) return;
        const href = linkEl.getAttribute("href") || "";
        const m = href.match(/\/scenes\/([a-zA-Z0-9_-]+)/);
        if (!m) return;
        const sceneId = m[1];

        const cachedScene = window.__SFM_GLOBAL_CACHE__?.scenes?.find((s) => String(s.id) === String(sceneId)) || { id: sceneId };
        const folderPath = resolveSceneFolder(cachedScene);

        const targetContainer = cardEl.querySelector(".card-section, .scene-card__details, .card-body") || cardEl;
        const mountDiv = document.createElement("div");
        mountDiv.className = "sfm-native-card-injected-container";
        targetContainer.appendChild(mountDiv);
        cardEl.setAttribute("data-sfm-decorated", "true");

        ReactDOM.render(
          React.createElement(NativeSceneCardOverlay, { scene: cachedScene, folderPath }),
          mountDiv
        );
      });
    }

    function injectSceneDetailDOMFallback() {
      if (typeof document === "undefined" || !document.querySelector || !document.getElementById) return;
      if (typeof window !== "undefined" && window.location?.hash?.startsWith("#file-manager")) return;
      const m = typeof window !== "undefined" && window.location?.pathname?.match(/\/scenes\/([a-zA-Z0-9_-]+)/);
      if (!m) return;
      const sceneId = m[1];

      // 1. Directory Hierarchy Breadcrumbs Row
      if (!document.getElementById("sfm-scene-hierarchy-row")) {
        const sidebar = document.querySelector(".scene-info, .scene-details, .details-list, .scene-sidebar, .col-lg-4 .card-body, .scene-file-info");
        if (sidebar && !sidebar.querySelector("[data-sfm-hierarchy]")) {
          const cachedScene = window.__SFM_GLOBAL_CACHE__?.scenes?.find((s) => String(s.id) === String(sceneId)) || { id: sceneId };
          const folderPath = resolveSceneFolder(cachedScene);
          const mountDiv = document.createElement("div");
          mountDiv.id = "sfm-scene-hierarchy-container";
          sidebar.appendChild(mountDiv);

          ReactDOM.render(
            React.createElement(NativeSceneDetailDirectoryHierarchy, { scene: cachedScene, folderPath }),
            mountDiv
          );
        }
      }

      // 2. Reel Mode Button
      if (!document.getElementById("sfm-scene-reel-btn")) {
        const toolbar = document.querySelector(".scene-toolbar, .scene-header .btn-toolbar, .scene-header .btn-group, .video-player-container, .scene-player, .scene-header");
        if (toolbar && !toolbar.querySelector("[data-sfm-reel-btn]")) {
          const cachedScene = window.__SFM_GLOBAL_CACHE__?.scenes?.find((s) => String(s.id) === String(sceneId)) || { id: sceneId };
          const folderPath = resolveSceneFolder(cachedScene);
          const mountDiv = document.createElement("div");
          mountDiv.id = "sfm-scene-reel-btn-container";
          mountDiv.style.display = "inline-block";
          mountDiv.style.marginLeft = "8px";
          toolbar.appendChild(mountDiv);

          ReactDOM.render(
            React.createElement(NativeSceneDetailReelButton, { scene: cachedScene, folderPath }),
            mountDiv
          );
        }
      }
    }

    let sfmMutationTimer = null;
    function scheduleNativeDomScan() {
      if (typeof document === "undefined" || !document.querySelector) return;
      if (sfmMutationTimer) return;
      sfmMutationTimer = setTimeout(() => {
        sfmMutationTimer = null;
        injectSceneCardsDOMFallback();
        injectSceneDetailDOMFallback();
      }, 150);
    }

    // Bounded fallback injection timer (stops once injected or after 10 attempts to eliminate memory leaks)
    let fallbackAttempts = 0;
    const fallbackTimer = setInterval(() => {
      fallbackAttempts++;
      injectMainBarButtonFallback();
      if (document.getElementById("sfm-nav-button") || fallbackAttempts >= 10) {
        clearInterval(fallbackTimer);
      }
    }, 1000);
    setTimeout(injectMainBarButtonFallback, 250);

    if (window.PluginApi.Event) {
      window.PluginApi.Event.addEventListener("stash:location", () => {
        setTimeout(injectMainBarButtonFallback, 150);
        scheduleNativeDomScan();
      });
    }

    window.addEventListener("popstate", scheduleNativeDomScan);
    window.addEventListener("hashchange", scheduleNativeDomScan);

    if (typeof MutationObserver !== "undefined" && document.body) {
      try {
        const nativeObserver = new MutationObserver(() => {
          scheduleNativeDomScan();
        });
        nativeObserver.observe(document.body, { childList: true, subtree: true });
      } catch (e) {}
    }
    setTimeout(scheduleNativeDomScan, 300);

    // Eager background library index restoration
    setTimeout(() => {
      ensureCatalog().catch(() => {});
    }, 100);

    // Expose Phase 4 native platform embedding APIs on global cache
    window.__SFM_GLOBAL_CACHE__.NativeSceneCardOverlay = NativeSceneCardOverlay;
    window.__SFM_GLOBAL_CACHE__.NativeSceneDetailDirectoryHierarchy = NativeSceneDetailDirectoryHierarchy;
    window.__SFM_GLOBAL_CACHE__.NativeSceneDetailReelButton = NativeSceneDetailReelButton;
    window.__SFM_GLOBAL_CACHE__.patchNativeSceneCard = patchNativeSceneCard;
    window.__SFM_GLOBAL_CACHE__.patchNativeSceneDetails = patchNativeSceneDetails;
    window.__SFM_GLOBAL_CACHE__.patchNativeScenePlayer = patchNativeScenePlayer;
    window.__SFM_GLOBAL_CACHE__.resolveSceneFolder = resolveSceneFolder;
    window.__SFM_GLOBAL_CACHE__.ensureCatalog = ensureCatalog;
    window.__SFM_GLOBAL_CACHE__.openFileManager = openFileManager;
    window.__SFM_GLOBAL_CACHE__.injectSceneCardsDOMFallback = injectSceneCardsDOMFallback;
    window.__SFM_GLOBAL_CACHE__.injectSceneDetailDOMFallback = injectSceneDetailDOMFallback;
    if (window.PluginApi) {
      window.PluginApi.Filemanager = window.__SFM_GLOBAL_CACHE__;
    }


    console.log("[PathFileManager] Initialized successfully with all enhanced features.");
  } catch (err) {
    console.error("[PathFileManager] Startup error:", err);
  }
})();
